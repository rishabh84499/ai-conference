import { createSlice, type PayloadAction } from '@reduxjs/toolkit';
import type { AuthUser } from '@/types/entities/user';

// ── Types ──────────────────────────────────────────────────

export interface TokenData {
    token: string;
    expires: string;
}

export interface RefreshTokenData {
    token?: string; // Optional because it might be in an HttpOnly cookie
    expires: string;
}

export interface Tokens {
    access: TokenData;
    refresh: RefreshTokenData;
}

export interface AuthState {
    user: AuthUser | null;
    tokens: Tokens | null;
    isAuthenticated: boolean;
}

// ── Initial State ──────────────────────────────────────────
const initialState: AuthState = {
    user: null,
    tokens: null,
    isAuthenticated: false,
};

// ── Slice ──────────────────────────────────────────────────
const authSlice = createSlice({
    name: 'auth',
    initialState,
    reducers: {
        setAuth(state, action: PayloadAction<{ user: AuthUser; tokens: Tokens }>) {
            state.user = action.payload.user;
            state.tokens = action.payload.tokens;
            state.isAuthenticated = true;
        },
        setUser(state, action: PayloadAction<AuthUser>) {
            state.user = action.payload;
        },
        setTokens(state, action: PayloadAction<Tokens>) {
            state.tokens = action.payload;
        },
        clearAuth(state) {
            state.user = null;
            state.tokens = null;
            state.isAuthenticated = false;
        },
    },
});

export const { setAuth, setUser, setTokens, clearAuth } = authSlice.actions;
export default authSlice.reducer;
