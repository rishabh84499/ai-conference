import authReducer, { setAuth, setUser, setTokens, clearAuth, type AuthState } from './authSlice';
import { describe, it, expect } from 'vitest';

describe('authSlice', () => {
    const initialState: AuthState = {
        user: null,
        tokens: null,
        isAuthenticated: false,
    };

    it('should handle initial state', () => {
        expect(authReducer(undefined, { type: 'unknown' })).toEqual(initialState);
    });

    it('should handle setAuth', () => {
        const user = { _id: '1', name: 'Test User', email: 'test@example.com', role: 'admin' };
        const tokens = {
            access: { token: 'access-token', expires: '2024-01-01' },
            refresh: { token: 'refresh-token', expires: '2024-01-01' }
        };

        const actual = authReducer(initialState, setAuth({ user, tokens }));

        expect(actual.user).toEqual(user);
        expect(actual.tokens).toEqual(tokens);
        expect(actual.isAuthenticated).toBe(true);
    });

    it('should handle setUser', () => {
        const user = { _id: '1', name: 'Test User', email: 'test@example.com', role: 'user' };
        const actual = authReducer(initialState, setUser(user));
        expect(actual.user).toEqual(user);
    });

    it('should handle setTokens', () => {
        const tokens = {
            access: { token: 'new-access', expires: '2024-01-01' },
            refresh: { token: 'new-refresh', expires: '2024-01-01' }
        };
        const actual = authReducer(initialState, setTokens(tokens));
        expect(actual.tokens).toEqual(tokens);
    });

    it('should handle clearAuth', () => {
        const loggedInState: AuthState = {
            user: { _id: '1', name: 'User', email: 'u@e.com', role: 'user' },
            tokens: {
                access: { token: 'a', expires: '2024-01-01' },
                refresh: { token: 'r', expires: '2024-01-01' }
            },
            isAuthenticated: true,
        };

        const actual = authReducer(loggedInState, clearAuth());
        expect(actual).toEqual(initialState);
    });
});
