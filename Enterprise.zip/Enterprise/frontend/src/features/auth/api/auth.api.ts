import apiClient from '@/core/api/client';
import { ENDPOINTS } from '@/core/api/endpoints';
import type { ApiResponse } from '@/core/types/api';
import { z } from 'zod';
import {
    AuthResponseSchema,
    LoginPayloadSchema,
    TokensSchema,
    AuthUserSchema
} from '@/features/auth/schemas/auth.schema';

export type LoginPayload = z.infer<typeof LoginPayloadSchema>;
export type AuthResponse = z.infer<typeof AuthResponseSchema>;

export interface ForgotPasswordPayload {
    email: string;
}

export interface ResetPasswordPayload {
    token: string;
    password: string;
}

export interface ChangePasswordPayload {
    currentPassword?: string;
    newPassword: string;
}

export const authApi = {
    login: async (payload: LoginPayload) => {
        const { data } = await apiClient.post<ApiResponse<AuthResponse>>(
            ENDPOINTS.AUTH.LOGIN,
            payload
        );
        return AuthResponseSchema.parse(data.data);
    },

    refreshTokens: async (refreshToken: string) => {
        const { data } = await apiClient.post<ApiResponse<{ tokens: z.infer<typeof TokensSchema> }>>(
            ENDPOINTS.AUTH.REFRESH,
            { refreshToken }
        );
        // Validate just tokens part
        const tokenData = z.object({ tokens: TokensSchema }).parse(data.data);
        return tokenData;
    },

    getProfile: async () => {
        const { data } = await apiClient.get<ApiResponse<z.infer<typeof AuthUserSchema>>>(
            ENDPOINTS.AUTH.PROFILE
        );
        return AuthUserSchema.parse(data.data);
    },

    logout: async () => {
        return apiClient.post(ENDPOINTS.AUTH.LOGOUT);
    },

    forgotPassword: (payload: ForgotPasswordPayload) =>
        apiClient.post(ENDPOINTS.AUTH.FORGOT_PASSWORD, payload),

    resetPassword: (payload: ResetPasswordPayload) =>
        apiClient.post(ENDPOINTS.AUTH.RESET_PASSWORD, payload),

    changePassword: (payload: ChangePasswordPayload) =>
        apiClient.post(ENDPOINTS.AUTH.CHANGE_PASSWORD, payload),
};

