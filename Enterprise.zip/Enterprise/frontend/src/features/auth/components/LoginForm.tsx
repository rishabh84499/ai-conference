import { useState } from 'react';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { z } from 'zod';
import { useTranslation } from 'react-i18next';
import { useAuth } from '@/features/auth/hooks/useAuth';
import { Mail, Lock, ArrowRight, Eye, EyeOff } from 'lucide-react';
import { Button } from '@/shared/ui/Button';
import { Input } from '@/shared/ui/Input';
import { Label } from '@/shared/ui/Label';
import { Link } from 'react-router-dom';

export default function LoginForm() {
    const { t } = useTranslation();
    const { login, isLoading } = useAuth();
    const [showPassword, setShowPassword] = useState(false);

    // Schema must be memoized or created inside component to use t()
    const loginSchema = z.object({
        email: z.string().email(t('auth.validation.email_invalid')),
        password: z.string().min(6, t('auth.validation.password_min')),
    });

    type LoginFormValues = z.infer<typeof loginSchema>;

    const {
        register,
        handleSubmit,
        setValue,
        formState: { errors },
    } = useForm<LoginFormValues>({
        resolver: zodResolver(loginSchema),
        defaultValues: {
            email: '',
            password: '',
        },
    });

    const onSubmit = async (data: LoginFormValues) => {
        try {
            await login(data);
        } catch {
            // Error already handled in useAuth hook via toast
        }
    };

    const fillCredentials = (type: 'email' | 'password' | 'both') => {
        if (type === 'email' || type === 'both') setValue('email', 'superadmin@enterprise.com', { shouldValidate: true });
        if (type === 'password' || type === 'both') setValue('password', 'SuperAdmin@123!', { shouldValidate: true });
    };

    return (
        <form onSubmit={handleSubmit(onSubmit)} className="space-y-6 animate-in fade-in slide-in-from-bottom-4 duration-500">
            {/* Heading */}
            <div className="space-y-2 text-center sm:text-left">
                <h2 className="text-2xl font-bold tracking-tight text-foreground">
                    {t('auth.login.title')}
                </h2>
                <p className="text-sm text-muted-foreground">
                    {t('auth.login.subtitle')}
                </p>
            </div>

            {/* Email Field */}
            <div className="space-y-2">
                <Label htmlFor="email" className="text-foreground">{t('auth.login.email_label')}</Label>
                <div className="relative group">
                    <div className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400 dark:text-muted-foreground group-focus-within:text-primary transition-colors duration-200 pointer-events-none">
                        <Mail size={18} />
                    </div>
                    <Input
                        id="email"
                        type="email"
                        placeholder={t('auth.login.email_placeholder')}
                        {...register('email')}
                        autoComplete="email"
                        className="pl-10 h-11"
                        error={errors.email?.message}
                    />
                </div>
            </div>

            {/* Password Field */}
            <div className="space-y-2">
                <Label htmlFor="password" className="text-foreground">{t('auth.login.password_label')}</Label>
                <div className="relative group">
                    <div className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400 dark:text-muted-foreground group-focus-within:text-primary transition-colors duration-200 pointer-events-none">
                        <Lock size={18} />
                    </div>
                    <Input
                        id="password"
                        type={showPassword ? 'text' : 'password'}
                        placeholder={t('auth.login.password_placeholder')}
                        {...register('password')}
                        autoComplete="current-password"
                        className="pl-10 pr-10 h-11"
                        error={errors.password?.message}
                    />
                    <button
                        type="button"
                        onClick={() => setShowPassword(!showPassword)}
                        className="absolute right-3 top-1/2 -translate-y-1/2 text-muted-foreground hover:text-foreground cursor-pointer transition-colors"
                        tabIndex={-1}
                    >
                        {showPassword ? <EyeOff size={18} /> : <Eye size={18} />}
                    </button>
                </div>
            </div>

            {/* Submit Button */}
            <Button
                type="submit"
                disabled={isLoading}
                className="w-full font-semibold shadow-lg shadow-primary/20 transition-all hover:shadow-primary/40 hover:-translate-y-0.5"
                size="lg"
                isLoading={isLoading}
            >
                {isLoading ? t('auth.login.submitting') : (
                    <>
                        {t('auth.login.submit')}
                        <ArrowRight size={16} className="ml-2 transition-transform group-hover:translate-x-1" />
                    </>
                )}
            </Button>

            {/* Divider */}
            <div className="relative">
                <div className="absolute inset-0 flex items-center">
                    <span className="w-full border-t border-border/40" />
                </div>
                <div className="relative flex justify-center text-xs uppercase">
                    <span className="bg-background/20 backdrop-blur-md px-4 text-muted-foreground font-medium rounded-full border border-white/5">{t('common.or')}</span>
                </div>
            </div>

            {/* Forgot Password */}
            <div className="text-center">
                <Link
                    to="/forgot-password"
                    className="text-sm font-medium text-primary hover:text-primary/90 underline-offset-4 hover:underline"
                >
                    {t('auth.login.forgot_password')}
                </Link>
            </div>

            {/* Dev Only: SuperAdmin Credentials */}
            {import.meta.env.DEV && (
                <div className="mt-8 p-4 rounded-xl bg-gray-100/80 dark:bg-secondary/30 border border-gray-200 dark:border-border/40 text-xs backdrop-blur-sm shadow-sm">
                    <div className="flex items-center gap-2 mb-3 text-indigo-600 dark:text-primary font-bold uppercase tracking-widest text-[10px]">
                        <span className="w-1.5 h-1.5 rounded-full bg-indigo-600 dark:bg-primary animate-pulse" />
                        Development Access
                    </div>
                    <div className="space-y-2">
                        <div className="group flex items-center justify-between p-2.5 rounded-lg bg-white/60 dark:bg-background/40 hover:bg-white/80 dark:hover:bg-background/60 border border-gray-200/50 dark:border-border/20 hover:border-indigo-300 dark:hover:border-primary/30 transition-all cursor-pointer shadow-sm hover:shadow-md"
                            onClick={() => fillCredentials('email')}
                            title="Click to copy email"
                        >
                            <span className="text-gray-600 dark:text-muted-foreground font-medium">Email</span>
                            <code className="font-mono text-gray-900 dark:text-foreground font-semibold bg-gray-50 dark:bg-background/50 px-1.5 py-0.5 rounded border border-gray-200 dark:border-white/5">superadmin@enterprise.com</code>
                        </div>
                        <div className="group flex items-center justify-between p-2.5 rounded-lg bg-white/60 dark:bg-background/40 hover:bg-white/80 dark:hover:bg-background/60 border border-gray-200/50 dark:border-border/20 hover:border-indigo-300 dark:hover:border-primary/30 transition-all cursor-pointer shadow-sm hover:shadow-md"
                            onClick={() => fillCredentials('password')}
                            title="Click to copy password"
                        >
                            <span className="text-gray-600 dark:text-muted-foreground font-medium">Pass</span>
                            <code className="font-mono text-gray-900 dark:text-foreground font-semibold bg-gray-50 dark:bg-background/50 px-1.5 py-0.5 rounded border border-gray-200 dark:border-white/5">SuperAdmin@123!</code>
                        </div>
                    </div>
                    <div className="mt-2 text-center">
                        <button
                            type="button"
                            onClick={() => fillCredentials('both')}
                            className="text-[10px] uppercase font-bold text-indigo-500 hover:text-indigo-600 dark:text-primary/80 dark:hover:text-primary transition-colors"
                        >
                            Auto-fill Both
                        </button>
                    </div>
                </div>
            )}
        </form>
    );
}
