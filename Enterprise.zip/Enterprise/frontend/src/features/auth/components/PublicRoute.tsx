import { Navigate, useLocation } from 'react-router-dom';
import { useAppSelector } from '@/core/store';
import { type ReactNode } from 'react';

interface PublicRouteProps {
    children: ReactNode;
}

export default function PublicRoute({ children }: PublicRouteProps) {
    const { isAuthenticated } = useAppSelector((state) => state.auth);
    const location = useLocation();

    if (isAuthenticated) {
        // Redirect to dashboard (or previous location) if already logged in
        const from = location.state?.from?.pathname || '/dashboard';
        return <Navigate to={from} replace />;
    }

    return <>{children}</>;
}
