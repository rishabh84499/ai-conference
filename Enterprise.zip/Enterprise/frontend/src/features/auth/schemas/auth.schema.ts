import { z } from 'zod';

export const UserRoleSchema = z.enum(['SuperAdmin', 'Admin', 'Manager', 'Operator']);

export const UserStatusSchema = z.enum(['active', 'inactive', 'suspended', 'pending']);

export const UserSchema = z.object({
    _id: z.string(),
    firstName: z.string(),
    lastName: z.string(),
    email: z.string().email(),
    role: UserRoleSchema,
    status: UserStatusSchema,
    profileImage: z.string().optional(),
    isEmailVerified: z.boolean(),
    lastLogin: z.string().optional(),
    createdAt: z.string(),
    updatedAt: z.string(),
    // preferences: ... (add if needed, optional for now)
});

// Basic token data
export const TokenDataSchema = z.object({
    token: z.string(),
    expires: z.string(),
});

// Refresh token might be empty/partial if responding with cookies
export const RefreshTokenSchema = z.object({
    token: z.string().optional(),
    expires: z.string(),
});

export const TokensSchema = z.object({
    access: TokenDataSchema,
    refresh: RefreshTokenSchema,
});

export const AuthUserSchema = UserSchema.extend({
    // name is often a virtual field, so we make it optional or remove it if not sent
    name: z.string().optional(),
});

export const AuthResponseSchema = z.object({
    user: AuthUserSchema,
    tokens: TokensSchema,
});

export const LoginPayloadSchema = z.object({
    email: z.string().email(),
    password: z.string(),
});
