import { describe, it, expect } from 'vitest';
import { AuthResponseSchema } from './auth.schema';

describe('AuthResponseSchema', () => {
    it('validates a response without name and refresh token string (cookie-based auth)', () => {
        const payload = {
            user: {
                _id: '123',
                firstName: 'John',
                lastName: 'Doe',
                email: 'john@example.com',
                role: 'Admin',
                status: 'active',
                isEmailVerified: true,
                createdAt: new Date().toISOString(),
                updatedAt: new Date().toISOString(),
            },
            tokens: {
                access: {
                    token: 'access-token-123',
                    expires: new Date().toISOString(),
                },
                refresh: {
                    expires: new Date().toISOString(),
                    // token is missing, which should be valid now
                },
            },
        };

        const result = AuthResponseSchema.safeParse(payload);
        expect(result.success).toBe(true);
    });

    it('fails when required user fields are missing', () => {
        const payload = {
            user: {
                // missing firstName/lastName
                email: 'john@example.com',
            },
            tokens: { /* ... */ }
        };

        const result = AuthResponseSchema.safeParse(payload);
        expect(result.success).toBe(false);
    });
});
