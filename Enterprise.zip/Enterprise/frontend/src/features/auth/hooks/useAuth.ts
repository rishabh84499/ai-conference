import { useMutation, useQueryClient } from '@tanstack/react-query';
import { AxiosError } from 'axios';
import { useAppSelector, useAppDispatch } from '@/core/store';
import { setAuth, clearAuth } from '@/features/auth/store/authSlice';
import { authApi } from '@/features/auth/api/auth.api';
import toast from 'react-hot-toast';
import { useNavigate } from 'react-router-dom';

interface ApiErrorResponse {
    message: string;
}

export function useAuth() {
    const dispatch = useAppDispatch();
    const navigate = useNavigate();
    const queryClient = useQueryClient();
    const { user, isAuthenticated, tokens } = useAppSelector((state) => state.auth);

    const loginMutation = useMutation({
        mutationFn: authApi.login,
        onSuccess: (data) => {
            dispatch(setAuth({ user: data.user, tokens: data.tokens }));
            toast.success('Welcome back!');
            navigate('/dashboard');
        },
        onError: (error: AxiosError<ApiErrorResponse>) => {
            const message = error?.response?.data?.message || 'Login failed. Please try again.';
            toast.error(message);
        },
    });

    const logoutMutation = useMutation({
        mutationFn: authApi.logout,
        onSettled: () => {
            dispatch(clearAuth());
            queryClient.clear();
            toast.success('Logged out successfully');
            navigate('/login');
        },
    });

    return {
        user,
        tokens,
        isAuthenticated,
        isLoading: loginMutation.isPending,
        login: loginMutation.mutateAsync,
        logout: logoutMutation.mutate,
    };
}
