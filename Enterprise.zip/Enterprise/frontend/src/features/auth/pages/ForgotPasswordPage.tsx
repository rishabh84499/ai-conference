import * as React from 'react';
import { useState } from 'react';
import { z } from 'zod';
import { authApi } from '@/features/auth/api/auth.api';
import { Button } from '@/shared/ui/Button';
import { Input } from '@/shared/ui/Input';
import { Label } from '@/shared/ui/Label';
import { Mail, ArrowLeft } from 'lucide-react';
import { Link } from 'react-router-dom';
import toast from 'react-hot-toast';

const forgotPasswordSchema = z.object({
    email: z.string().email('Please enter a valid email address'),
});

export default function ForgotPasswordPage() {
    const [email, setEmail] = useState('');
    const [error, setError] = useState('');
    const [isLoading, setIsLoading] = useState(false);
    const [isSubmitted, setIsSubmitted] = useState(false);

    const handleSubmit = async (e: React.FormEvent) => {
        e.preventDefault();
        setError('');

        const result = forgotPasswordSchema.safeParse({ email });
        if (!result.success) {
            setError(result.error.issues[0].message);
            return;
        }

        setIsLoading(true);
        try {
            await authApi.forgotPassword({ email });
            setIsSubmitted(true);
            toast.success('Reset link sent to your email');
        } catch (err: unknown) {
            const error = err as { response?: { data?: { message?: string } } };
            toast.error(error?.response?.data?.message || 'Failed to send reset link');
        } finally {
            setIsLoading(false);
        }
    };

    if (isSubmitted) {
        return (
            <div className="text-center space-y-6 animate-in fade-in zoom-in duration-500">
                <div className="text-5xl mb-6 filter drop-shadow-md">📧</div>
                <h2 className="text-2xl font-bold tracking-tight text-foreground">
                    Check your email
                </h2>
                <p className="text-muted-foreground">
                    We've sent a password reset link to <strong className="text-foreground">{email}</strong>
                </p>
                <div className="pt-4">
                    <Link
                        to="/login"
                        className="inline-flex items-center gap-2 text-sm font-medium text-primary hover:text-primary/80 transition-colors"
                    >
                        <ArrowLeft size={16} />
                        Back to sign in
                    </Link>
                </div>
            </div>
        );
    }

    return (
        <form onSubmit={handleSubmit} className="space-y-6 animate-in fade-in slide-in-from-bottom-4 duration-500">
            <div className="text-center sm:text-left space-y-1">
                <h2 className="text-2xl font-bold tracking-tight text-foreground">
                    Reset your password
                </h2>
                <p className="text-sm text-muted-foreground">
                    Enter your email and we'll send you a reset link
                </p>
            </div>

            <div className="space-y-2">
                <Label htmlFor="email" className="text-foreground">Email</Label>
                <div className="relative group">
                    <div className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400 dark:text-muted-foreground group-focus-within:text-primary transition-colors duration-200 pointer-events-none">
                        <Mail size={18} />
                    </div>
                    <Input
                        id="email"
                        type="email"
                        placeholder="you@company.com"
                        value={email}
                        onChange={(e: React.ChangeEvent<HTMLInputElement>) => setEmail(e.target.value)}
                        error={error}
                        autoComplete="email"
                        className="pl-10 h-11"
                    />
                </div>
            </div>

            <Button type="submit" size="lg" className="w-full font-semibold shadow-lg shadow-primary/20 transition-all hover:shadow-primary/40 hover:-translate-y-0.5" isLoading={isLoading}>
                Send Reset Link
            </Button>

            <div className="text-center">
                <Link
                    to="/login"
                    className="inline-flex items-center gap-2 text-sm font-medium text-primary hover:text-primary/80 transition-colors"
                >
                    <ArrowLeft size={16} />
                    Back to sign in
                </Link>
            </div>
        </form>
    );
}
