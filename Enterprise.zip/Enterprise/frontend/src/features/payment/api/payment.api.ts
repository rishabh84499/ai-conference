import apiClient from '@/core/api/client';
import { ENDPOINTS } from '@/core/api/endpoints';
import type { ApiResponse } from '@/core/types/api';

export interface CreateOrderPayload {
    amount: number;
    currency: string;
    providerName?: string;
    options?: any;
}

export interface VerifyPaymentPayload {
    orderId: string;
    paymentId: string;
    signature: string;
    providerName?: string;
}

export interface RefundPayload {
    transactionId: string;
    amount?: number;
    notes?: any;
}

export const paymentApi = {
    createOrder: async (payload: CreateOrderPayload) => {
        const { data } = await apiClient.post<ApiResponse<any>>(
            ENDPOINTS.PAYMENT.CREATE_ORDER,
            payload
        );
        return data.data;
    },

    verifyPayment: async (payload: VerifyPaymentPayload) => {
        const { data } = await apiClient.post<ApiResponse<any>>(
            ENDPOINTS.PAYMENT.VERIFY,
            payload
        );
        return data.data;
    },

    refundPayment: async (payload: RefundPayload) => {
        const { data } = await apiClient.post<ApiResponse<any>>(
            ENDPOINTS.PAYMENT.REFUND,
            payload
        );
        return data.data;
    },
    getTransactions: async (params?: any) => {
        const { data } = await apiClient.get<ApiResponse<any>>(
            ENDPOINTS.PAYMENT.LIST,
            { params }
        );
        return data.data;
    },
};
