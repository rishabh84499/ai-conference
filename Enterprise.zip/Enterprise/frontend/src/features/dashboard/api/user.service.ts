import apiClient from '@/core/api/client';
import { ENDPOINTS } from '@/core/api/endpoints';
import type {
    User,
    CreateUserRequest,
    UpdateUserRequest,
    UserFilters,
    UserStatus
} from '@/features/dashboard/types/user';
import type { ApiResponse, PaginatedResponse } from '@/core/types/api';

import { UserListResponseSchema } from '@/features/dashboard/schemas/user.schema';

export const userService = {
    getUsers: async (filters?: UserFilters): Promise<ApiResponse<PaginatedResponse<User>>> => {
        const params = new URLSearchParams();
        if (filters) {
            Object.entries(filters).forEach(([key, value]) => {
                if (value !== undefined && value !== '') {
                    params.append(key, String(value));
                }
            });
        }
        const response = await apiClient.get<ApiResponse<PaginatedResponse<User>>>(`${ENDPOINTS.USERS.BASE}?${params.toString()}`);

        // Runtime validation
        // Note: validating large lists can be expensive, but ensures type safety
        try {
            // We only validate the `data` part of the response if the structure matches
            if (response.data && response.data.data) {
                // Actually the `UserListResponseSchema` validates the paginated object structure { results, page, ... }
                // The `ApiResponse` shape is { success, message, data: PaginatedResponse }
                UserListResponseSchema.parse(response.data.data);
            }
        } catch (error) {
            console.error('User validation failed:', error);
            // We don't throw to avoid breaking UI on minor mismatches, but log it for dev
        }

        return response.data;
    },

    getUser: async (id: string) => {
        const response = await apiClient.get<ApiResponse<User>>(ENDPOINTS.USERS.BY_ID(id));
        return response.data;
    },

    createUser: async (data: CreateUserRequest) => {
        const response = await apiClient.post<ApiResponse<User>>(ENDPOINTS.USERS.BASE, data);
        return response.data.data;
    },

    updateUser: async (id: string, data: UpdateUserRequest) => {
        const response = await apiClient.patch<ApiResponse<User>>(ENDPOINTS.USERS.BY_ID(id), data);
        return response.data.data;
    },

    updateProfile: async (data: UpdateUserRequest) => {
        const response = await apiClient.patch<ApiResponse<User>>(`${ENDPOINTS.USERS.BASE}/profile`, data);
        return response.data.data;
    },

    deleteUser: async (id: string) => {
        await apiClient.delete(ENDPOINTS.USERS.BY_ID(id));
    },

    changeStatus: async (id: string, status: UserStatus) => {
        const response = await apiClient.patch<ApiResponse<User>>(`${ENDPOINTS.USERS.BY_ID(id)}/status`, { status });
        return response.data.data;
    },

    resetPassword: async (id: string, password: string) => {
        const response = await apiClient.post<ApiResponse<null>>(`${ENDPOINTS.USERS.BY_ID(id)}/reset-password`, { password });
        return response.data;
    },
};
