import apiClient from '@/core/api/client';
import type { ApiResponse, PaginatedResponse } from '@/core/types/api';

export interface Notification {
    id: string; // mapped from _id
    title: string;
    message: string;
    type: 'security' | 'system' | 'marketing' | 'activity';
    read: boolean;
    createdAt: string;
    [key: string]: unknown;
}

export interface BroadcastRequest {
    title: string;
    message: string;
    type: 'security' | 'system' | 'marketing' | 'activity';
}

export const notificationApi = {
    getNotifications: async (params?: { page?: number; limit?: number; sortBy?: string }) => {
        const { data } = await apiClient.get<ApiResponse<PaginatedResponse<Notification & { _id: string }>>>('/notifications', { params });
        const result = data.data;
        return {
            results: result.results.map((n) => ({ ...n, id: n._id })),
            page: result.page,
            limit: result.limit,
            totalPages: result.totalPages,
            totalResults: result.totalResults
        };
    },

    markAsRead: async (notificationId: string) => {
        const { data } = await apiClient.patch<ApiResponse<Notification>>(`/notifications/${notificationId}/read`);
        return data.data;
    },

    markAllAsRead: async () => {
        await apiClient.patch<ApiResponse<null>>('/notifications/read-all');
    },

    deleteNotification: async (notificationId: string) => {
        await apiClient.delete<ApiResponse<null>>(`/notifications/${notificationId}`);
    },

    deleteAllNotifications: async () => {
        await apiClient.delete<ApiResponse<null>>('/notifications/all');
    },

    broadcastNotification: async (request: BroadcastRequest) => {
        const { data } = await apiClient.post<ApiResponse<BroadcastRequest & { _id: string }>>('/notifications/broadcast', request);
        return data.data;
    }
};
