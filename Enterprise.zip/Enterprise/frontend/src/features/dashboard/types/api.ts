export interface ApiResponse<T> {
    status: number;
    message: string;
    data: T;
}

export interface PaginatedResponse<T> {
    results: T[];
    page: number;
    limit: number;
    totalPages: number;
    totalResults: number;
}
