import { UserRole, UserStatus, type User, type UserPreferences } from '@/types/entities/user';

export { UserRole, UserStatus };
export type { User };

export interface UserListResponse {
    results: User[];
    page: number;
    limit: number;
    totalPages: number;
    totalResults: number;
}

export interface CreateUserRequest {
    email: string;
    password: string;
    firstName: string;
    lastName: string;
    role: UserRole;
    status?: UserStatus;
}

export interface UpdateUserRequest {
    email?: string;
    firstName?: string;
    lastName?: string;
    role?: UserRole;
    password?: string;
    preferences?: UserPreferences;
}

export interface UserFilters {
    role?: string;
    status?: string;
    sortBy?: string;
    sortOrder?: 'asc' | 'desc';
    page?: number;
    limit?: number;
    search?: string;
}
