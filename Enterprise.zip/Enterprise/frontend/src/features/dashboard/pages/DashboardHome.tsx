import { useAppSelector } from '@/core/store';

export default function DashboardHome() {
    const user = useAppSelector((state) => state.auth.user);

    return (
        <div className="w-full space-y-8 animate-in fade-in slide-in-from-bottom-4 duration-500">
            {/* Header Section */}
            <div>
                <h1 className="text-4xl font-extrabold tracking-tight sm:text-5xl mb-2">
                    <span className="block text-foreground">Welcome back,</span>
                    <span className="block bg-gradient-to-r from-indigo-500 via-purple-500 to-pink-500 bg-clip-text text-transparent">
                        {user?.firstName ? `${user.firstName} ${user.lastName || ''}`.trim() : (user?.name || 'User')}
                    </span>
                </h1>
                <p className="text-lg text-muted-foreground/80 max-w-3xl lg:max-w-4xl">
                    Here's what's happening in your enterprise environment today.
                </p>
            </div>

            {/* Stats Grid */}
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
                {[
                    { label: 'Total Users', value: '2,847', change: '+12.5%', trend: 'up', color: 'from-blue-500/20 to-cyan-500/20', iconColor: 'text-blue-500' },
                    { label: 'Active Sessions', value: '1,024', change: '+3.2%', trend: 'up', color: 'from-emerald-500/20 to-green-500/20', iconColor: 'text-emerald-500' },
                    { label: 'Revenue', value: '$48,290', change: '+8.1%', trend: 'up', color: 'from-violet-500/20 to-purple-500/20', iconColor: 'text-violet-500' },
                    { label: 'Pending Tasks', value: '23', change: '-4 today', trend: 'down', color: 'from-amber-500/20 to-orange-500/20', iconColor: 'text-amber-500' },
                ].map((stat) => (
                    <div
                        key={stat.label}
                        className={`relative overflow-hidden rounded-2xl p-6 border border-white/10 bg-gradient-to-br ${stat.color} backdrop-blur-sm shadow-xl transition-all duration-300 hover:scale-[1.02] hover:shadow-2xl hover:border-white/20 group`}
                    >
                        <div className="relative z-10">
                            <p className="text-sm font-medium text-muted-foreground mb-1">
                                {stat.label}
                            </p>
                            <h3 className="text-3xl font-bold text-foreground tracking-tight">
                                {stat.value}
                            </h3>
                            <div className="flex items-center gap-2 mt-2">
                                <span className={`text-xs font-bold px-2 py-0.5 rounded-full bg-background/40 border border-white/10 ${stat.iconColor}`}>
                                    {stat.change}
                                </span>
                                <span className="text-xs text-muted-foreground/70">vs last month</span>
                            </div>
                        </div>
                        {/* Decorative background glow */}
                        <div className={`absolute -right-6 -bottom-6 w-24 h-24 rounded-full blur-2xl opacity-20 bg-current ${stat.iconColor}`} />
                    </div>
                ))}
            </div>

            {/* Placeholder Content */}
            <div className="rounded-2xl p-12 text-center border dashed border-border/50 bg-card/30 backdrop-blur-sm">
                <div className="mx-auto w-16 h-16 rounded-full bg-muted/30 flex items-center justify-center mb-4 text-3xl">
                    📊
                </div>
                <h3 className="text-lg font-semibold text-foreground">Analytics Overview</h3>
                <p className="text-muted-foreground max-w-xl md:max-w-2xl mx-auto mt-2">
                    Detailed charts and real-time data visualization components will appear here.
                </p>
            </div>
        </div>
    );
}
