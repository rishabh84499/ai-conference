import { useState, useEffect } from 'react';
import { Bell, Check, Info, Shield, Megaphone, Trash2, CheckCircle, Radio } from 'lucide-react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { notificationApi, type Notification } from '../api/notification.api';

import { useAuth } from '@/features/auth/hooks/useAuth';
import { Button } from '@/shared/ui/Button';
import Spinner from '@/shared/ui/Spinner';
import BroadcastModal from '../components/BroadcastModal';
import { io } from 'socket.io-client';

const socketUrl = import.meta.env.VITE_SOCKET_URL || 'http://localhost:5000';

export default function NotificationsPage() {
    const [filter, setFilter] = useState<'all' | 'unread' | 'security' | 'system'>('all');
    const [isBroadcastOpen, setIsBroadcastOpen] = useState(false);
    const { user, tokens } = useAuth();
    const queryClient = useQueryClient();

    // Fetch Notifications
    const { data, isLoading, error } = useQuery({
        queryKey: ['notifications'],
        queryFn: () => notificationApi.getNotifications({ limit: 50, sortBy: 'createdAt:desc' }),
    });

    const notifications: Notification[] = data?.results || [];

    // Socket Listener
    useEffect(() => {
        if (!tokens?.access?.token) return;

        const newSocket = io(socketUrl, {
            auth: { token: tokens.access.token },
        });

        newSocket.on('notification:new', (notification: Notification) => {
            queryClient.setQueryData(['notifications'], (old: any) => {
                if (!old) return { results: [notification] };
                return { ...old, results: [notification, ...old.results] };
            });
        });

        // Listen for broadcast specific events if needed, but notification:new covers it

        return () => {
            newSocket.disconnect();
        };
    }, [tokens?.access?.token, queryClient]);

    // Mutations
    const markAllMutation = useMutation({
        mutationFn: notificationApi.markAllAsRead,
        onSuccess: () => {
            queryClient.invalidateQueries({ queryKey: ['notifications'] });
        }
    });

    // deleteMutation removed as per user request to disable individual deletion

    const deleteAllMutation = useMutation({
        mutationFn: notificationApi.deleteAllNotifications,
        onSuccess: () => {
            queryClient.invalidateQueries({ queryKey: ['notifications'] });
        }
    });

    const filteredNotifications = notifications.filter(n => {
        if (filter === 'all') return true;
        if (filter === 'unread') return !n.read;
        return n.type === filter;
    });

    const getIcon = (type: Notification['type']) => {
        switch (type) {
            case 'security': return <Shield size={20} className="text-red-400" />;
            case 'marketing': return <Megaphone size={20} className="text-blue-400" />;
            case 'activity': return <CheckCircle size={20} className="text-green-400" />;
            default: return <Info size={20} className="text-gray-400" />;
        }
    };

    const canBroadcast = user?.role === 'SuperAdmin' || user?.role === 'Admin' || user?.role === 'Manager';

    if (isLoading) {
        return (
            <div className="flex h-96 items-center justify-center">
                <Spinner size="lg" />
            </div>
        );
    }

    if (error) {
        return (
            <div className="flex h-96 items-center justify-center text-destructive">
                Failed to load notifications.
            </div>
        );
    }

    return (
        <div className="space-y-6 animate-in fade-in slide-in-from-bottom-4 duration-500">
            {/* Header */}
            <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
                <div>
                    <h1 className="text-2xl font-bold tracking-tight">Notifications</h1>
                    <p className="text-muted-foreground">Manage your alerts and activity history.</p>
                </div>
                <div className="flex gap-2">
                    {canBroadcast && (
                        <Button
                            variant="secondary"
                            onClick={() => setIsBroadcastOpen(true)}
                        >
                            <Radio size={16} className="mr-2" />
                            Broadcast
                        </Button>
                    )}
                    <Button
                        variant="outline"
                        onClick={() => markAllMutation.mutate()}
                        disabled={markAllMutation.isPending}
                    >
                        <Check size={16} className="mr-2" /> Mark all read
                    </Button>
                    <Button
                        variant="destructive"
                        onClick={() => deleteAllMutation.mutate()}
                        disabled={deleteAllMutation.isPending || notifications.length === 0}
                    >
                        <Trash2 size={16} className="mr-2" /> Clear all
                    </Button>
                </div>
            </div>

            {/* Filters */}
            <div className="flex items-center gap-2 overflow-x-auto pb-2">
                {[
                    { id: 'all', label: 'All' },
                    { id: 'unread', label: 'Unread' },
                    { id: 'security', label: 'Security' },
                    { id: 'system', label: 'System' }
                ].map((tab) => (
                    <button
                        key={tab.id}
                        onClick={() => setFilter(tab.id as typeof filter)}
                        className={`px-4 py-1.5 rounded-full text-sm font-medium transition-colors whitespace-nowrap ${filter === tab.id
                            ? 'bg-primary text-primary-foreground'
                            : 'bg-muted/50 text-muted-foreground hover:bg-muted hover:text-foreground'
                            }`}
                    >
                        {tab.label}
                    </button>
                ))}
            </div>

            {/* List */}
            <div className="rounded-xl border border-border bg-card overflow-hidden">
                {filteredNotifications.length === 0 ? (
                    <div className="p-12 text-center text-muted-foreground">
                        <Bell size={48} className="mx-auto mb-4 opacity-20" />
                        <h3 className="text-lg font-medium text-foreground">No notifications found</h3>
                        <p>You're all caught up!</p>
                    </div>
                ) : (
                    <div className="divide-y divide-border">
                        {filteredNotifications.map((notification) => (
                            <div
                                key={notification.id}
                                className={`group p-4 sm:p-6 flex gap-4 transition-colors hover:bg-muted/40 ${!notification.read ? 'bg-primary/5' : ''
                                    }`}
                            >
                                <div className="mt-1 h-10 w-10 rounded-full flex items-center justify-center bg-background border border-border shrink-0">
                                    {getIcon(notification.type)}
                                </div>

                                <div className="flex-1 min-w-0">
                                    <div className="flex items-start justify-between gap-4">
                                        <div>
                                            <h4 className={`text-base font-medium ${!notification.read ? 'text-foreground' : 'text-muted-foreground'}`}>
                                                {notification.title}
                                            </h4>
                                            <p className="text-sm text-muted-foreground mt-1">
                                                {notification.message}
                                            </p>
                                        </div>
                                        <span className="text-xs text-muted-foreground whitespace-nowrap">
                                            {/* Format date appropriately */}
                                            {new Date(notification.createdAt).toLocaleDateString()}
                                        </span>
                                    </div>
                                </div>

                                {/* Delete button removed as per user request */}
                            </div>
                        ))}
                    </div>
                )}
            </div>

            <BroadcastModal
                isOpen={isBroadcastOpen}
                onClose={() => setIsBroadcastOpen(false)}
            />
        </div>
    );
}
