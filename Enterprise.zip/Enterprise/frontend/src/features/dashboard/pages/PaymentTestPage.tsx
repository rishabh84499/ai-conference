import { useState, useEffect } from 'react';
import { paymentApi } from '@/features/payment/api/payment.api';
import toast from 'react-hot-toast';
import { CreditCard, RefreshCcw, CheckCircle, AlertCircle } from 'lucide-react';
import { ConfirmationModal } from '@/shared/ui/ConfirmationModal';

declare global {
    interface Window {
        Razorpay: any;
    }
}

const PaymentTestPage = () => {
    const [amount, setAmount] = useState<number>(100);
    const [currency, setCurrency] = useState<string>('INR');
    const [loading, setLoading] = useState<boolean>(false);
    const [orderInfo, setOrderInfo] = useState<any>(null);
    const [status, setStatus] = useState<string>('idle');
    const [transactions, setTransactions] = useState<any[]>([]);
    const [historyLoading, setHistoryLoading] = useState<boolean>(false);
    const [isRefundModalOpen, setIsRefundModalOpen] = useState(false);
    const [selectedTxId, setSelectedTxId] = useState<string | null>(null);
    const [isRefunding, setIsRefunding] = useState(false);

    useEffect(() => {
        const script = document.createElement('script');
        script.src = 'https://checkout.razorpay.com/v1/checkout.js';
        script.async = true;
        document.body.appendChild(script);

        fetchHistory();

        return () => {
            document.body.removeChild(script);
        };
    }, []);

    const fetchHistory = async () => {
        setHistoryLoading(true);
        try {
            const data = await paymentApi.getTransactions({ limit: 20 });
            setTransactions(data.results || []);
        } catch (err) {
            console.error('Failed to fetch history:', err);
        } finally {
            setHistoryLoading(false);
        }
    };

    const handleCreateOrder = async () => {
        setLoading(true);
        setStatus('creating_order');
        try {
            const data = await paymentApi.createOrder({ amount, currency });
            setOrderInfo(data);
            setStatus('order_created');
            toast.success('Order created successfully');

            const options = {
                key: import.meta.env.VITE_RAZORPAY_KEY_ID || 'rzp_test_placeholder', // Should be in env
                amount: data.order.amount,
                currency: data.order.currency,
                name: 'Enterprise Test Payment',
                description: 'Testing Payment Integration',
                order_id: data.order.id,
                handler: async (response: any) => {
                    setLoading(true);
                    setStatus('verifying');
                    try {
                        const verifiedData = await paymentApi.verifyPayment({
                            orderId: response.razorpay_order_id,
                            paymentId: response.razorpay_payment_id,
                            signature: response.razorpay_signature
                        });
                        setOrderInfo(verifiedData); // Update debug view with confirmed transaction
                        setStatus('completed');
                        toast.success('Payment verified successfully');
                        fetchHistory(); // Refresh history
                    } catch (err: any) {
                        setStatus('failed');
                        toast.error(err.message || 'Verification failed');
                    } finally {
                        setLoading(false);
                    }
                },
                prefill: {
                    name: 'Test User',
                    email: 'test@example.com'
                },
                theme: {
                    color: '#6366f1'
                }
            };

            const rzp = new window.Razorpay(options);
            rzp.on('payment.failed', (response: any) => {
                setStatus('failed');
                toast.error(response.error.description);
            });
            rzp.open();
        } catch (err: any) {
            setStatus('failed');
            toast.error(err.message || 'Failed to create order');
        } finally {
            setLoading(false);
        }
    };

    const handleRefundClick = (transactionId: string) => {
        setSelectedTxId(transactionId);
        setIsRefundModalOpen(true);
    };

    const handleConfirmRefund = async () => {
        if (!selectedTxId) return;

        setIsRefunding(true);
        try {
            const data = await paymentApi.refundPayment({ transactionId: selectedTxId });
            setOrderInfo(data);
            toast.success('Refund processed successfully');
            setIsRefundModalOpen(false);
            fetchHistory();
        } catch (err: any) {
            toast.error(err.message || 'Refund failed');
        } finally {
            setIsRefunding(false);
            setSelectedTxId(null);
        }
    };

    return (
        <div className="max-w-4xl mx-auto space-y-6">
            <header className="flex flex-col gap-2">
                <h1 className="text-3xl font-bold tracking-tight bg-gradient-to-r from-foreground to-foreground/70 bg-clip-text text-transparent">
                    Payment Integration Test
                </h1>
                <p className="text-muted-foreground">
                    Use this page to verify backend payment flows and Razorpay integration.
                </p>
            </header>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                {/* Payment Form */}
                <div className="bg-card/50 backdrop-blur-xl border border-border p-6 rounded-2xl shadow-sm space-y-4">
                    <div className="flex items-center gap-2 text-primary font-semibold">
                        <CreditCard size={20} />
                        <span>Initiate Payment</span>
                    </div>

                    <div className="space-y-4">
                        <div>
                            <label className="block text-sm font-medium mb-1.5">Amount</label>
                            <input
                                type="number"
                                value={amount}
                                onChange={(e) => setAmount(Number(e.target.value))}
                                className="w-full px-4 py-2 rounded-xl bg-background border border-border focus:ring-2 focus:ring-primary/20 outline-none transition-all"
                                placeholder="Enter amount"
                            />
                        </div>
                        <div>
                            <label className="block text-sm font-medium mb-1.5">Currency</label>
                            <select
                                value={currency}
                                onChange={(e) => setCurrency(e.target.value)}
                                className="w-full px-4 py-2 rounded-xl bg-background border border-border focus:ring-2 focus:ring-primary/20 outline-none transition-all"
                            >
                                <option value="INR">INR</option>
                                <option value="USD">USD</option>
                                <option value="GBP">GBP</option>
                                <option value="EUR">EUR</option>
                            </select>
                        </div>
                        <button
                            onClick={handleCreateOrder}
                            disabled={loading}
                            className={`w-full py-3 rounded-xl font-semibold text-white shadow-lg transition-all active:scale-95 flex items-center justify-center gap-2 ${loading
                                ? 'bg-muted text-muted-foreground cursor-not-allowed'
                                : 'bg-gradient-to-r from-indigo-500 to-purple-600 hover:shadow-indigo-500/25'
                                }`}
                        >
                            {loading ? (
                                <RefreshCcw className="animate-spin" size={20} />
                            ) : (
                                'Pay Now'
                            )}
                        </button>
                    </div>
                </div>

                {/* Status Box */}
                <div className="bg-card/50 backdrop-blur-xl border border-border p-6 rounded-2xl shadow-sm space-y-4">
                    <div className="flex items-center gap-2 text-foreground font-semibold">
                        <CheckCircle size={20} />
                        <span>Transaction Status</span>
                    </div>

                    <div className="flex flex-col items-center justify-center h-48 border-2 border-dashed border-border/50 rounded-xl bg-muted/20">
                        {status === 'idle' && (
                            <div className="text-center text-muted-foreground">
                                <p>No transaction in progress</p>
                            </div>
                        )}
                        {status === 'creating_order' && <p className="animate-pulse text-indigo-500">Creating order...</p>}
                        {status === 'order_created' && (
                            <div className="text-center space-y-2">
                                <p className="text-green-500 font-medium">Order Created!</p>
                                <p className="text-xs text-muted-foreground font-mono">{orderInfo?.transaction?._id}</p>
                            </div>
                        )}
                        {status === 'verifying' && <p className="animate-pulse text-purple-500">Verifying payment...</p>}
                        {status === 'completed' && (
                            <div className="text-center space-y-2 animate-in zoom-in duration-300">
                                <CheckCircle size={48} className="text-green-500 mx-auto" />
                                <p className="text-green-500 font-bold text-xl">Success!</p>
                                <p className="text-sm text-muted-foreground">Payment verified and recorded.</p>
                            </div>
                        )}
                        {status === 'failed' && (
                            <div className="text-center space-y-2">
                                <AlertCircle size={48} className="text-destructive mx-auto" />
                                <p className="text-destructive font-bold text-xl">Failed</p>
                                <p className="text-sm text-muted-foreground">Payment could not be completed.</p>
                            </div>
                        )}
                    </div>
                </div>
            </div>

            {/* Transaction History */}
            <div className="bg-card/50 backdrop-blur-xl border border-border rounded-2xl shadow-sm overflow-hidden">
                <div className="p-6 border-b border-border flex items-center justify-between">
                    <div className="flex items-center gap-2 text-foreground font-semibold">
                        <CreditCard size={20} className="text-primary" />
                        <span>Transaction History</span>
                    </div>
                    <button
                        onClick={fetchHistory}
                        disabled={historyLoading}
                        className="p-2 hover:bg-muted rounded-lg transition-colors"
                    >
                        <RefreshCcw size={16} className={historyLoading ? 'animate-spin' : ''} />
                    </button>
                </div>
                <div className="overflow-x-auto">
                    <table className="w-full text-left border-collapse">
                        <thead>
                            <tr className="border-b border-border bg-muted/30">
                                <th className="px-6 py-4 text-xs font-semibold uppercase tracking-wider text-muted-foreground">ID</th>
                                <th className="px-6 py-4 text-xs font-semibold uppercase tracking-wider text-muted-foreground">Amount</th>
                                <th className="px-6 py-4 text-xs font-semibold uppercase tracking-wider text-muted-foreground">Status</th>
                                <th className="px-6 py-4 text-xs font-semibold uppercase tracking-wider text-muted-foreground">Provider ID</th>
                                <th className="px-6 py-4 text-xs font-semibold uppercase tracking-wider text-muted-foreground">Date</th>
                                <th className="px-6 py-4 text-xs font-semibold uppercase tracking-wider text-muted-foreground text-right">Actions</th>
                            </tr>
                        </thead>
                        <tbody className="divide-y divide-border">
                            {historyLoading && transactions.length === 0 ? (
                                <tr>
                                    <td colSpan={5} className="px-6 py-12 text-center text-muted-foreground animate-pulse">
                                        Loading transactions...
                                    </td>
                                </tr>
                            ) : transactions.length === 0 ? (
                                <tr>
                                    <td colSpan={5} className="px-6 py-12 text-center text-muted-foreground">
                                        No transactions found.
                                    </td>
                                </tr>
                            ) : (
                                transactions.map((tx) => (
                                    <tr key={tx.id} className="hover:bg-muted/20 transition-colors">
                                        <td className="px-6 py-4 text-sm font-mono text-muted-foreground">{tx.id?.slice(-8) || 'N/A'}</td>
                                        <td className="px-6 py-4">
                                            <span className="font-semibold">
                                                {typeof tx.amount === 'object' ? tx.amount.$numberDecimal : tx.amount}
                                            </span>
                                            <span className="ml-1 text-xs text-muted-foreground">{tx.currency}</span>
                                        </td>
                                        <td className="px-6 py-4">
                                            <span className={`px-2.5 py-0.5 rounded-full text-xs font-medium ${tx.status === 'completed' ? 'bg-green-500/10 text-green-500' :
                                                tx.status === 'pending' ? 'bg-yellow-500/10 text-yellow-500' :
                                                    'bg-red-500/10 text-red-500'
                                                }`}>
                                                {tx.status}
                                            </span>
                                        </td>
                                        <td className="px-6 py-4 text-sm font-mono text-muted-foreground">
                                            {tx.providerOrderId || 'N/A'}
                                        </td>
                                        <td className="px-6 py-4 text-sm text-muted-foreground">
                                            {new Date(tx.createdAt).toLocaleString()}
                                        </td>
                                        <td className="px-6 py-4 text-right">
                                            {tx.status === 'completed' && (
                                                <button
                                                    onClick={() => handleRefundClick(tx.id)}
                                                    disabled={loading || isRefunding}
                                                    className="text-xs font-semibold text-destructive hover:underline disabled:opacity-50"
                                                >
                                                    Refund
                                                </button>
                                            )}
                                        </td>
                                    </tr>
                                ))
                            )}
                        </tbody>
                    </table>
                </div>
            </div>

            {/* Debug Info */}
            {orderInfo && (
                <div className="bg-card/30 rounded-2xl border border-border p-4 h-48 overflow-auto">
                    <h3 className="text-xs font-semibold uppercase tracking-wider text-muted-foreground mb-2">Debug JSON</h3>
                    <pre className="text-[10px] font-mono whitespace-pre-wrap">
                        {JSON.stringify(orderInfo, null, 2)}
                    </pre>
                </div>
            )}

            <ConfirmationModal
                isOpen={isRefundModalOpen}
                onClose={() => !isRefunding && setIsRefundModalOpen(false)}
                onConfirm={handleConfirmRefund}
                title="Process Refund"
                message="Are you sure you want to refund this transaction? This action will reverse the payment through Razorpay and cannot be undone."
                confirmText="Refund Transaction"
                variant="destructive"
                isLoading={isRefunding}
            />
        </div>
    );
};

export default PaymentTestPage;
