import { useState } from 'react';
import { UserRole } from '@/types/entities/user';
import {
    User,
    Bell,
    Shield,
    Monitor,
    Building2,
    CreditCard
} from 'lucide-react';
import { Can } from '@/shared/components/Can';

// Sub-components
import ProfileSettings from '@/features/dashboard/components/settings/ProfileSettings';
import SecuritySettings from '@/features/dashboard/components/settings/SecuritySettings';
import AppearanceSettings from '@/features/dashboard/components/settings/AppearanceSettings';
import NotificationSettings from '@/features/dashboard/components/settings/NotificationSettings';
import OrganizationSettings from '@/features/dashboard/components/settings/OrganizationSettings';
import BillingSettings from '@/features/dashboard/components/settings/BillingSettings';

export default function SettingsPage() {
    const [activeTab, setActiveTab] = useState('profile');

    const tabs = [
        {
            id: 'profile',
            label: 'Profile',
            icon: User,
            component: <ProfileSettings />
        },
        {
            id: 'security',
            label: 'Security',
            icon: Shield,
            component: <SecuritySettings />
        },
        {
            id: 'notifications',
            label: 'Notifications',
            icon: Bell,
            component: <NotificationSettings />
        },
        {
            id: 'appearance',
            label: 'Appearance',
            icon: Monitor,
            component: <AppearanceSettings />
        },
        {
            id: 'organization',
            label: 'Organization',
            icon: Building2,
            component: <OrganizationSettings />,
            roles: [UserRole.SUPER_ADMIN, UserRole.ADMIN]
        },
        {
            id: 'billing',
            label: 'Billing',
            icon: CreditCard,
            component: <BillingSettings />,
            roles: [UserRole.SUPER_ADMIN]
        },
    ];

    return (
        <div className="w-full space-y-8 max-w-full mx-auto">
            <div className="flex flex-col md:flex-row md:items-end justify-between gap-6">
                <div>
                    <h1 className="text-4xl font-extrabold tracking-tight text-foreground mb-2">
                        Settings
                    </h1>
                    <p className="text-lg text-muted-foreground">
                        Manage your account preferences and security.
                    </p>
                </div>

                {/* Desktop Pro Tip */}
                <div className="hidden lg:flex items-center gap-3 px-4 py-2 rounded-full bg-indigo-500/5 dark:bg-indigo-500/10 border border-indigo-500/20">
                    <span className="flex h-2 w-2 rounded-full bg-indigo-500 animate-pulse" />
                    <span className="text-xs font-bold text-indigo-600 dark:text-indigo-400 uppercase tracking-wider">Pro Tip:</span>
                    <p className="text-xs text-muted-foreground font-medium">Keep your security settings updated.</p>
                </div>
            </div>

            {/* Horizontal Navigation */}
            <div className="relative border-b border-border/50">
                <nav className="flex items-center gap-1 overflow-x-auto pb-px scrollbar-hide">
                    {tabs.map((tab) => {
                        const isActive = activeTab === tab.id;
                        const buttonContent = (
                            <button
                                onClick={() => setActiveTab(tab.id)}
                                className={`group flex items-center gap-2.5 px-6 py-4 text-sm font-bold transition-all duration-300 relative whitespace-nowrap overflow-hidden ${isActive
                                    ? 'text-indigo-600 dark:text-indigo-400'
                                    : 'text-muted-foreground hover:text-foreground hover:bg-muted/30'
                                    }`}
                            >
                                <tab.icon size={18} className={`transition-transform duration-300 ${isActive ? 'scale-110 text-indigo-500' : 'group-hover:scale-110'}`} />
                                <span className="relative z-10">{tab.label}</span>

                                {isActive && (
                                    <div className="absolute bottom-0 left-0 right-0 h-0.5 bg-gradient-to-r from-indigo-500 via-purple-500 to-cyan-500 animate-in fade-in slide-in-from-bottom-1" />
                                )}
                            </button>
                        );

                        if (tab.roles) {
                            return (
                                <Can
                                    key={tab.id}
                                    perform={tab.roles}
                                    yes={buttonContent}
                                />
                            );
                        }
                        return <div key={tab.id}>{buttonContent}</div>;
                    })}
                </nav>
            </div>

            {/* Content Area */}
            <div className="w-full pb-12">
                <div className="animate-in fade-in slide-in-from-bottom-4 duration-500">
                    {tabs.find(t => t.id === activeTab)?.component}
                </div>
            </div>
        </div>
    );
}
