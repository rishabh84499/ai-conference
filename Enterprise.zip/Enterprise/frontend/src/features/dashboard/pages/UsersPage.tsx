import { useState, useEffect } from 'react';
import { useTranslation } from 'react-i18next';
import { Button } from '@/shared/ui/Button';
import { useUsers, useUserMutations } from '@/features/dashboard/hooks/useUsers';
import { useAuth } from '@/features/auth/hooks/useAuth';
import { type User, UserStatus } from '@/features/dashboard/types/user';
import { useDebounce } from '@/shared/hooks/useDebounce';
import { CreateUserModal } from '../components/CreateUserModal';
import { EditUserModal } from '../components/EditUserModal';
import { ViewUserModal } from '../components/ViewUserModal';
import { ResetPasswordModal } from '../components/ResetPasswordModal';
import { DeleteUserModal } from '../components/DeleteUserModal';
import { UsersTable } from '../components/UsersTable';
import { UsersToolbar } from '../components/UsersToolbar';

export default function UsersPage() {
    const { t } = useTranslation();
    const { user: currentUser } = useAuth();
    const [searchTerm, setSearchTerm] = useState('');
    const debouncedSearch = useDebounce(searchTerm, 300);
    const [page, setPage] = useState(1);

    // React Query Hooks
    const { data: usersData, isLoading, refetch } = useUsers({
        page,
        limit: 10,
        search: debouncedSearch,
    });

    // Reset page when search changes
    useEffect(() => {
        setPage(1);
    }, [debouncedSearch]);

    const { deleteUser, changeStatus } = useUserMutations();

    // Modal States
    const [isCreateModalOpen, setIsCreateModalOpen] = useState(false);
    const [isEditModalOpen, setIsEditModalOpen] = useState(false);
    const [isViewModalOpen, setIsViewModalOpen] = useState(false);
    const [isResetPasswordModalOpen, setIsResetPasswordModalOpen] = useState(false);
    const [isDeleteModalOpen, setIsDeleteModalOpen] = useState(false);
    const [selectedUser, setSelectedUser] = useState<User | null>(null);

    const rawUsers = usersData?.data?.results || [];
    const users = currentUser ? rawUsers.filter(u => u._id !== currentUser._id) : rawUsers;
    const totalPages = usersData?.data?.totalPages || 1;

    const handleChangeStatus = (userId: string, status: UserStatus) => {
        changeStatus.mutate({ id: userId, status });
    };

    const handleDeleteUser = async () => {
        if (!selectedUser) return;
        try {
            await deleteUser.mutateAsync(selectedUser._id);
            setIsDeleteModalOpen(false);
        } catch (error) {
            // Error handled by mutation hook
        }
    };

    // Action Handlers
    const handleEdit = (user: User) => {
        setSelectedUser(user);
        setIsEditModalOpen(true);
    };

    const handleView = (user: User) => {
        setSelectedUser(user);
        setIsViewModalOpen(true);
    };

    const handleResetPassword = (user: User) => {
        setSelectedUser(user);
        setIsResetPasswordModalOpen(true);
    };

    const handleDeleteClick = (user: User) => {
        setSelectedUser(user);
        setIsDeleteModalOpen(true);
    };

    return (
        <div className="space-y-6">
            <UsersToolbar
                searchTerm={searchTerm}
                onSearchChange={setSearchTerm}
                onRefresh={() => refetch()}
                onAddUser={() => setIsCreateModalOpen(true)}
                isLoading={isLoading}
            />

            <UsersTable
                users={users}
                isLoading={isLoading}
                onEdit={handleEdit}
                onView={handleView}
                onResetPassword={handleResetPassword}
                onDelete={handleDeleteClick}
                onChangeStatus={handleChangeStatus}
            />

            {/* Pagination (Simple) */}
            <div className="flex justify-end gap-2">
                <Button
                    variant="outline"
                    size="sm"
                    onClick={() => setPage(p => Math.max(1, p - 1))}
                    disabled={page === 1 || isLoading}
                >
                    {t('common.previous')}
                </Button>
                <div className="flex items-center px-2 text-sm text-muted-foreground">
                    {t('common.page_info', { page, total: totalPages })}
                </div>
                <Button
                    variant="outline"
                    size="sm"
                    onClick={() => setPage(p => Math.min(totalPages, p + 1))}
                    disabled={page === totalPages || isLoading}
                >
                    {t('common.next')}
                </Button>
            </div>

            <CreateUserModal
                isOpen={isCreateModalOpen}
                onClose={() => setIsCreateModalOpen(false)}
                onSuccess={() => setIsCreateModalOpen(false)}
            />

            <EditUserModal
                isOpen={isEditModalOpen}
                onClose={() => setIsEditModalOpen(false)}
                onSuccess={() => setIsEditModalOpen(false)}
                user={selectedUser}
            />

            <ViewUserModal
                isOpen={isViewModalOpen}
                onClose={() => setIsViewModalOpen(false)}
                user={selectedUser}
            />

            <ResetPasswordModal
                isOpen={isResetPasswordModalOpen}
                onClose={() => setIsResetPasswordModalOpen(false)}
                userId={selectedUser?._id || ''}
                userName={`${selectedUser?.firstName} ${selectedUser?.lastName}`}
            />

            <DeleteUserModal
                isOpen={isDeleteModalOpen}
                onClose={() => setIsDeleteModalOpen(false)}
                onConfirm={handleDeleteUser}
                userName={`${selectedUser?.firstName || ''} ${selectedUser?.lastName || ''}`}
                userEmail={selectedUser?.email || ''}
            />
        </div>
    );
}
