import { useState, useEffect } from 'react';
import { useSocketContext } from '@/core/context/SocketContext';
import { CallService } from '@/core/services/CallService';
import type { AgoraTokenResponse } from '@/core/services/CallService';
import toast from 'react-hot-toast';
import { Video, Phone, PhoneOff, User, Terminal, Shield } from 'lucide-react';

interface SignalingEvent {
    time: string;
    event: string;
    data: any;
}

const VideoCallTestPage = () => {
    const { socket, isConnected, emitCall, emitAnswer, emitRejectCall, emitEndCall } = useSocketContext();
    const [channelName, setChannelName] = useState('test-room');
    const [targetUserId, setTargetUserId] = useState('');
    const [tokenData, setTokenData] = useState<AgoraTokenResponse | null>(null);
    const [events, setEvents] = useState<SignalingEvent[]>([]);
    const [loading, setLoading] = useState(false);

    const addEvent = (event: string, data: any) => {
        setEvents(prev => [{
            time: new Date().toLocaleTimeString(),
            event,
            data
        }, ...prev].slice(0, 50));
    };

    useEffect(() => {
        if (!socket) return;

        const handlers = {
            'call-made': (data: any) => addEvent('CALL_RECEIVED (call-made)', data),
            'answer-made': (data: any) => addEvent('ANSWER_RECEIVED (answer-made)', data),
            'call-rejected': (data: any) => addEvent('CALL_REJECTED', data),
            'call-ended': (data: any) => addEvent('CALL_ENDED', data),
        };

        Object.entries(handlers).forEach(([event, handler]) => {
            socket.on(event, handler);
        });

        return () => {
            Object.entries(handlers).forEach(([event, handler]) => {
                socket.off(event, handler);
            });
        };
    }, [socket]);

    const handleGetToken = async () => {
        setLoading(true);
        try {
            const data = await CallService.getToken(channelName);
            setTokenData(data);
            toast.success('Agora token generated');
            addEvent('TOKEN_FETCHED', data);
        } catch (error: any) {
            toast.error(error.message || 'Failed to fetch token');
        } finally {
            setLoading(false);
        }
    };

    const handleStartCall = () => {
        if (!targetUserId) return toast.error('Target User ID is required');
        const offer = { type: 'offer', sdp: 'dummy-sdp-for-testing' };
        emitCall(targetUserId, offer, channelName);
        addEvent('CALL_INITIATED (call-user)', { to: targetUserId, channelName });
        toast(`Calling ${targetUserId}...`, { icon: '📞' });
    };

    const handleAcceptCall = () => {
        if (!targetUserId) return toast.error('Target User ID is required to reply');
        const answer = { type: 'answer', sdp: 'dummy-sdp-answer-for-testing' };
        emitAnswer(targetUserId, answer);
        addEvent('ANSWER_SENT (make-answer)', { to: targetUserId });
        toast.success(`Accepted call from ${targetUserId}`);
    };

    const handleRejectCall = () => {
        if (!targetUserId) return toast.error('Target User ID is required');
        emitRejectCall(targetUserId);
        addEvent('REJECT_SENT (reject-call)', { to: targetUserId });
        toast.error(`Rejected call from ${targetUserId}`);
    };

    const handleEndCall = () => {
        if (!targetUserId) return toast.error('Target User ID is required');
        emitEndCall(targetUserId);
        addEvent('END_SENT (end-call)', { to: targetUserId });
        toast(`Ended call for ${targetUserId}`, { icon: '🛑' });
    };

    return (
        <div className="max-w-5xl mx-auto space-y-6">
            <header className="flex flex-col gap-2">
                <h1 className="text-3xl font-bold tracking-tight bg-gradient-to-r from-indigo-400 to-purple-500 bg-clip-text text-transparent">
                    Video Call Integration Test
                </h1>
                <p className="text-muted-foreground">
                    Simulate video calling signaling and verify Agora token generation.
                </p>
            </header>

            <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
                {/* Configuration Panel */}
                <div className="lg:col-span-12 grid grid-cols-1 md:grid-cols-3 gap-6">
                    <div className="bg-card/50 backdrop-blur-xl border border-border p-6 rounded-2xl shadow-sm space-y-4">
                        <div className="flex items-center gap-2 text-primary font-semibold">
                            <Shield size={18} />
                            <span>1. Fetch Agora Token</span>
                        </div>
                        <div className="space-y-3">
                            <div>
                                <label className="text-xs font-medium text-muted-foreground uppercase">Channel Name</label>
                                <input
                                    type="text"
                                    value={channelName}
                                    onChange={(e) => setChannelName(e.target.value)}
                                    className="w-full mt-1 px-3 py-2 rounded-lg bg-background border border-border focus:ring-2 focus:ring-primary/20 outline-none transition-all"
                                />
                            </div>
                            <button
                                onClick={handleGetToken}
                                disabled={loading}
                                className="w-full py-2 bg-primary text-primary-foreground rounded-lg font-medium hover:opacity-90 transition-all disabled:opacity-50"
                            >
                                {loading ? 'Fetching...' : 'Get Token'}
                            </button>
                        </div>
                    </div>

                    <div className="bg-card/50 backdrop-blur-xl border border-border p-6 rounded-2xl shadow-sm space-y-4">
                        <div className="flex items-center gap-2 text-indigo-500 font-semibold">
                            <User size={18} />
                            <span>2. Target User</span>
                        </div>
                        <div className="space-y-3">
                            <div>
                                <label className="text-xs font-medium text-muted-foreground uppercase">Target User ID</label>
                                <input
                                    type="text"
                                    value={targetUserId}
                                    placeholder="Paste destination user ID"
                                    onChange={(e) => setTargetUserId(e.target.value)}
                                    className="w-full mt-1 px-3 py-2 rounded-lg bg-background border border-border focus:ring-2 focus:ring-indigo-500/20 outline-none transition-all"
                                />
                            </div>
                            <div className="flex items-center gap-2">
                                <div className={`w-3 h-3 rounded-full ${isConnected ? 'bg-green-500' : 'bg-red-500'}`} />
                                <span className="text-sm font-medium">{isConnected ? 'Socket Connected' : 'Socket Disconnected'}</span>
                            </div>
                        </div>
                    </div>

                    <div className="bg-card/50 backdrop-blur-xl border border-border p-6 rounded-2xl shadow-sm space-y-4">
                        <div className="flex items-center gap-2 text-purple-500 font-semibold">
                            <Video size={18} />
                            <span>3. Call Actions</span>
                        </div>
                        <div className="grid grid-cols-2 gap-2">
                            <button
                                onClick={handleStartCall}
                                className="flex items-center justify-center gap-2 p-2 bg-green-500/10 text-green-500 border border-green-500/20 rounded-lg hover:bg-green-500/20 transition-all font-medium"
                            >
                                <Video size={16} /> Call
                            </button>
                            <button
                                onClick={handleAcceptCall}
                                className="flex items-center justify-center gap-2 p-2 bg-indigo-500/10 text-indigo-500 border border-indigo-500/20 rounded-lg hover:bg-indigo-500/20 transition-all font-medium"
                            >
                                <Phone size={16} /> Answer
                            </button>
                            <button
                                onClick={handleRejectCall}
                                className="flex items-center justify-center gap-2 p-2 bg-red-500/10 text-red-500 border border-red-500/20 rounded-lg hover:bg-red-500/20 transition-all font-medium"
                            >
                                <PhoneOff size={16} /> Reject
                            </button>
                            <button
                                onClick={handleEndCall}
                                className="flex items-center justify-center gap-2 p-2 bg-gray-500/10 text-gray-500 border border-gray-500/20 rounded-lg hover:bg-gray-500/20 transition-all font-medium"
                            >
                                <PhoneOff size={16} /> End
                            </button>
                        </div>
                    </div>
                </div>

                {/* Token Display */}
                <div className="lg:col-span-4 bg-card/50 backdrop-blur-xl border border-border p-6 rounded-2xl shadow-sm space-y-4">
                    <div className="flex items-center gap-2 text-foreground font-semibold">
                        <Shield size={18} className="text-primary" />
                        <span>Token Response</span>
                    </div>
                    {tokenData ? (
                        <div className="space-y-4">
                            <div className="p-3 bg-muted/50 rounded-lg overflow-hidden">
                                <label className="text-[10px] font-bold text-muted-foreground uppercase block mb-1">Generated Token</label>
                                <p className="text-[10px] font-mono break-all text-foreground/80 leading-relaxed">
                                    {tokenData.token}
                                </p>
                            </div>
                            <div className="grid grid-cols-2 gap-2 text-xs">
                                <div>
                                    <span className="text-muted-foreground">UID:</span>
                                    <span className="ml-1 font-mono font-bold">{tokenData.uid}</span>
                                </div>
                                <div>
                                    <span className="text-muted-foreground">Channel:</span>
                                    <span className="ml-1 font-mono font-bold">{tokenData.channelName}</span>
                                </div>
                            </div>
                        </div>
                    ) : (
                        <div className="flex flex-col items-center justify-center h-32 border border-dashed border-border rounded-xl text-muted-foreground text-sm italic">
                            No token fetched yet
                        </div>
                    )}
                </div>

                {/* Event Log */}
                <div className="lg:col-span-8 bg-card/50 backdrop-blur-xl border border-border p-6 rounded-2xl shadow-sm space-y-4">
                    <div className="flex items-center justify-between">
                        <div className="flex items-center gap-2 text-foreground font-semibold">
                            <Terminal size={18} className="text-primary" />
                            <span>Signaling Event Log</span>
                        </div>
                        <button
                            onClick={() => setEvents([])}
                            className="text-xs text-muted-foreground hover:text-foreground underline transition-colors"
                        >
                            Clear
                        </button>
                    </div>
                    <div className="bg-muted/30 rounded-xl overflow-y-auto h-[350px] border border-border scrollbar-thin scrollbar-thumb-border">
                        {events.length === 0 ? (
                            <div className="flex flex-col items-center justify-center h-full text-muted-foreground text-sm italic py-10">
                                Waiting for signals...
                            </div>
                        ) : (
                            <div className="divide-y divide-border">
                                {events.map((ev, i) => (
                                    <div key={i} className="p-3 hover:bg-muted/50 transition-colors animate-in slide-in-from-top-1 duration-200">
                                        <div className="flex items-center justify-between mb-1">
                                            <span className="text-[10px] font-bold text-primary px-1.5 py-0.5 bg-primary/10 rounded uppercase">
                                                {ev.event}
                                            </span>
                                            <span className="text-[10px] text-muted-foreground font-mono">{ev.time}</span>
                                        </div>
                                        <pre className="text-[10px] font-mono text-foreground/70 overflow-x-auto">
                                            {JSON.stringify(ev.data, null, 2)}
                                        </pre>
                                    </div>
                                ))}
                            </div>
                        )}
                    </div>
                </div>
            </div>
        </div>
    );
};

export default VideoCallTestPage;
