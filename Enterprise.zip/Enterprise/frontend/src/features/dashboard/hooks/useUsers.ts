import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { AxiosError } from 'axios';
import { userService } from '@/features/dashboard/api/user.service';
import type { UserFilters, CreateUserRequest, UpdateUserRequest, UserStatus } from '@/features/dashboard/types/user';
import toast from 'react-hot-toast';

interface ApiErrorResponse {
    message: string;
}

export const USER_KEYS = {
    all: ['users'] as const,
    lists: () => [...USER_KEYS.all, 'list'] as const,
    list: (filters: UserFilters) => [...USER_KEYS.lists(), filters] as const,
    details: () => [...USER_KEYS.all, 'detail'] as const,
    detail: (id: string) => [...USER_KEYS.details(), id] as const,
};

export function useUsers(filters: UserFilters) {
    return useQuery({
        queryKey: USER_KEYS.list(filters),
        queryFn: () => userService.getUsers(filters),
        placeholderData: (previousData) => previousData, // Keep previous data while fetching new page
    });
}

export function useUser(id: string) {
    return useQuery({
        queryKey: USER_KEYS.detail(id),
        queryFn: () => userService.getUser(id),
        enabled: !!id,
    });
}

export function useUserMutations() {
    const queryClient = useQueryClient();

    const createUser = useMutation({
        mutationFn: (data: CreateUserRequest) => userService.createUser(data),
        onSuccess: () => {
            queryClient.invalidateQueries({ queryKey: USER_KEYS.lists() });
            toast.success('User created successfully');
        },
        onError: (error: AxiosError<ApiErrorResponse>) => {
            toast.error(error.response?.data?.message || 'Failed to create user');
        },
    });

    const updateUser = useMutation({
        mutationFn: ({ id, data }: { id: string; data: UpdateUserRequest }) =>
            userService.updateUser(id, data),
        onSuccess: (data) => {
            queryClient.invalidateQueries({ queryKey: USER_KEYS.lists() });
            queryClient.invalidateQueries({ queryKey: USER_KEYS.detail(data._id) });
            toast.success('User updated successfully');
        },
        onError: (error: AxiosError<ApiErrorResponse>) => {
            toast.error(error.response?.data?.message || 'Failed to update user');
        },
    });

    const deleteUser = useMutation({
        mutationFn: (id: string) => userService.deleteUser(id),
        onSuccess: () => {
            queryClient.invalidateQueries({ queryKey: USER_KEYS.lists() });
            toast.success('User deleted successfully');
        },
        onError: (error: AxiosError<ApiErrorResponse>) => {
            toast.error(error.response?.data?.message || 'Failed to delete user');
        },
    });

    const changeStatus = useMutation({
        mutationFn: ({ id, status }: { id: string; status: UserStatus }) =>
            userService.changeStatus(id, status),
        onSuccess: (data) => {
            queryClient.invalidateQueries({ queryKey: USER_KEYS.lists() });
            queryClient.invalidateQueries({ queryKey: USER_KEYS.detail(data._id) });
            toast.success(`User status updated to ${data.status}`);
        },
        onError: (error: AxiosError<ApiErrorResponse>) => {
            toast.error(error.response?.data?.message || 'Failed to update status');
        },
    });

    const resetPassword = useMutation({
        mutationFn: ({ id, password }: { id: string; password: string }) =>
            userService.resetPassword(id, password),
        onSuccess: () => {
            toast.success('Password reset successfully');
        },
        onError: (error: AxiosError<ApiErrorResponse>) => {
            toast.error(error.response?.data?.message || 'Failed to reset password');
        },
    });

    return {
        createUser,
        updateUser,
        deleteUser,
        changeStatus,
        resetPassword,
    };
}
