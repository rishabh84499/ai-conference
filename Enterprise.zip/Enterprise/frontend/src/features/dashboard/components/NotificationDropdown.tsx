import { useState, useRef, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { Bell, Check, Shield, Megaphone } from 'lucide-react';
import { useSocket } from '@/shared/hooks/useSocket';
import { NotificationService } from '@/core/services/NotificationService';
import type { Notification } from '@/core/services/NotificationService';
import toast from 'react-hot-toast';

export default function NotificationDropdown() {
    const navigate = useNavigate();
    const [isOpen, setIsOpen] = useState(false);
    const [notifications, setNotifications] = useState<Notification[]>([]);
    const [loading, setLoading] = useState(false);
    const dropdownRef = useRef<HTMLDivElement>(null);
    const { socket } = useSocket();

    const unreadCount = notifications.filter(n => !n.read).length;

    const fetchNotifications = async () => {
        try {
            setLoading(true);
            const data = await NotificationService.getAll({ limit: 4, sortBy: 'createdAt:desc' });
            setNotifications(data.results);
        } catch (error) {
            console.error('Failed to fetch notifications', error);
        } finally {
            setLoading(false);
        }
    };

    useEffect(() => {
        fetchNotifications();
    }, []);

    useEffect(() => {
        if (!socket) return;

        const handleNewNotification = (notification: Notification) => {
            setNotifications(prev => [notification, ...prev]);
            toast.custom((t) => (
                <div
                    className={`${t.visible ? 'animate-enter' : 'animate-leave'
                        } max-w-md w-full bg-white dark:bg-zinc-900 shadow-lg rounded-lg pointer-events-auto flex ring-1 ring-black ring-opacity-5`}
                >
                    <div className="flex-1 w-0 p-4">
                        <div className="flex items-start">
                            <div className="flex-shrink-0 pt-0.5">
                                <div className="h-10 w-10 rounded-full bg-gradient-to-br from-indigo-500/20 to-purple-500/20 flex items-center justify-center border border-indigo-500/20">
                                    <Bell className="h-5 w-5 text-indigo-500 dark:text-indigo-400" />
                                </div>
                            </div>
                            <div className="ml-3 flex-1">
                                <p className="text-sm font-medium text-gray-900 dark:text-gray-100">
                                    {notification.title}
                                </p>
                                <p className="mt-1 text-sm text-gray-500 dark:text-gray-400">
                                    {notification.message}
                                </p>
                            </div>
                        </div>
                    </div>
                </div>
            ));
        };

        socket.on('notification:new', handleNewNotification);

        return () => {
            socket.off('notification:new', handleNewNotification);
        };
    }, [socket]);

    // Close dropdown when clicking outside
    useEffect(() => {
        function handleClickOutside(event: MouseEvent) {
            if (dropdownRef.current && !dropdownRef.current.contains(event.target as Node)) {
                setIsOpen(false);
            }
        }
        document.addEventListener('mousedown', handleClickOutside);
        return () => document.removeEventListener('mousedown', handleClickOutside);
    }, []);

    const markAsRead = async (id: string, e: React.MouseEvent) => {
        e.stopPropagation();
        try {
            await NotificationService.markAsRead(id);
            setNotifications(prev => prev.map(n => n.id === id ? { ...n, read: true } : n));
        } catch (error) {
            console.error('Failed to mark as read', error);
        }
    };



    const getIconData = (type: Notification['type']) => {
        switch (type) {
            case 'security':
                return {
                    icon: <Shield size={16} />,
                    className: "text-amber-500 dark:text-amber-400",
                    bg: "bg-amber-500/10 border-amber-500/20"
                };
            case 'marketing':
                return {
                    icon: <Megaphone size={16} />,
                    className: "text-purple-500 dark:text-purple-400",
                    bg: "bg-purple-500/10 border-purple-500/20"
                };
            case 'activity':
                return {
                    icon: <Check size={16} />,
                    className: "text-emerald-500 dark:text-emerald-400",
                    bg: "bg-emerald-500/10 border-emerald-500/20"
                };
            case 'system':
                return {
                    icon: <Bell size={16} />,
                    className: "text-blue-500 dark:text-blue-400",
                    bg: "bg-blue-500/10 border-blue-500"
                };
            default:
                return {
                    icon: <Bell size={16} />,
                    className: "text-blue-500 dark:text-blue-400",
                    bg: "bg-blue-500/10 border-blue-500/20"
                };
        }
    };

    const formatTime = (dateString: string) => {
        const date = new Date(dateString);
        const now = new Date();
        const diffInSeconds = Math.floor((now.getTime() - date.getTime()) / 1000);

        if (diffInSeconds < 60) return `${diffInSeconds}s ago`;
        if (diffInSeconds < 3600) return `${Math.floor(diffInSeconds / 60)}m ago`;
        if (diffInSeconds < 86400) return `${Math.floor(diffInSeconds / 3600)}h ago`;
        return `${Math.floor(diffInSeconds / 86400)}d ago`;
    };

    return (
        <div className="relative" ref={dropdownRef}>
            <button
                onClick={() => setIsOpen(!isOpen)}
                className="relative p-2 rounded-lg hover:bg-white/5 transition-colors text-muted-foreground hover:text-foreground"
            >
                <Bell size={20} />
                {unreadCount > 0 && (
                    <span className="absolute top-1.5 right-1.5 h-2.5 w-2.5 rounded-full bg-gradient-to-br from-indigo-500 to-purple-500 ring-2 ring-background animate-pulse" />
                )}
            </button>

            {isOpen && (
                <div className="absolute right-0 mt-2 w-80 md:w-96 rounded-xl border border-border bg-popover shadow-xl z-50 animate-in fade-in zoom-in-95 duration-200 overflow-hidden">
                    <div className="flex items-center justify-between p-4 border-b border-border bg-muted/30">
                        <h3 className="font-semibold text-foreground">Notifications</h3>
                    </div>

                    <div className="max-h-[400px] overflow-y-auto">
                        {loading && notifications.length === 0 ? (
                            <div className="p-8 text-center text-muted-foreground">
                                <span className="animate-spin inline-block mr-2">⟳</span> Loading...
                            </div>
                        ) : notifications.length === 0 ? (
                            <div className="p-8 text-center text-muted-foreground">
                                <Bell size={32} className="mx-auto mb-3 opacity-20" />
                                <p className="text-sm">No notifications</p>
                            </div>
                        ) : (
                            <div className="divide-y divide-border">
                                {notifications.map((notification) => {
                                    const iconData = getIconData(notification.type);
                                    return (
                                        <div
                                            key={notification.id}
                                            onClick={(e) => {
                                                if (!notification.read) {
                                                    markAsRead(notification.id, e);
                                                }
                                                setIsOpen(false);
                                                navigate('/dashboard/notifications');
                                            }}
                                            className={`relative group p-4 hover:bg-muted/50 transition-colors cursor-pointer ${!notification.read ? 'bg-primary/5' : ''
                                                }`}
                                        >
                                            <div className="flex gap-3">
                                                <div className={`mt-1 h-8 w-8 rounded-full flex items-center justify-center shrink-0 border ${iconData.bg} ${iconData.className}`}>
                                                    {iconData.icon}
                                                </div>
                                                <div className="flex-1 space-y-1">
                                                    <div className="flex items-start justify-between gap-2">
                                                        <p className={`text-sm font-medium leading-none ${!notification.read ? 'text-foreground' : 'text-muted-foreground'
                                                            }`}>
                                                            {notification.title}
                                                        </p>
                                                        <span className="text-[10px] text-muted-foreground whitespace-nowrap">
                                                            {formatTime(notification.createdAt)}
                                                        </span>
                                                    </div>
                                                    <p className="text-xs text-muted-foreground line-clamp-2">
                                                        {notification.message}
                                                    </p>
                                                </div>

                                            </div>
                                        </div>
                                    );
                                })}
                            </div >
                        )
                        }
                    </div >

                    <div className="p-2 border-t border-border bg-muted/30 text-center">
                        <button
                            onClick={() => {
                                setIsOpen(false);
                                navigate('/dashboard/notifications');
                            }}
                            className="text-xs text-muted-foreground hover:text-foreground transition-colors w-full py-1"
                        >
                            View all notifications
                        </button>
                    </div>
                </div >
            )}
        </div >
    );
}
