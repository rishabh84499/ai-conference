import { Modal } from '@/shared/ui/Modal';
import { Button } from '@/shared/ui/Button';
import type { User } from '@/features/dashboard/types/user';
import { UserCheck, Mail, Shield, Calendar } from 'lucide-react';

interface ViewUserModalProps {
    isOpen: boolean;
    onClose: () => void;
    user: User | null;
}

export function ViewUserModal({ isOpen, onClose, user }: ViewUserModalProps) {
    if (!user) return null;

    return (
        <Modal
            isOpen={isOpen}
            onClose={onClose}
            title="User Details"
            maxWidth="lg"
        >
            <div className="space-y-6">
                {/* User Header */}
                <div className="flex items-center gap-4 pb-6 border-b border-border/50">
                    <div className="w-16 h-16 rounded-full bg-gradient-to-br from-indigo-500/20 to-purple-500/20 flex items-center justify-center text-2xl font-bold text-indigo-500 dark:text-indigo-400 border border-indigo-500/20 shadow-sm">
                        {(user.firstName || '?')[0]}{(user.lastName || '')[0]}
                    </div>
                    <div>
                        <h3 className="text-2xl font-bold text-foreground">{user.firstName} {user.lastName}</h3>
                        <p className="text-muted-foreground">{user.email}</p>
                    </div>
                </div>

                {/* User Info Grid */}
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <div className="space-y-2">
                        <div className="flex items-center gap-2 text-sm text-muted-foreground font-semibold uppercase tracking-wider">
                            <Shield className="h-4 w-4 text-indigo-500" />
                            <span>Role</span>
                        </div>
                        <p className="text-lg font-medium capitalize text-foreground">{user.role}</p>
                    </div>

                    <div className="space-y-2">
                        <div className="flex items-center gap-2 text-sm text-muted-foreground font-semibold uppercase tracking-wider">
                            <UserCheck className="h-4 w-4 text-indigo-500" />
                            <span>Status</span>
                        </div>
                        <div className="flex items-center gap-2">
                            <span className={`h-2 w-2 rounded-full ${user.status === 'active' ? 'bg-emerald-500' : 'bg-gray-500'
                                }`} />
                            <p className="text-lg font-medium capitalize text-foreground">{user.status}</p>
                        </div>
                    </div>

                    <div className="space-y-2">
                        <div className="flex items-center gap-2 text-sm text-muted-foreground font-semibold uppercase tracking-wider">
                            <Mail className="h-4 w-4 text-indigo-500" />
                            <span>Email</span>
                        </div>
                        <p className="text-lg font-medium text-foreground break-all">{user.email}</p>
                    </div>

                    <div className="space-y-2">
                        <div className="flex items-center gap-2 text-sm text-muted-foreground font-semibold uppercase tracking-wider">
                            <Calendar className="h-4 w-4 text-indigo-500" />
                            <span>Created</span>
                        </div>
                        <p className="text-lg font-medium text-foreground">
                            {new Date(user.createdAt).toLocaleDateString()}
                        </p>
                    </div>
                </div>

                {/* Actions */}
                <div className="flex justify-end gap-3 pt-4 border-t border-border/50">
                    <Button variant="outline" onClick={onClose}>
                        Close
                    </Button>
                </div>
            </div>
        </Modal>
    );
}
