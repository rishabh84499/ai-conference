import { useState } from 'react';

import { Modal } from '@/shared/ui/Modal';
import { Button } from '@/shared/ui/Button';
import { Input } from '@/shared/ui/Input';
import { Textarea } from '@/shared/ui/Textarea';
import { Select } from '@/shared/ui/Select';
import { useMutation } from '@tanstack/react-query';
import { notificationApi, type BroadcastRequest } from '../api/notification.api';

import toast from 'react-hot-toast';
import { Loader2 } from 'lucide-react';

interface BroadcastModalProps {
    isOpen: boolean;
    onClose: () => void;
}

export default function BroadcastModal({ isOpen, onClose }: BroadcastModalProps) {
    const [title, setTitle] = useState('');
    const [message, setMessage] = useState('');
    const [type, setType] = useState<BroadcastRequest['type']>('system');

    const { mutate: broadcast, isPending } = useMutation({
        mutationFn: notificationApi.broadcastNotification,
        onSuccess: () => {
            toast.success('Broadcast started successfully');
            // Reset form
            setTitle('');
            setMessage('');
            setType('system');
            onClose();
        },
        onError: (error: any) => {
            const msg = error?.response?.data?.message || 'Failed to broadcast notification';
            toast.error(msg);
        }
    });

    const handleSubmit = (e: React.FormEvent) => {
        e.preventDefault();
        if (!title.trim() || !message.trim()) return;

        broadcast({
            title,
            message,
            type
        });
    };

    return (
        <Modal
            isOpen={isOpen}
            onClose={onClose}
            title="Broadcast Notification"
            description="Send a real-time notification to all active users in the system."
        >
            <form onSubmit={handleSubmit} className="space-y-4">
                <Select
                    label="Type"
                    value={type}
                    onChange={(e) => setType(e.target.value as any)}
                    options={[
                        { value: 'system', label: 'System' },
                        { value: 'security', label: 'Security' },
                        { value: 'marketing', label: 'Marketing' },
                        { value: 'activity', label: 'Activity' },
                    ]}
                />

                <Input
                    label="Title"
                    value={title}
                    onChange={(e) => setTitle(e.target.value)}
                    placeholder="e.g., System Maintenance"
                    required
                    minLength={3}
                    maxLength={100}
                />

                <Textarea
                    label="Message"
                    value={message}
                    onChange={(e) => setMessage(e.target.value)}
                    placeholder="Enter the notification message..."
                    required
                    minLength={10}
                    maxLength={1000}
                    rows={4}
                />

                <div className="flex justify-end gap-3 pt-4">
                    <Button type="button" variant="outline" onClick={onClose} disabled={isPending}>
                        Cancel
                    </Button>
                    <Button type="submit" disabled={isPending} isLoading={isPending}>
                        Send Broadcast
                    </Button>
                </div>
            </form>
        </Modal>
    );
}

