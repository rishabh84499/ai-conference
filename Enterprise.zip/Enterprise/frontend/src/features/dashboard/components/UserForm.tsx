import { useState, useEffect } from 'react';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { z } from 'zod';
import { Button } from '@/shared/ui/Button';
import { Input } from '@/shared/ui/Input';
import { Label } from '@/shared/ui/Label';
import { UserRole } from '@/features/dashboard/types/user';
import { Eye, EyeOff } from 'lucide-react';
import { VALIDATION } from '@/shared/constants/validation';

// Common Schema Definitions
const nameSchema = z.string()
    .min(VALIDATION.NAME.MIN_LENGTH, `Must be at least ${VALIDATION.NAME.MIN_LENGTH} characters`)
    .max(VALIDATION.NAME.MAX_LENGTH, `Cannot exceed ${VALIDATION.NAME.MAX_LENGTH} characters`);

const roleSchema = z.nativeEnum(UserRole);

// Mode-specific schemas
export const createUserFormSchema = z.object({
    firstName: nameSchema,
    lastName: nameSchema,
    email: z.string().email(VALIDATION.EMAIL.MESSAGE),
    password: z.string()
        .min(8, 'Password must be at least 8 characters')
        .regex(VALIDATION.PASSWORD.REGEX, VALIDATION.PASSWORD.MESSAGE),
    role: roleSchema,
});

export const editUserFormSchema = z.object({
    firstName: nameSchema,
    lastName: nameSchema,
    role: roleSchema,
    email: z.string().email(VALIDATION.EMAIL.MESSAGE),
    // Email is read-only in edit mode but required for form state
});

export type CreateUserFormValues = z.infer<typeof createUserFormSchema>;
export type EditUserFormValues = z.infer<typeof editUserFormSchema>;

// Discriminated Union for Form Props
type BaseUserFormProps = {
    isLoading: boolean;
    onCancel: () => void;
    serverErrors?: Record<string, string>;
};

type CreateModeProps = BaseUserFormProps & {
    mode: 'create';
    defaultValues?: Partial<CreateUserFormValues>;
    onSubmit: (data: CreateUserFormValues) => Promise<void>;
};

type EditModeProps = BaseUserFormProps & {
    mode: 'edit';
    defaultValues?: Partial<EditUserFormValues>;
    onSubmit: (data: EditUserFormValues) => Promise<void>;
};

type UserFormProps = CreateModeProps | EditModeProps;

export function UserForm(props: UserFormProps) {
    const { mode, defaultValues, onSubmit, isLoading, onCancel, serverErrors } = props;
    const [showPassword, setShowPassword] = useState(false);

    const schema = mode === 'create' ? createUserFormSchema : editUserFormSchema;

    const {
        register,
        handleSubmit,
        setError,
        formState: { errors },
        reset,
    } = useForm<CreateUserFormValues | EditUserFormValues>({
        // eslint-disable-next-line @typescript-eslint/no-explicit-any
        resolver: zodResolver(schema) as any, // Resolver type mismatch with union types is a known extensive issue, safe to cast here only
        defaultValues: {
            firstName: '',
            lastName: '',
            role: UserRole.OPERATOR,
            email: '',
            ...(mode === 'create' ? { password: '' } : {}),
            ...defaultValues,
        },
    });

    // Reset form when defaultValues change
    useEffect(() => {
        if (defaultValues) {
            reset({
                firstName: defaultValues.firstName || '',
                lastName: defaultValues.lastName || '',
                role: defaultValues.role || UserRole.OPERATOR,
                email: defaultValues.email || '',
                ...(mode === 'create' ? { password: '' } : {})
            });
        }
    }, [defaultValues, reset, mode]);

    // Handle Server Errors
    useEffect(() => {
        if (serverErrors) {
            Object.entries(serverErrors).forEach(([field, message]) => {
                setError(field as keyof CreateUserFormValues, { message });
            });
        }
    }, [serverErrors, setError]);

    const handleFormSubmit = (data: CreateUserFormValues | EditUserFormValues) => {
        if (mode === 'create') {
            (onSubmit as (data: CreateUserFormValues) => Promise<void>)(data as CreateUserFormValues);
        } else {
            (onSubmit as (data: EditUserFormValues) => Promise<void>)(data as EditUserFormValues);
        }
    };

    return (
        <form onSubmit={handleSubmit(handleFormSubmit)} className="w-full min-w-0 space-y-6 text-left">
            <fieldset disabled={isLoading} className="w-full min-w-0 space-y-6">
                <div className="grid grid-cols-2 gap-4">
                    <div className="space-y-2">
                        <Label htmlFor="firstName">First Name</Label>
                        <Input
                            id="firstName"
                            {...register('firstName')}
                            error={errors.firstName?.message}
                            placeholder="John"
                        />
                    </div>
                    <div className="space-y-2">
                        <Label htmlFor="lastName">Last Name</Label>
                        <Input
                            id="lastName"
                            {...register('lastName')}
                            error={errors.lastName?.message}
                            placeholder="Doe"
                        />
                    </div>
                </div>

                <div className="space-y-2">
                    <Label htmlFor="email">Email Address</Label>
                    <Input
                        id="email"
                        type="email"
                        {...register('email')}
                        error={errors.email?.message}
                        placeholder="john@example.com"
                        disabled={mode === 'edit'}
                        className={mode === 'edit' ? "opacity-60 cursor-not-allowed" : ""}
                    />
                    {mode === 'edit' && <p className="text-xs text-muted-foreground">Email cannot be changed</p>}
                </div>

                {mode === 'create' && (
                    <div className="space-y-2">
                        <Label htmlFor="password">Password</Label>
                        <div className="relative group">
                            <Input
                                id="password"
                                type={showPassword ? 'text' : 'password'}
                                {...register('password' as keyof CreateUserFormValues)}
                                error={(errors as any).password?.message}
                                placeholder="••••••••"
                                className="pr-10"
                            />
                            <button
                                type="button"
                                onClick={() => setShowPassword(!showPassword)}
                                className="absolute right-3 top-1/2 -translate-y-1/2 text-muted-foreground hover:text-foreground cursor-pointer transition-colors"
                                tabIndex={-1}
                            >
                                {showPassword ? <EyeOff size={18} /> : <Eye size={18} />}
                            </button>
                        </div>
                    </div>
                )}

                <div className="space-y-2">
                    <Label htmlFor="role">Role</Label>
                    <div className="relative group">
                        <select
                            id="role"
                            {...register('role')}
                            className="flex h-10 w-full rounded-md border border-input bg-transparent px-3 py-1 text-sm shadow-sm transition-all duration-200 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:cursor-not-allowed disabled:opacity-50 hover:border-primary/50"
                        >
                            {Object.values(UserRole).map((role) => (
                                <option key={role} value={role} className="bg-popover text-popover-foreground">
                                    {role}
                                </option>
                            ))}
                        </select>
                    </div>
                    {errors.role && (
                        <p className="text-sm font-medium text-destructive">{errors.role.message}</p>
                    )}
                </div>

                <div className="flex justify-end gap-3 pt-4 border-t border-border/50">
                    <Button type="button" variant="outline" onClick={onCancel} disabled={isLoading} className="rounded-xl">
                        Cancel
                    </Button>
                    <Button
                        type="submit"
                        className="rounded-xl px-8 bg-gradient-to-r from-indigo-600 via-purple-600 to-cyan-600 hover:opacity-90 shadow-lg shadow-indigo-500/20 dark:shadow-indigo-500/40 border-none h-11 font-bold tracking-wide"
                        disabled={isLoading}
                    >
                        {isLoading ? (
                            <span className="flex items-center gap-2">
                                <span className="h-4 w-4 animate-spin rounded-full border-2 border-white border-t-transparent" />
                                {mode === 'create' ? 'Creating...' : 'Saving...'}
                            </span>
                        ) : (
                            mode === 'create' ? 'Create User' : 'Save Changes'
                        )}
                    </Button>
                </div>
            </fieldset>
        </form>
    );
}
