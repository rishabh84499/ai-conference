import { useState } from 'react';
import axios from 'axios';
import { Modal } from '@/shared/ui/Modal';
import { userService } from '@/features/dashboard/api/user.service';
import { type User } from '@/features/dashboard/types/user';
import toast from 'react-hot-toast';
import { UserForm, type EditUserFormValues } from './UserForm';
import { Logger } from '@/core/services/Logger';

interface EditUserModalProps {
    isOpen: boolean;
    onClose: () => void;
    onSuccess: () => void;
    user: User | null;
}

export function EditUserModal({ isOpen, onClose, onSuccess, user }: EditUserModalProps) {
    const [isLoading, setIsLoading] = useState(false);
    const [serverErrors, setServerErrors] = useState<Record<string, string>>({});

    const onSubmit = async (data: EditUserFormValues) => {
        if (!user) return;

        setIsLoading(true);
        setServerErrors({});

        try {
            await userService.updateUser(user._id, data);
            toast.success('User updated successfully');
            onSuccess();
            onClose();
        } catch (error: unknown) {
            toast.error('Failed to update user. Please try again.');
            Logger.error('EditUserModal error:', error);
            let backendMessage = 'Failed to update user';

            if (axios.isAxiosError(error) && error.response?.data?.message) {
                backendMessage = error.response.data.message;
            } else if (error instanceof Error) {
                backendMessage = error.message;
            }

            const lowerMessage = backendMessage.toLowerCase();
            const newErrors: Record<string, string> = {};

            // Map backend error to field if possible
            if (lowerMessage.includes('firstname')) {
                newErrors.firstName = backendMessage;
            } else if (lowerMessage.includes('lastname')) {
                newErrors.lastName = backendMessage;
            } else {
                // Show email errors and other errors as toast since email is not editable
                toast.error(backendMessage);
            }
            setServerErrors(newErrors);
        } finally {
            setIsLoading(false);
        }
    };

    if (!user) return null;

    return (
        <Modal isOpen={isOpen} onClose={onClose} title="Edit User">
            <form onSubmit={(e) => e.preventDefault()} className="space-y-4"> {/* Prevent default form submission as UserForm handles it */}
                <fieldset disabled={isLoading} className="space-y-4">
                    <UserForm
                        mode="edit"
                        defaultValues={{
                            firstName: user.firstName,
                            lastName: user.lastName,
                            role: user.role,
                            email: user.email,
                        }}
                        onSubmit={onSubmit}
                        isLoading={isLoading}
                        onCancel={onClose}
                        serverErrors={serverErrors}
                    />
                </fieldset>
            </form>
        </Modal>
    );
}
