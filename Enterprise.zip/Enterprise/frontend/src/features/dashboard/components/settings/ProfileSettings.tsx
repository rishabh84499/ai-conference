import { useState, useEffect } from 'react';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { z } from 'zod';
import { useAppSelector, useAppDispatch } from '@/core/store';
import { setUser } from '@/features/auth/store/authSlice';
import { userService } from '@/features/dashboard/api/user.service';
import { Button } from '@/shared/ui/Button';
import { Input } from '@/shared/ui/Input';
import { Label } from '@/shared/ui/Label';
import toast from 'react-hot-toast';
import { Logger } from '@/core/services/Logger';
import {
    User,
    Save,
    Pencil
} from 'lucide-react';

const profileSchema = z.object({
    firstName: z.string().min(2, 'First name must be at least 2 characters'),
    lastName: z.string().min(2, 'Last name must be at least 2 characters'),
});

type ProfileFormData = z.infer<typeof profileSchema>;

export default function ProfileSettings() {
    const user = useAppSelector((state) => state.auth.user);
    const dispatch = useAppDispatch();
    const [isSubmitting, setIsSubmitting] = useState(false);
    const [isEditing, setIsEditing] = useState(false);

    const {
        register,
        handleSubmit,
        reset,
        formState: { errors }
    } = useForm<ProfileFormData>({
        resolver: zodResolver(profileSchema),
        defaultValues: {
            firstName: user?.firstName || '',
            lastName: user?.lastName || '',
        },
    });

    // Update form when user data is available
    useEffect(() => {
        if (user) {
            reset({
                firstName: user.firstName,
                lastName: user.lastName,
            });
        }
    }, [user, reset]);

    const handleCancel = () => {
        reset({
            firstName: user?.firstName || '',
            lastName: user?.lastName || '',
        });
        setIsEditing(false);
    };

    const onSubmit = async (data: ProfileFormData) => {
        if (!user) return;
        setIsSubmitting(true);
        try {
            const updatedUser = await userService.updateProfile(data);
            // Compute name property as it might be missing from backend response but is required by AuthUser type
            const userWithComputedName = {
                ...updatedUser,
                name: `${updatedUser.firstName} ${updatedUser.lastName}`
            };
            dispatch(setUser(userWithComputedName)); // Update Redux store
            toast.success('Profile updated successfully');
            setIsEditing(false);
        } catch (error) {
            toast.error('Failed to update profile');
            Logger.error('ProfileSettings error:', error);
        } finally {
            setIsSubmitting(false);
        }
    };

    return (
        <div className="w-full space-y-6 animate-in fade-in slide-in-from-right-4 duration-500">
            {/* Profile Header Card */}
            <section className="w-full rounded-2xl border border-border/50 bg-card/30 p-6 backdrop-blur-sm shadow-sm">
                <div className="flex items-center justify-between mb-6">
                    <h2 className="text-xl font-semibold flex items-center gap-2">
                        <User className="text-primary" size={24} />
                        Profile Information
                    </h2>
                    {!isEditing && (
                        <Button
                            onClick={() => setIsEditing(true)}
                            variant="outline"
                            size="sm"
                            className="rounded-xl border-border/50 hover:bg-accent/50"
                        >
                            <Pencil size={14} className="mr-2" />
                            Edit Profile
                        </Button>
                    )}
                </div>

                <div className="flex flex-col md:flex-row gap-8 items-start w-full">
                    {/* Avatar */}
                    <div className="flex flex-col items-center gap-4 flex-none">
                        <div className="w-24 h-24 rounded-full bg-gradient-to-br from-indigo-500 to-purple-600 flex items-center justify-center text-3xl font-bold text-white shadow-xl ring-2 ring-border/50 dark:ring-white/10">
                            {user?.firstName?.charAt(0)?.toUpperCase()}
                        </div>
                    </div>

                    {/* Form Fields */}
                    <form onSubmit={handleSubmit(onSubmit)} className="flex-1 w-full space-y-4 min-w-0">
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                            <div className="space-y-2">
                                <Label htmlFor="firstName">First Name</Label>
                                <Input
                                    id="firstName"
                                    {...register('firstName')}
                                    error={errors.firstName?.message}
                                    className="bg-background/50 border-border/50 focus:border-primary/50"
                                    disabled={!isEditing}
                                />
                            </div>
                            <div className="space-y-2">
                                <Label htmlFor="lastName">Last Name</Label>
                                <Input
                                    id="lastName"
                                    {...register('lastName')}
                                    error={errors.lastName?.message}
                                    className="bg-background/50 border-border/50 focus:border-primary/50"
                                    disabled={!isEditing}
                                />
                            </div>
                        </div>

                        <div className="space-y-2">
                            <Label htmlFor="email">Email Address</Label>
                            <Input
                                id="email"
                                type="email"
                                value={user?.email || ''}
                                disabled
                                className="bg-background/50 border-border/50 opacity-70 cursor-not-allowed"
                            />
                            <p className="text-xs text-muted-foreground">
                                Email cannot be changed directly. Contact admin for assistance.
                            </p>
                        </div>

                        {isEditing && (
                            <div className="mt-8 flex justify-end gap-3 animated-in fade-in slide-in-from-bottom-2">
                                <Button
                                    type="button"
                                    variant="ghost"
                                    onClick={handleCancel}
                                    disabled={isSubmitting}
                                >
                                    Cancel
                                </Button>
                                <Button
                                    type="submit"
                                    className="bg-gradient-to-r from-indigo-500 to-purple-500"
                                    disabled={isSubmitting}
                                >
                                    {isSubmitting ? (
                                        <span className="flex items-center gap-2">
                                            <span className="h-4 w-4 animate-spin rounded-full border-2 border-white border-t-transparent" />
                                            Saving...
                                        </span>
                                    ) : (
                                        <>
                                            <Save size={16} className="mr-2" />
                                            Save Changes
                                        </>
                                    )}
                                </Button>
                            </div>
                        )}
                    </form>
                </div>
            </section>
        </div>
    );
}
