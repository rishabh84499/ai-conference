import { useState } from 'react';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { z } from 'zod';
import { authApi } from '@/features/auth/api/auth.api';
import { Button } from '@/shared/ui/Button';
import { Input } from '@/shared/ui/Input';
import { Label } from '@/shared/ui/Label';
import toast from 'react-hot-toast';
import { Shield, Key, Check, Eye, EyeOff } from 'lucide-react';
import { Logger } from '@/core/services/Logger';

const passwordSchema = z.object({
    currentPassword: z.string().min(1, 'Current password is required'),
    newPassword: z.string().min(8, 'Password must be at least 8 characters')
        .regex(/[A-Z]/, 'Must contain at least one uppercase letter')
        .regex(/[a-z]/, 'Must contain at least one lowercase letter')
        .regex(/[0-9]/, 'Must contain at least one number')
        .regex(/[^A-Za-z0-9]/, 'Must contain at least one specific symbol'),
    confirmPassword: z.string()
}).refine((data) => data.newPassword === data.confirmPassword, {
    message: "Passwords don't match",
    path: ["confirmPassword"],
});

type PasswordFormData = z.infer<typeof passwordSchema>;

export default function SecuritySettings() {
    const [isSubmitting, setIsSubmitting] = useState(false);
    const [showCurrentPassword, setShowCurrentPassword] = useState(false);
    const [showNewPassword, setShowNewPassword] = useState(false);
    const [showConfirmPassword, setShowConfirmPassword] = useState(false);

    const {
        register,
        handleSubmit,
        reset,
        formState: { errors }
    } = useForm<PasswordFormData>({
        resolver: zodResolver(passwordSchema)
    });

    const onSubmit = async (data: PasswordFormData) => {
        setIsSubmitting(true);
        try {
            await authApi.changePassword({
                currentPassword: data.currentPassword,
                newPassword: data.newPassword
            });
            toast.success('Password changed successfully');
            reset();
        } catch (error: any) {
            Logger.error('Failed to change password:', error);
            const message = error.response?.data?.message || 'Failed to change password';
            toast.error(message);
        } finally {
            setIsSubmitting(false);
        }
    };

    return (
        <div className="w-full space-y-6 animate-in fade-in slide-in-from-right-4 duration-500">
            <section className="rounded-2xl border border-border/50 bg-card/30 p-6 backdrop-blur-sm w-full shadow-sm">
                <div className="flex items-center justify-between mb-6">
                    <h2 className="text-xl font-semibold flex items-center gap-2">
                        <Shield className="text-primary" size={24} />
                        Security Settings
                    </h2>
                </div>

                <div className="w-full">
                    <form onSubmit={handleSubmit(onSubmit)} className="space-y-6">
                        <div className="space-y-2">
                            <Label htmlFor="currentPassword">Current Password</Label>
                            <div className="relative w-full">
                                <Key className="absolute left-3 top-3 h-4 w-4 text-muted-foreground z-10" />
                                <Input
                                    id="currentPassword"
                                    type={showCurrentPassword ? "text" : "password"}
                                    className="pl-9 pr-10 bg-background/50 border-border/50 focus:border-primary/50"
                                    {...register('currentPassword')}
                                    error={errors.currentPassword?.message}
                                />
                                <button
                                    type="button"
                                    onClick={() => setShowCurrentPassword(!showCurrentPassword)}
                                    className="absolute right-3 top-3 text-muted-foreground hover:text-foreground focus:outline-none"
                                >
                                    {showCurrentPassword ? <EyeOff size={16} /> : <Eye size={16} />}
                                </button>
                            </div>
                        </div>

                        <div className="space-y-2">
                            <Label htmlFor="newPassword">New Password</Label>
                            <div className="relative w-full">
                                <Key className="absolute left-3 top-3 h-4 w-4 text-muted-foreground z-10" />
                                <Input
                                    id="newPassword"
                                    type={showNewPassword ? "text" : "password"}
                                    className="pl-9 pr-10 bg-background/50 border-border/50 focus:border-primary/50"
                                    {...register('newPassword')}
                                    error={errors.newPassword?.message}
                                />
                                <button
                                    type="button"
                                    onClick={() => setShowNewPassword(!showNewPassword)}
                                    className="absolute right-3 top-3 text-muted-foreground hover:text-foreground focus:outline-none"
                                >
                                    {showNewPassword ? <EyeOff size={16} /> : <Eye size={16} />}
                                </button>
                            </div>
                        </div>

                        <div className="space-y-2">
                            <Label htmlFor="confirmPassword">Confirm New Password</Label>
                            <div className="relative w-full">
                                <Key className="absolute left-3 top-3 h-4 w-4 text-muted-foreground z-10" />
                                <Input
                                    id="confirmPassword"
                                    type={showConfirmPassword ? "text" : "password"}
                                    className="pl-9 pr-10 bg-background/50 border-border/50 focus:border-primary/50"
                                    {...register('confirmPassword')}
                                    error={errors.confirmPassword?.message}
                                />
                                <button
                                    type="button"
                                    onClick={() => setShowConfirmPassword(!showConfirmPassword)}
                                    className="absolute right-3 top-3 text-muted-foreground hover:text-foreground focus:outline-none"
                                >
                                    {showConfirmPassword ? <EyeOff size={16} /> : <Eye size={16} />}
                                </button>
                            </div>
                        </div>

                        <div className="pt-4">
                            <Button
                                type="submit"
                                className="bg-gradient-to-r from-indigo-500 to-purple-500 w-full sm:w-auto min-w-[150px]"
                                disabled={isSubmitting}
                            >
                                {isSubmitting ? (
                                    <span className="flex items-center justify-center gap-2">
                                        <span className="h-4 w-4 animate-spin rounded-full border-2 border-white border-t-transparent" />
                                        Updating...
                                    </span>
                                ) : (
                                    <>
                                        <Check size={16} className="mr-2" />
                                        Update Password
                                    </>
                                )}
                            </Button>
                        </div>
                    </form>
                </div>
            </section>
        </div>
    );
}
