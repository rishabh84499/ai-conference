import { useState, useEffect } from 'react';
import { useAppSelector, useAppDispatch } from '@/core/store';
import { setUser } from '@/features/auth/store/authSlice';
import { userService } from '@/features/dashboard/api/user.service';
import { Button } from '@/shared/ui/Button';
import toast from 'react-hot-toast';
import { Logger } from '@/core/services/Logger';
import { Bell, Mail, Smartphone, Shield, Activity, Megaphone, Server, Check } from 'lucide-react';
import type { UserPreferences } from '@/types/entities/user';

// Default preferences structure if user has none
const defaultPreferences: UserPreferences = {
    notifications: {
        security: { email: true, push: true, inApp: true },
        activity: { email: true, push: true, inApp: true },
        marketing: { email: false, push: false, inApp: false },
        system: { email: true, push: false, inApp: true },
    }
};

type NotificationCategory = 'security' | 'activity' | 'marketing' | 'system';
type NotificationChannel = 'email' | 'push' | 'inApp';

const CATEGORIES = [
    { id: 'security', label: 'Security', icon: Shield, description: 'Login alerts and password changes' },
    { id: 'activity', label: 'Activity', icon: Activity, description: 'Mentions, comments, and workflow updates' },
    { id: 'marketing', label: 'Marketing', icon: Megaphone, description: 'Newsletters and product updates' },
    { id: 'system', label: 'System', icon: Server, description: 'Maintenance and downtime alerts' },
] as const;

export default function NotificationSettings() {
    const user = useAppSelector((state) => state.auth.user);
    const dispatch = useAppDispatch();
    const [preferences, setPreferences] = useState<UserPreferences>(() => {
        return user?.preferences || defaultPreferences;
    });
    const [isSaving, setIsSaving] = useState(false);
    const [hasChanges, setHasChanges] = useState(false);

    // Sync local state if user updates elsewhere (e.g. initial load)
    useEffect(() => {
        if (user?.preferences) {
            setPreferences(user.preferences);
        }
    }, [user?.preferences]);

    const handleToggle = (category: NotificationCategory, channel: NotificationChannel) => {
        setPreferences(prev => ({
            ...prev,
            notifications: {
                ...prev.notifications,
                [category]: {
                    ...prev.notifications[category],
                    [channel]: !prev.notifications[category][channel]
                }
            }
        }));
        setHasChanges(true);
    };

    const handleSave = async () => {
        if (!user) return;
        setIsSaving(true);
        try {
            const updatedUser = await userService.updateProfile({ preferences });
            // Compute name property as it might be missing from backend response but is required by AuthUser type
            const userWithComputedName = {
                ...updatedUser,
                name: `${updatedUser.firstName} ${updatedUser.lastName}`
            };
            dispatch(setUser(userWithComputedName));
            toast.success('Notification preferences saved');
            setHasChanges(false);
        } catch (error) {
            toast.error('Failed to save preferences');
            Logger.error('NotificationSettings error:', error);
        } finally {
            setIsSaving(false);
        }
    };

    return (
        <div className="space-y-6 animate-in fade-in slide-in-from-right-4 duration-500">
            <section className="rounded-2xl border border-border/50 bg-card/30 p-6 backdrop-blur-sm shadow-sm">
                <div className="flex items-center justify-between mb-6">
                    <h2 className="text-xl font-semibold flex items-center gap-2">
                        <Bell className="text-primary" size={24} />
                        Notification Preferences
                    </h2>
                    {hasChanges && (
                        <Button
                            onClick={handleSave}
                            disabled={isSaving}
                            className="bg-primary text-primary-foreground hover:bg-primary/90 transition-all animate-in fade-in zoom-in"
                        >
                            {isSaving ? 'Saving...' : (
                                <>
                                    <Check size={16} className="mr-2" />
                                    Save Changes
                                </>
                            )}
                        </Button>
                    )}
                </div>

                <div className="space-y-6">
                    {/* Header Row for Channels */}
                    <div className="hidden md:grid grid-cols-12 gap-4 px-4 py-2 text-sm font-medium text-muted-foreground border-b border-border/50">
                        <div className="col-span-6">Category</div>
                        <div className="col-span-2 text-center flex items-center justify-center gap-2">
                            <Mail size={16} /> Email
                        </div>
                        <div className="col-span-2 text-center flex items-center justify-center gap-2">
                            <Smartphone size={16} /> Push
                        </div>
                        <div className="col-span-2 text-center flex items-center justify-center gap-2">
                            <Bell size={16} /> In-App
                        </div>
                    </div>

                    {CATEGORIES.map((category) => (
                        <div
                            key={category.id}
                            className="flex flex-col md:grid md:grid-cols-12 gap-4 p-4 rounded-xl border border-border/20 bg-muted/20 hover:bg-muted/40 transition-colors"
                        >
                            <div className="col-span-6 flex items-start gap-3">
                                <div className="p-2 rounded-lg bg-background border border-border/50">
                                    <category.icon size={20} className="text-primary" />
                                </div>
                                <div>
                                    <div className="font-medium">{category.label}</div>
                                    <div className="text-xs text-muted-foreground">{category.description}</div>
                                </div>
                            </div>

                            <div className="col-span-6 md:col-span-6 grid grid-cols-3 gap-4">
                                <Toggle
                                    checked={preferences.notifications[category.id as NotificationCategory].email}
                                    onChange={() => handleToggle(category.id as NotificationCategory, 'email')}
                                    icon={<Mail size={14} />}
                                    label="Email"
                                />
                                <Toggle
                                    checked={preferences.notifications[category.id as NotificationCategory].push}
                                    onChange={() => handleToggle(category.id as NotificationCategory, 'push')}
                                    icon={<Smartphone size={14} />}
                                    label="Push"
                                />
                                <Toggle
                                    checked={preferences.notifications[category.id as NotificationCategory].inApp}
                                    onChange={() => handleToggle(category.id as NotificationCategory, 'inApp')}
                                    icon={<Bell size={14} />}
                                    label="In-App"
                                />
                            </div>
                        </div>
                    ))}
                </div>
            </section>
        </div>
    );
}

function Toggle({ checked, onChange, icon, label }: { checked: boolean; onChange: () => void; icon: React.ReactNode; label: string }) {
    return (
        <div className="flex flex-col items-center justify-center gap-2">
            <button
                onClick={onChange}
                className={`relative inline-flex h-6 w-11 items-center rounded-full transition-colors focus:outline-none focus:ring-2 focus:ring-primary focus:ring-offset-2 focus:ring-offset-background ${checked ? 'bg-primary' : 'bg-muted'
                    }`}
            >
                <span
                    className={`inline-block h-4 w-4 transform rounded-full bg-white transition-transform ${checked ? 'translate-x-6' : 'translate-x-1'
                        }`}
                />
            </button>
            <span className="md:hidden text-xs text-muted-foreground flex items-center gap-1">
                {icon} {label}
            </span>
        </div>
    );
}
