import { CreditCard, FileText } from 'lucide-react';

export default function BillingSettings() {
    return (
        <div className="w-full space-y-6 animate-in fade-in slide-in-from-right-4 duration-500">
            <section className="w-full rounded-2xl border border-white/10 bg-card/30 p-6 backdrop-blur-sm">
                <div className="flex items-center justify-between mb-6">
                    <h2 className="text-xl font-semibold flex items-center gap-2">
                        <CreditCard className="text-primary" size={24} />
                        Billing & Subscription
                    </h2>
                </div>

                <div className="flex flex-col items-center justify-center py-12 text-center text-muted-foreground">
                    <FileText size={48} className="mb-4 opacity-20" />
                    <h3 className="text-lg font-medium">Enterprise Feature</h3>
                    <p className="text-sm opacity-60 max-w-xl md:max-w-2xl mt-2">
                        Billing and subscription management is currently being configured for your enterprise account.
                    </p>
                </div>
            </section>
        </div>
    );
}
