import { Monitor, Sun, Moon } from 'lucide-react';
import { useTheme } from '@/core/context/ThemeProvider';

export default function AppearanceSettings() {
    const { theme, setTheme } = useTheme();

    return (
        <div className="w-full space-y-6 animate-in fade-in slide-in-from-right-4 duration-500">
            <section className="w-full rounded-2xl border border-border/50 bg-card/30 p-6 backdrop-blur-sm shadow-sm">
                <div className="flex items-center justify-between mb-6">
                    <h2 className="text-xl font-semibold flex items-center gap-2">
                        <Monitor className="text-primary" size={24} />
                        Appearance
                    </h2>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-3 gap-4 w-full">
                    <button
                        onClick={() => setTheme('light')}
                        className={`flex items-center justify-between p-4 rounded-xl border transition-all hover:bg-muted/50 ${theme === 'light'
                            ? 'border-primary bg-primary/10 ring-1 ring-primary'
                            : 'border-border/50 bg-background/50'
                            }`}
                    >
                        <div className="flex items-center gap-3">
                            <div className="p-2 rounded-full bg-background border border-border/50">
                                <Sun size={20} className="text-yellow-500" />
                            </div>
                            <div className="text-left">
                                <div className="font-medium">Light Mode</div>
                                <div className="text-xs text-muted-foreground">Always light</div>
                            </div>
                        </div>
                        {theme === 'light' && (
                            <div className="h-4 w-4 rounded-full border border-primary bg-primary" />
                        )}
                    </button>

                    <button
                        onClick={() => setTheme('dark')}
                        className={`flex items-center justify-between p-4 rounded-xl border transition-all hover:bg-muted/50 ${theme === 'dark'
                            ? 'border-primary bg-primary/10 ring-1 ring-primary'
                            : 'border-border/50 bg-background/50'
                            }`}
                    >
                        <div className="flex items-center gap-3">
                            <div className="p-2 rounded-full bg-background border border-border/50">
                                <Moon size={20} className="text-indigo-500" />
                            </div>
                            <div className="text-left">
                                <div className="font-medium">Dark Mode</div>
                                <div className="text-xs text-muted-foreground">Always dark</div>
                            </div>
                        </div>
                        {theme === 'dark' && (
                            <div className="h-4 w-4 rounded-full border border-primary bg-primary" />
                        )}
                    </button>

                    <button
                        onClick={() => setTheme('system')}
                        className={`flex items-center justify-between p-4 rounded-xl border transition-all hover:bg-muted/50 ${theme === 'system'
                            ? 'border-primary bg-primary/10 ring-1 ring-primary'
                            : 'border-border/50 bg-background/50'
                            }`}
                    >
                        <div className="flex items-center gap-3">
                            <div className="p-2 rounded-full bg-background border border-border/50">
                                <Monitor size={20} className="text-slate-500" />
                            </div>
                            <div className="text-left">
                                <div className="font-medium">System</div>
                                <div className="text-xs text-muted-foreground">Follow settings</div>
                            </div>
                        </div>
                        {theme === 'system' && (
                            <div className="h-4 w-4 rounded-full border border-primary bg-primary" />
                        )}
                    </button>
                </div>
            </section>
        </div>
    );
}
