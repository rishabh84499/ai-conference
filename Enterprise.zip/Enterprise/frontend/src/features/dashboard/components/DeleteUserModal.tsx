import { Modal } from '@/shared/ui/Modal';
import { Button } from '@/shared/ui/Button';
import toast from 'react-hot-toast';
import { Logger } from '@/core/services/Logger';
import { AlertTriangle } from 'lucide-react';
import { useState } from 'react';

interface DeleteUserModalProps {
    isOpen: boolean;
    onClose: () => void;
    onConfirm: () => Promise<void>;
    userName: string;
    userEmail: string;
}

export function DeleteUserModal({ isOpen, onClose, onConfirm, userName, userEmail }: DeleteUserModalProps) {
    const [isDeleting, setIsDeleting] = useState(false);

    const handleConfirm = async () => {
        setIsDeleting(true);
        try {
            await onConfirm();
            onClose();
        } catch (error) {
            toast.error('Failed to delete user. Please try again.');
            Logger.error('DeleteUserModal error:', error);
        } finally {
            setIsDeleting(false);
        }
    };

    return (
        <Modal
            isOpen={isOpen}
            onClose={onClose}
            title="Delete User"
            maxWidth="md"
        >
            <div className="space-y-6">
                <div className="bg-destructive/10 border border-destructive/20 rounded-xl p-4">
                    <div className="flex items-start gap-4">
                        <div className="flex-shrink-0 w-10 h-10 rounded-full bg-destructive/20 flex items-center justify-center">
                            <AlertTriangle className="h-5 w-5 text-destructive" />
                        </div>
                        <div className="flex-1">
                            <h4 className="text-sm font-semibold text-destructive mb-1">
                                This action cannot be undone
                            </h4>
                            <p className="text-sm text-foreground/70">
                                Deleting this user will permanently remove all their data, including their profile,
                                activity history, and associated records from the system.
                            </p>
                        </div>
                    </div>
                </div>

                {/* User Details */}
                <div className="bg-muted/30 border border-border/50 rounded-xl p-4">
                    <p className="text-sm text-muted-foreground mb-2">You are about to delete:</p>
                    <div className="space-y-1">
                        <div className="flex items-center gap-2">
                            <span className="text-sm font-medium text-foreground">Name:</span>
                            <span className="text-sm text-foreground">{userName}</span>
                        </div>
                        <div className="flex items-center gap-2">
                            <span className="text-sm font-medium text-foreground">Email:</span>
                            <span className="text-sm text-foreground">{userEmail}</span>
                        </div>
                    </div>
                </div>

                {/* Confirmation Text */}
                <div className="bg-amber-500/10 border border-amber-500/20 rounded-xl p-4">
                    <p className="text-sm text-amber-600 dark:text-amber-400">
                        Please confirm that you understand this action is permanent and cannot be reversed.
                    </p>
                </div>

                {/* Actions */}
                <div className="flex justify-end gap-3 pt-4 border-t border-border/50">
                    <Button
                        type="button"
                        variant="outline"
                        onClick={onClose}
                        disabled={isDeleting}
                    >
                        Cancel
                    </Button>
                    <Button
                        type="button"
                        variant="destructive"
                        onClick={handleConfirm}
                        disabled={isDeleting}
                        className="bg-red-600 hover:bg-red-700 border-red-600"
                    >
                        {isDeleting ? 'Deleting...' : 'Delete User'}
                    </Button>
                </div>
            </div>
        </Modal>
    );
}

export default DeleteUserModal;
