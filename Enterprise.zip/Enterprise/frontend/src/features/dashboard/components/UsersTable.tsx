import { useRef } from 'react'; // Added useRef
import { useVirtualizer } from '@tanstack/react-virtual'; // Added useVirtualizer
import { useTranslation } from 'react-i18next';
import { MoreHorizontal, Trash2, UserCheck, Ban, Edit, Eye, KeyRound } from 'lucide-react';
import {
    Table,
    TableBody,
    TableCell,
    TableHead,
    TableHeader,
    TableRow,
} from '@/shared/ui/Table';
import { Button } from '@/shared/ui/Button';
import { Skeleton } from '@/shared/ui/Skeleton';
import { DropdownMenu, DropdownMenuItem, DropdownMenuSeparator } from '@/shared/ui/DropdownMenu';
import { type User, UserStatus } from '@/features/dashboard/types/user';

interface UsersTableProps {
    users: User[];
    isLoading: boolean;
    onEdit: (user: User) => void;
    onView: (user: User) => void;
    onDelete: (user: User) => void;
    onResetPassword: (user: User) => void;
    onChangeStatus: (userId: string, status: UserStatus) => void;
}

export function UsersTable({
    users,
    isLoading,
    onEdit,
    onView,
    onDelete,
    onResetPassword,
    onChangeStatus
}: UsersTableProps) {
    const { t } = useTranslation();
    const parentRef = useRef<HTMLDivElement>(null);

    const rowVirtualizer = useVirtualizer({
        count: users.length,
        getScrollElement: () => parentRef.current,
        estimateSize: () => 60, // Estimate row height
        overscan: 5,
    });

    return (
        <div className="rounded-2xl border border-border/40 bg-card/40 backdrop-blur-xl shadow-2xl shadow-black/5 flex flex-col overflow-hidden animate-in fade-in slide-in-from-bottom-6 duration-700">
            {/* Added max-h for virtualization scroll container */}
            <div ref={parentRef} className="overflow-auto max-h-[600px] relative scrollbar-thin">
                <Table className="min-w-full border-separate border-spacing-0">
                    <TableHeader className="sticky top-0 z-20 bg-background/80 backdrop-blur-md shadow-sm">
                        <TableRow className="hover:bg-transparent border-border/50">
                            <TableHead className="w-[30%] py-4 text-xs font-semibold uppercase tracking-wider text-muted-foreground/80 pl-6">{t('users.table.user')}</TableHead>
                            <TableHead className="w-[25%] py-4 text-xs font-semibold uppercase tracking-wider text-muted-foreground/80">{t('users.table.email')}</TableHead>
                            <TableHead className="w-[15%] py-4 text-xs font-semibold uppercase tracking-wider text-muted-foreground/80">{t('users.table.role')}</TableHead>
                            <TableHead className="w-[15%] py-4 text-xs font-semibold uppercase tracking-wider text-muted-foreground/80">{t('users.table.status')}</TableHead>
                            <TableHead className="w-[15%] py-4 text-xs font-semibold uppercase tracking-wider text-muted-foreground/80 text-right pr-6">{t('common.actions')}</TableHead>
                        </TableRow>
                    </TableHeader>
                    <TableBody>
                        {isLoading ? (
                            Array.from({ length: 5 }).map((_, i) => (
                                <TableRow key={i} className="border-white/10">
                                    <TableCell>
                                        <div className="flex items-center gap-3">
                                            <Skeleton className="w-8 h-8 rounded-full" />
                                            <Skeleton className="h-4 w-32" />
                                        </div>
                                    </TableCell>
                                    <TableCell><Skeleton className="h-4 w-48" /></TableCell>
                                    <TableCell><Skeleton className="h-4 w-20" /></TableCell>
                                    <TableCell><Skeleton className="h-4 w-16" /></TableCell>
                                    <TableCell className="text-right"><Skeleton className="h-8 w-8 ml-auto" /></TableCell>
                                </TableRow>
                            ))
                        ) : users.length === 0 ? (
                            <TableRow>
                                <TableCell colSpan={5} className="h-24 text-center text-muted-foreground">
                                    {t('users.messages.no_users')}
                                </TableCell>
                            </TableRow>
                        ) : (
                            <>
                                {/* Virtualizer Spacer - Top */}
                                {rowVirtualizer.getVirtualItems().length > 0 && (
                                    <tr style={{ height: `${rowVirtualizer.getVirtualItems()[0].start}px` }}>
                                        <td colSpan={5} />
                                    </tr>
                                )}

                                {rowVirtualizer.getVirtualItems().map((virtualRow) => {
                                    const user = users[virtualRow.index];
                                    return (
                                        <TableRow
                                            key={user._id}
                                            className="hover:bg-muted/30 border-border/40 transition-colors group"
                                            data-index={virtualRow.index}
                                            ref={rowVirtualizer.measureElement}
                                        >
                                            <TableCell className="font-medium text-foreground py-3 pl-6">
                                                <div className="flex items-center gap-3">
                                                    <div className="w-9 h-9 rounded-full bg-gradient-to-br from-indigo-500 to-violet-600 flex items-center justify-center text-xs font-bold text-white shadow-md ring-2 ring-background group-hover:scale-105 transition-transform duration-200">
                                                        {(user.firstName || '?')[0]}{(user.lastName || '')[0]}
                                                    </div>
                                                    <span className="font-semibold">{user.firstName} {user.lastName}</span>
                                                </div>
                                            </TableCell>
                                            <TableCell className="text-muted-foreground text-sm">{user.email}</TableCell>
                                            <TableCell>
                                                <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-secondary text-secondary-foreground border border-border/50 capitalize shadow-sm">
                                                    {t(`users.roles.${user.role.toLowerCase()}`, user.role)}
                                                </span>
                                            </TableCell>
                                            <TableCell>
                                                <div className="flex items-center gap-2">
                                                    <span className={`relative flex h-2.5 w-2.5`}>
                                                        <span className={`animate-ping absolute inline-flex h-full w-full rounded-full opacity-75 ${user.status === UserStatus.ACTIVE ? 'bg-emerald-400' : 'bg-gray-400'}`}></span>
                                                        <span className={`relative inline-flex rounded-full h-2.5 w-2.5 ${user.status === UserStatus.ACTIVE ? 'bg-emerald-500' : 'bg-gray-500'}`}></span>
                                                    </span>
                                                    <span className="text-sm font-medium text-muted-foreground capitalize">
                                                        {t(`users.status.${user.status.toLowerCase()}`, user.status)}
                                                    </span>
                                                </div>
                                            </TableCell>
                                            <TableCell className="text-right pr-6">
                                                <DropdownMenu
                                                    trigger={
                                                        <Button variant="ghost" size="icon" className="h-8 w-8 hover:bg-background hover:shadow-sm transition-all duration-200">
                                                            <MoreHorizontal className="h-4 w-4 text-muted-foreground" />
                                                        </Button>
                                                    }
                                                >
                                                    <DropdownMenuItem onClick={() => onEdit(user)} className="cursor-pointer">
                                                        <Edit className="h-4 w-4 mr-2" />
                                                        {t('users.actions.edit_user')}
                                                    </DropdownMenuItem>
                                                    <DropdownMenuItem onClick={() => onView(user)} className="cursor-pointer">
                                                        <Eye className="h-4 w-4 mr-2" />
                                                        {t('users.actions.view_details')}
                                                    </DropdownMenuItem>

                                                    <DropdownMenuSeparator />

                                                    <DropdownMenuItem onClick={() => onResetPassword(user)} className="cursor-pointer">
                                                        <KeyRound className="h-4 w-4 mr-2" />
                                                        {t('users.actions.reset_password')}
                                                    </DropdownMenuItem>

                                                    <DropdownMenuSeparator />

                                                    <div className="px-2 py-1.5 text-[10px] font-bold text-muted-foreground/50 uppercase tracking-widest">
                                                        {t('users.table.status')}
                                                    </div>

                                                    {user.status === UserStatus.SUSPENDED && (
                                                        <DropdownMenuItem onClick={() => onChangeStatus(user._id, UserStatus.ACTIVE)} className="text-emerald-500 focus:text-emerald-500 focus:bg-emerald-500/10 cursor-pointer">
                                                            <UserCheck className="h-4 w-4 mr-2" />
                                                            {t('users.actions.reactivate_user')}
                                                        </DropdownMenuItem>
                                                    )}
                                                    {user.status !== UserStatus.SUSPENDED && (
                                                        <DropdownMenuItem onClick={() => onChangeStatus(user._id, UserStatus.SUSPENDED)} className="text-amber-500 focus:text-amber-500 focus:bg-amber-500/10 cursor-pointer">
                                                            <Ban className="h-4 w-4 mr-2" />
                                                            {t('users.actions.suspend_user')}
                                                        </DropdownMenuItem>
                                                    )}

                                                    <DropdownMenuSeparator />

                                                    <DropdownMenuItem
                                                        className="text-destructive focus:text-destructive focus:bg-destructive/10 cursor-pointer"
                                                        onClick={() => onDelete(user)}
                                                    >
                                                        <Trash2 className="h-4 w-4 mr-2" />
                                                        {t('users.actions.delete_user')}
                                                    </DropdownMenuItem>
                                                </DropdownMenu>
                                            </TableCell>
                                        </TableRow>
                                    );
                                })}

                                {/* Virtualizer Spacer - Bottom */}
                                {rowVirtualizer.getVirtualItems().length > 0 && (
                                    <tr style={{ height: `${rowVirtualizer.getTotalSize() - rowVirtualizer.getVirtualItems()[rowVirtualizer.getVirtualItems().length - 1].end}px` }}>
                                        <td colSpan={5} />
                                    </tr>
                                )}
                            </>
                        )}
                    </TableBody>
                </Table>
            </div>
        </div>
    );
}
