import { useTranslation } from 'react-i18next';
import { Search, RefreshCw, Plus } from 'lucide-react';
import { Button } from '@/shared/ui/Button';
import { Input } from '@/shared/ui/Input';
import { Can } from '@/shared/components/Can';
import { UserRole } from '@/features/dashboard/types/user';

interface UsersToolbarProps {
    searchTerm: string;
    onSearchChange: (value: string) => void;
    onRefresh: () => void;
    onAddUser: () => void;
    isLoading?: boolean;
}

export function UsersToolbar({
    searchTerm,
    onSearchChange,
    onRefresh,
    onAddUser,
    isLoading
}: UsersToolbarProps) {
    const { t } = useTranslation();

    return (
        <div className="w-full space-y-6 animate-in fade-in slide-in-from-bottom-2 duration-500">
            <div className="flex flex-col sm:flex-row sm:items-end justify-between gap-4">
                <div>
                    <h1 className="text-3xl font-extrabold tracking-tight text-foreground">
                        {t('users.title')}
                    </h1>
                    <p className="text-muted-foreground mt-1 text-sm max-w-3xl lg:max-w-4xl">
                        {t('users.subtitle')}
                    </p>
                </div>
                <div className="flex items-center gap-3">
                    <Can perform={[UserRole.SUPER_ADMIN, UserRole.ADMIN, UserRole.MANAGER]}>
                        <Button
                            onClick={onAddUser}
                            className="bg-indigo-600 hover:bg-indigo-700 text-white shadow-lg shadow-indigo-500/25 hover:shadow-indigo-500/40 rounded-xl"
                            size="lg"
                        >
                            <Plus className="mr-2 h-5 w-5" />
                            {t('users.add_user')}
                        </Button>
                    </Can>
                </div>
            </div>

            <div className="flex items-center gap-4 p-1.5 ">
                <div className="relative flex-1 max-w-sm group">
                    <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                        <Search className="h-4 w-4 text-muted-foreground group-focus-within:text-primary transition-colors" />
                    </div>
                    <Input
                        placeholder={t('common.search')}
                        value={searchTerm}
                        onChange={(e) => onSearchChange(e.target.value)}
                        className="pl-10 pb-2.5 pt-2.5 h-auto bg-card/50 border-border/50 focus:bg-background transition-all rounded-xl shadow-sm hover:shadow-md focus:shadow-lg focus:ring-primary/20"
                    />
                </div>
                <div className="w-px h-8 bg-border/50 mx-2 hidden sm:block" />
                <Button
                    variant="outline"
                    size="icon"
                    onClick={onRefresh}
                    className="h-10 w-10 rounded-xl border-border/50 bg-card/50 hover:bg-background hover:border-primary/30 transition-all shadow-sm hover:shadow-md"
                    title={t('common.refresh')}
                >
                    <RefreshCw className={`h-4 w-4 text-muted-foreground ${isLoading ? 'animate-spin text-primary' : ''}`} />
                </Button>
            </div>
        </div>
    );
}
