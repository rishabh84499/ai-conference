import { useState } from 'react';
import axios from 'axios';
import { Modal } from '@/shared/ui/Modal';
import { userService } from '@/features/dashboard/api/user.service';
import toast from 'react-hot-toast';
import { UserForm, type CreateUserFormValues } from './UserForm';
import { Logger } from '@/core/services/Logger';

interface CreateUserModalProps {
    isOpen: boolean;
    onClose: () => void;
    onSuccess: () => void;
}

export function CreateUserModal({ isOpen, onClose, onSuccess }: CreateUserModalProps) {
    const [isLoading, setIsLoading] = useState(false);
    const [serverErrors, setServerErrors] = useState<Record<string, string>>({});

    const onSubmit = async (data: CreateUserFormValues) => {
        setIsLoading(true);
        setServerErrors({});

        try {
            await userService.createUser(data);
            toast.success('User created successfully');
            onSuccess();
            onClose();
            // Form inside UserForm will reset via key or effect if needed, 
            // but since Modal unmounts/hides, we might need a reset signal.
            // Actually UserForm resets on mount/defaultValues change. 
        } catch (error: unknown) {
            Logger.error('CreateUserModal error:', error);
            let backendMessage = 'Failed to create user';

            if (axios.isAxiosError(error) && error.response?.data?.message) {
                backendMessage = error.response.data.message;
            } else if (error instanceof Error) {
                backendMessage = error.message;
            }

            const lowerMessage = backendMessage.toLowerCase();
            const newErrors: Record<string, string> = {};

            // Map backend error to field if possible
            if (lowerMessage.includes('email')) {
                newErrors.email = backendMessage;
            } else if (lowerMessage.includes('password')) {
                newErrors.password = backendMessage;
            } else if (lowerMessage.includes('firstname')) {
                newErrors.firstName = backendMessage;
            } else if (lowerMessage.includes('lastname')) {
                newErrors.lastName = backendMessage;
            } else {
                toast.error(backendMessage);
            }
            setServerErrors(newErrors);
        } finally {
            setIsLoading(false);
        }
    };

    return (
        <Modal isOpen={isOpen} onClose={onClose} title="Create New User">
            <UserForm
                mode="create"
                onSubmit={onSubmit}
                isLoading={isLoading}
                onCancel={onClose}
                serverErrors={serverErrors}
            />
        </Modal>
    );
}
