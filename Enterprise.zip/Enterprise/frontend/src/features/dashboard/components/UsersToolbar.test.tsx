import { describe, it, expect, vi } from 'vitest';
import { render, screen, fireEvent } from '@testing-library/react';
import { UsersToolbar } from './UsersToolbar';
import { UserRole } from '@/features/dashboard/types/user';

// Mock dependencies
vi.mock('react-i18next', () => ({
    useTranslation: () => ({
        t: (key: string) => key,
    }),
}));

vi.mock('@/features/auth/hooks/useAuth', () => ({
    useAuth: () => ({
        user: { role: UserRole.ADMIN },
    }),
}));

describe('UsersToolbar', () => {
    it('renders correctly', () => {
        render(
            <UsersToolbar
                searchTerm=""
                onSearchChange={() => { }}
                onRefresh={() => { }}
                onAddUser={() => { }}
            />
        );

        expect(screen.getByText('users.title')).toBeInTheDocument();
        expect(screen.getByText('users.add_user')).toBeInTheDocument();
    });

    it('calls onSearchChange when input changes', () => {
        const handleSearch = vi.fn();
        render(
            <UsersToolbar
                searchTerm=""
                onSearchChange={handleSearch}
                onRefresh={() => { }}
                onAddUser={() => { }}
            />
        );

        const input = screen.getByPlaceholderText('common.search');
        fireEvent.change(input, { target: { value: 'test' } });
        expect(handleSearch).toHaveBeenCalledWith('test');
    });
});
