import { z } from 'zod';
import { UserRole, UserStatus } from '@/types/entities/user';

export const CreateUserSchema = z.object({
    email: z.string().email('Invalid email address'),
    password: z.string().min(8, 'Password must be at least 8 characters'),
    firstName: z.string().min(1, 'First name is required'),
    lastName: z.string().min(1, 'Last name is required'),
    role: z.nativeEnum(UserRole),
    status: z.nativeEnum(UserStatus).optional(),
});

export const UpdateUserSchema = z.object({
    email: z.string().email('Invalid email address').optional(),
    firstName: z.string().min(1).optional(),
    lastName: z.string().min(1).optional(),
    role: z.nativeEnum(UserRole).optional(),
    password: z.string().min(8).optional(),
    status: z.nativeEnum(UserStatus).optional(),
});

export const UserSchema = z.object({
    _id: z.string(),
    email: z.string().email(),
    firstName: z.string(),
    lastName: z.string(),
    role: z.nativeEnum(UserRole),
    status: z.nativeEnum(UserStatus),
    isEmailVerified: z.boolean(),
    createdAt: z.string(),
    updatedAt: z.string(),
    lastLogin: z.string().optional(),
});

export const UserListResponseSchema = z.object({
    results: z.array(UserSchema),
    page: z.number(),
    limit: z.number(),
    totalPages: z.number(),
    totalResults: z.number(),
});

export type CreateUserInput = z.infer<typeof CreateUserSchema>;
export type UpdateUserInput = z.infer<typeof UpdateUserSchema>;
