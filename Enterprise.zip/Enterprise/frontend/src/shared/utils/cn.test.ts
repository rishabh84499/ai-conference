import { cn } from './cn';
import { describe, it, expect } from 'vitest';

describe('cn utility', () => {
    it('merges class names correctly', () => {
        expect(cn('c1', 'c2')).toBe('c1 c2');
    });

    it('conditionally merges class names', () => {
        expect(cn('c1', true && 'c2', false && 'c3')).toBe('c1 c2');
    });

    it('handles objects', () => {
        expect(cn({ c1: true, c2: false, c3: true })).toBe('c1 c3');
    });

    it('merges tailwind classes using tailwind-merge', () => {
        expect(cn('px-2 py-1', 'p-4')).toBe('p-4'); // p-4 overrides px-2 py-1
        expect(cn('bg-red-500', 'bg-blue-500')).toBe('bg-blue-500');
    });
});
