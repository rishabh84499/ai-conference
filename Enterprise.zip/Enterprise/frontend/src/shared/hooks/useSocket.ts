import { useSocketContext } from '../../core/context/SocketContext';

export const useSocket = () => {
    return useSocketContext();
};
