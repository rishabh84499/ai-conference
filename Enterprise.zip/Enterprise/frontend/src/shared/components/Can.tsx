import React from 'react';
import { useAuth } from '@/features/auth/hooks/useAuth';
import { UserRole } from '@/features/dashboard/types/user';

// Re-export UserRole for convenience
export { UserRole };

interface CanProps {
    perform: string | string[]; // Permission or Role
    yes?: React.ReactNode;
    no?: React.ReactNode;
    children?: React.ReactNode;
    /**
     * Optional custom check function for resource-based permissions
     * @param user The current authenticated user
     * @returns boolean - true if allowed
     */
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    check?: (user: any) => boolean;
}

/**
 * Declarative RBAC Component
 * Usage:
 * <Can perform={UserRole.ADMIN} yes={<AdminButton />} no={<UserButton />} />
 * or
 * <Can perform={[UserRole.ADMIN, UserRole.MANAGER]}>
 *   <SensitiveResource />
 * </Can>
 * or
 * <Can perform={UserRole.OPERATOR} check={(user) => user.id === resource.ownerId}>
 *   <EditButton />
 * </Can>
 */
export const Can: React.FC<CanProps> = ({ perform, yes, no, children, check }) => {
    const { user } = useAuth();

    if (!user) return <>{no || null}</>;

    const roles = Array.isArray(perform) ? perform : [perform];
    const userRoleStr = String(user.role).toLowerCase();

    // 1. Check Role/Permission
    const hasRole = roles.some(role => String(role).toLowerCase() === userRoleStr);

    // 2. Check Custom Logic (if provided)
    // If 'check' is provided, it MUST return true.
    // If 'hasRole' is true, we still check 'check' if provided (AND logic).
    // Actually, usually it's OR logic (Role OR Ownership), but here we might want refinements.
    // Let's implement: (Role Match) AND (Custom Check if present)
    // Example: Admin can edit ANY user (Role Match), but User can only edit SELF (Custom Check).
    // This requires slightly more complex logic: "If Admin -> True. Else -> Check Custom".

    // For this generic component, let's keep it simple:
    // If the user has one of the allowed roles, AND passes the check (if any), then YES.

    let isAllowed = hasRole;

    if (check) {
        isAllowed = isAllowed && check(user);
    }

    if (isAllowed) {
        return <>{yes || children || null}</>;
    }

    return <>{no || null}</>;
};
