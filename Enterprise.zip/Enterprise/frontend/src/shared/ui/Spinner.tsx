import { cn } from '@/shared/utils/cn';

interface SpinnerProps {
    size?: 'sm' | 'md' | 'lg';
    className?: string;
}

const sizeClasses: Record<string, string> = {
    sm: 'w-4 h-4 border-2',
    md: 'w-6 h-6 border-2',
    lg: 'w-10 h-10 border-3',
};

export default function Spinner({ size = 'md', className }: SpinnerProps) {
    return (
        <div
            className={cn(
                'rounded-full animate-spin',
                sizeClasses[size],
                className,
            )}
            style={{
                borderColor: 'var(--color-border)',
                borderTopColor: 'var(--color-primary)',
            }}
            role="status"
            aria-label="Loading"
        />
    );
}
