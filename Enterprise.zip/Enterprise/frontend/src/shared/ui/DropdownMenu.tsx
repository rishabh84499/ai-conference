import { useState, useRef, useEffect, useLayoutEffect, type ReactNode } from 'react';
import { createPortal } from 'react-dom';

interface DropdownMenuProps {
    trigger: ReactNode;
    children: ReactNode;
    align?: 'left' | 'right';
}

export function DropdownMenu({ trigger, children, align = 'right' }: DropdownMenuProps) {
    const [isOpen, setIsOpen] = useState(false);
    const [coords, setCoords] = useState({ top: 0, left: 0, width: 0 });
    const triggerRef = useRef<HTMLDivElement>(null);
    const menuRef = useRef<HTMLDivElement>(null);

    const updateCoords = () => {
        if (triggerRef.current) {
            const rect = triggerRef.current.getBoundingClientRect();
            setCoords({
                top: rect.bottom + window.scrollY,
                left: rect.left + window.scrollX,
                width: rect.width,
            });
        }
    };

    useLayoutEffect(() => {
        if (isOpen) {
            updateCoords();
        }
    }, [isOpen]);

    useEffect(() => {
        if (!isOpen) return;

        const handleScroll = () => updateCoords();
        const handleResize = () => updateCoords();

        window.addEventListener('scroll', handleScroll, true);
        window.addEventListener('resize', handleResize);

        return () => {
            window.removeEventListener('scroll', handleScroll, true);
            window.removeEventListener('resize', handleResize);
        };
    }, [isOpen]);

    useEffect(() => {
        const handleClickOutside = (event: MouseEvent) => {
            if (
                triggerRef.current && !triggerRef.current.contains(event.target as Node) &&
                menuRef.current && !menuRef.current.contains(event.target as Node)
            ) {
                setIsOpen(false);
            }
        };
        document.addEventListener('mousedown', handleClickOutside);
        return () => document.removeEventListener('mousedown', handleClickOutside);
    }, []);

    useEffect(() => {
        const handleEscape = (event: KeyboardEvent) => {
            if (event.key === 'Escape') setIsOpen(false);
        };
        document.addEventListener('keydown', handleEscape);
        return () => document.removeEventListener('keydown', handleEscape);
    }, []);

    return (
        <div className="relative inline-block" ref={triggerRef}>
            <div className="cursor-pointer" onClick={() => setIsOpen(!isOpen)}>
                {trigger}
            </div>
            {isOpen && createPortal(
                <div
                    ref={menuRef}
                    style={{
                        position: 'absolute',
                        top: `${coords.top}px`,
                        left: align === 'right'
                            ? `${coords.left + coords.width}px`
                            : `${coords.left}px`,
                        transform: align === 'right' ? 'translateX(-100%)' : 'none',
                    }}
                    className="z-[100] mt-2 min-w-[200px] max-w-[280px] max-h-[400px] overflow-y-auto rounded-xl border border-border bg-popover/90 backdrop-blur-xl shadow-xl py-2 transition-all duration-200"
                    onClick={() => setIsOpen(false)}
                >
                    {children}
                </div>,
                document.body
            )}
        </div>
    );
}

import { cn } from "@/shared/utils/cn";

export interface DropdownMenuItemProps {
    onClick?: () => void;
    children: ReactNode;
    variant?: 'default' | 'danger';
    disabled?: boolean;
    className?: string;
}

export function DropdownMenuItem({ onClick, children, variant = 'default', disabled = false, className }: DropdownMenuItemProps) {
    return (
        <button
            type="button"
            onClick={onClick}
            disabled={disabled}
            className={cn(
                "w-full flex items-center gap-2 px-3 py-2 text-sm transition-colors cursor-pointer disabled:opacity-50 disabled:cursor-not-allowed",
                variant === 'danger'
                    ? 'text-red-500 hover:bg-red-500/10'
                    : 'text-popover-foreground/80 hover:bg-accent hover:text-accent-foreground',
                className
            )}
        >
            {children}
        </button>
    );
}

export function DropdownMenuSeparator() {
    return <div className="my-1 h-px bg-border" />;
}
