import { Modal } from './Modal';
import { Button } from './Button';
import { AlertTriangle, Info, HelpCircle } from 'lucide-react';
import { cn } from '@/shared/utils/cn';

interface ConfirmationModalProps {
    isOpen: boolean;
    onClose: () => void;
    onConfirm: () => Promise<void> | void;
    title: string;
    message: string;
    confirmText?: string;
    cancelText?: string;
    variant?: 'default' | 'destructive' | 'warning' | 'info';
    isLoading?: boolean;
}

export function ConfirmationModal({
    isOpen,
    onClose,
    onConfirm,
    title,
    message,
    confirmText = 'Confirm',
    cancelText = 'Cancel',
    variant = 'default',
    isLoading = false
}: ConfirmationModalProps) {

    const icons = {
        default: <HelpCircle className="h-5 w-5 text-primary" />,
        destructive: <AlertTriangle className="h-5 w-5 text-destructive" />,
        warning: <AlertTriangle className="h-5 w-5 text-amber-500" />,
        info: <Info className="h-5 w-5 text-blue-500" />
    };

    const variantStyles = {
        default: 'bg-primary/10 border-primary/20 text-primary',
        destructive: 'bg-destructive/10 border-destructive/20 text-destructive',
        warning: 'bg-amber-500/10 border-amber-500/20 text-amber-600 dark:text-amber-400',
        info: 'bg-blue-500/10 border-blue-500/20 text-blue-600 dark:text-blue-400'
    };

    const iconBgStyles = {
        default: 'bg-primary/20',
        destructive: 'bg-destructive/20',
        warning: 'bg-amber-500/20',
        info: 'bg-blue-500/20'
    };

    const confirmButtonVariants = {
        default: 'default' as const,
        destructive: 'destructive' as const,
        warning: 'default' as const,
        info: 'default' as const
    };

    return (
        <Modal
            isOpen={isOpen}
            onClose={onClose}
            title={title}
            maxWidth="sm"
        >
            <div className="space-y-6">
                <div className={cn("border rounded-xl p-4", variantStyles[variant])}>
                    <div className="flex items-start gap-4">
                        <div className={cn("flex-shrink-0 w-10 h-10 rounded-full flex items-center justify-center", iconBgStyles[variant])}>
                            {icons[variant]}
                        </div>
                        <div className="flex-1">
                            <p className="text-sm font-medium leading-relaxed">
                                {message}
                            </p>
                        </div>
                    </div>
                </div>

                {/* Actions */}
                <div className="flex justify-end gap-3 pt-4 border-t border-border/50">
                    <Button
                        type="button"
                        variant="outline"
                        onClick={onClose}
                        disabled={isLoading}
                    >
                        {cancelText}
                    </Button>
                    <Button
                        type="button"
                        variant={confirmButtonVariants[variant]}
                        onClick={onConfirm}
                        isLoading={isLoading}
                        className={cn(
                            variant === 'warning' && "bg-amber-500 hover:bg-amber-600 border-amber-500 text-white"
                        )}
                    >
                        {confirmText}
                    </Button>
                </div>
            </div>
        </Modal>
    );
}
