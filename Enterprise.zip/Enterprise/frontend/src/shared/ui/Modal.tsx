import * as React from 'react';
import * as Dialog from '@radix-ui/react-dialog';
import { X } from 'lucide-react';
import { Button } from './Button';

interface ModalProps {
    isOpen: boolean;
    onClose: () => void;
    title: string;
    description?: string;
    children: React.ReactNode;
    maxWidth?: 'sm' | 'md' | 'lg' | 'xl' | '2xl';
}

export function Modal({
    isOpen,
    onClose,
    title,
    description,
    children,
    maxWidth = 'md'
}: ModalProps) {
    const maxWidthClasses = {
        sm: 'max-w-sm',
        md: 'max-w-md',
        lg: 'max-w-lg',
        xl: 'max-w-xl',
        '2xl': 'max-w-2xl',
    };

    return (
        <Dialog.Root open={isOpen} onOpenChange={(open) => !open && onClose()}>
            <Dialog.Portal>
                {/* Backdrop */}
                <Dialog.Overlay
                    className="fixed inset-0 z-50 bg-background/80 backdrop-blur-sm transition-opacity data-[state=open]:animate-in data-[state=closed]:animate-out data-[state=closed]:fade-out-0 data-[state=open]:fade-in-0"
                />

                {/* Modal Content */}
                <Dialog.Content
                    className={`fixed left-[50%] top-[50%] z-50 flex flex-col w-full ${maxWidthClasses[maxWidth]} translate-x-[-50%] translate-y-[-50%] border border-border/50 bg-card shadow-2xl shadow-primary/5 duration-200 data-[state=open]:animate-in data-[state=closed]:animate-out data-[state=closed]:fade-out-0 data-[state=open]:fade-in-0 data-[state=closed]:zoom-out-95 data-[state=open]:zoom-in-95 data-[state=closed]:slide-out-to-left-1/2 data-[state=closed]:slide-out-to-top-[48%] data-[state=open]:slide-in-from-left-1/2 data-[state=open]:slide-in-from-top-[48%] sm:rounded-xl overflow-hidden`}
                    aria-describedby={description ? "modal-description" : undefined}
                >
                    {/* Header */}
                    <div className="flex items-center justify-between p-6 border-b border-border/50 bg-muted/30 flex-none">
                        <div className="space-y-1">
                            <Dialog.Title className="text-lg font-semibold text-foreground">
                                {title}
                            </Dialog.Title>
                            {description && (
                                <Dialog.Description id="modal-description" className="text-sm text-muted-foreground">
                                    {description}
                                </Dialog.Description>
                            )}
                        </div>
                        <Dialog.Close asChild>
                            <Button
                                type="button"
                                variant="ghost"
                                size="icon"
                                className="h-8 w-8 text-muted-foreground hover:text-foreground hover:bg-muted/50"
                            >
                                <X size={18} />
                                <span className="sr-only">Close</span>
                            </Button>
                        </Dialog.Close>
                    </div>

                    {/* Body */}
                    <div className="p-6 w-full">
                        {children}
                    </div>
                </Dialog.Content>
            </Dialog.Portal>
        </Dialog.Root>
    );
}
