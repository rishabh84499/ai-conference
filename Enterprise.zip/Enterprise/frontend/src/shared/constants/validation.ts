export const VALIDATION = {
    PASSWORD: {
        REGEX: /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[@$!%*?&#._-])[A-Za-z\d@$!%*?&#._-]{8,}$/,
        MESSAGE: 'Password must contain at least 8 characters, one uppercase letter, one lowercase letter, one number and one special character',
    },
    NAME: {
        MIN_LENGTH: 2,
        MAX_LENGTH: 50,
    },
    EMAIL: {
        MESSAGE: 'Invalid email address',
    },
};
