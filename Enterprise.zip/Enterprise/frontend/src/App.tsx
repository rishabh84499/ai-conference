import AppRouter from '@/router';

function App() {
  // Global error handling is now managed by QueryProvider (TanStack Query)
  // and ErrorBoundary (in main.tsx) for component crashes.

  return (
    <AppRouter />
  );
}

export default App;
