import { StrictMode } from 'react';
import { createRoot } from 'react-dom/client';
import { Provider } from 'react-redux';
import { PersistGate } from 'redux-persist/integration/react';
import { BrowserRouter } from 'react-router-dom';
import { HelmetProvider, Helmet } from 'react-helmet-async';
import { Toaster } from 'react-hot-toast';
import { store, persistor } from '@/core/store';
import { setupAxios } from '@/core/api/client';
import QueryProvider from '@/core/providers/QueryProvider';
import { ThemeProvider } from '@/core/context/ThemeProvider';
import { SocketProvider } from '@/core/context/SocketContext';
import '@/core/i18n/config'; // Import i18n config
import App from './App';
import './index.css';

import { ErrorBoundary } from '@/core/components/ErrorBoundary';

setupAxios(store);

createRoot(document.getElementById('root')!).render(
  <StrictMode>
    <Provider store={store}>
      <PersistGate loading={null} persistor={persistor}>
        <QueryProvider>
          <SocketProvider>
            <HelmetProvider>
              <ThemeProvider defaultTheme="dark" storageKey="vite-ui-theme">
                <Helmet>
                  <meta
                    httpEquiv="Content-Security-Policy"
                    content={`
                    default-src 'self';
                    script-src 'self' 'unsafe-inline' 'unsafe-eval' https://checkout.razorpay.com https://*.razorpay.com;
                    style-src 'self' 'unsafe-inline' https://fonts.googleapis.com;
                    font-src 'self' data: https://fonts.gstatic.com;
                    img-src 'self' data: https://* blob:;
                    connect-src 'self' ${import.meta.env.VITE_API_BASE_URL || 'http://localhost:5000'} ws://localhost:5173 ws://localhost:5000 https://api.razorpay.com https://*.razorpay.com;
                    frame-src 'self' https://api.razorpay.com https://checkout.razorpay.com https://*.razorpay.com;
                    object-src 'none';
                    base-uri 'self';
                    form-action 'self';
                    frame-ancestors 'none';
                    upgrade-insecure-requests;
                  `.replace(/\s{2,}/g, ' ').trim()}
                  />
                </Helmet>
                <BrowserRouter>
                  <ErrorBoundary>
                    <App />
                  </ErrorBoundary>
                  <Toaster
                    position="top-right"
                    toastOptions={{
                      duration: 4000,
                      style: {
                        background: 'hsl(var(--card))',
                        color: 'hsl(var(--foreground))',
                        border: '1px solid hsl(var(--border))',
                        borderRadius: 'var(--radius-lg)',
                        fontSize: '0.875rem',
                      },
                      success: {
                        iconTheme: { primary: 'hsl(var(--primary))', secondary: 'white' },
                      },
                      error: {
                        iconTheme: { primary: 'hsl(var(--destructive))', secondary: 'white' },
                      },
                    }}
                  />
                </BrowserRouter>
              </ThemeProvider>
            </HelmetProvider>
          </SocketProvider>
        </QueryProvider>
      </PersistGate>
    </Provider>
  </StrictMode>,
);
