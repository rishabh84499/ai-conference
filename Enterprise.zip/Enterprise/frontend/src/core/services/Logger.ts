import { env } from '@/core/config/env';

type LogLevel = 'info' | 'warn' | 'error' | 'debug';

/**
 * Enterprise Logger Service
 * Abstraction layer for logging to allow swapping implementations (Console vs Sentry/Datadog)
 * and controlling verbosity based on environment.
 */
class LoggerService {
    private isDev = import.meta.env.DEV;
    private isApiLoggingEnabled = env.VITE_ENABLE_API_LOGGING ?? false;

    private log(level: LogLevel, message: string, ...args: unknown[]) {
        if (this.isDev || level === 'error') {
            const timestamp = new Date().toISOString();
            const prefix = `[${timestamp}] [${level.toUpperCase()}]`;

            switch (level) {
                case 'info':
                    console.info(prefix, message, ...args);
                    break;
                case 'warn':
                    console.warn(prefix, message, ...args);
                    break;
                case 'error':
                    console.error(prefix, message, ...args);
                    break;
                case 'debug':
                    if (this.isApiLoggingEnabled) {
                        console.debug(prefix, message, ...args);
                    }
                    break;
            }
        }

        // TODO: In production, send 'error' and 'warn' levels to Sentry/Datadog
        if (!this.isDev && level === 'error') {
            // Sentry.captureException(args[0] || message);
        }
    }

    info(message: string, ...args: unknown[]) {
        this.log('info', message, ...args);
    }

    warn(message: string, ...args: unknown[]) {
        this.log('warn', message, ...args);
    }

    error(message: string, ...args: unknown[]) {
        this.log('error', message, ...args);
    }

    debug(message: string, ...args: unknown[]) {
        this.log('debug', message, ...args);
    }
}

export const Logger = new LoggerService();
