import apiClient from '@/core/api/client';
import { ENDPOINTS } from '@/core/api/endpoints';
import type { ApiResponse } from '@/core/types/api';

export interface AgoraTokenResponse {
    token: string;
    channelName: string;
    uid: number;
}

export const CallService = {
    /**
     * Fetch Agora RTC token for a channel
     */
    getToken: async (channelName: string, uid?: number) => {
        const response = await apiClient.post<ApiResponse<AgoraTokenResponse>>(ENDPOINTS.CALL.TOKEN, {
            channelName,
            uid,
        });
        return response.data.data;
    },
};
