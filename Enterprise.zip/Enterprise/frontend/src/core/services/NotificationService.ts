import apiClient from '@/core/api/client';
import type { PaginatedResponse } from '@/core/types/api';

// Define Notification Type locally or import if I made a types file.
// I'll define it here for now or update a types file.
export interface Notification {
    id: string;
    recipient: string;
    type: 'security' | 'system' | 'marketing' | 'activity';
    title: string;
    message: string;
    read: boolean;
    createdAt: string;
}

import type { ApiResponse } from '@/core/types/api';

export const NotificationService = {
    getAll: async (params?: { page?: number; limit?: number; sortBy?: string }) => {
        const { data } = await apiClient.get<ApiResponse<PaginatedResponse<Notification>>>('/notifications', { params });
        return data.data;
    },

    markAsRead: async (id: string) => {
        const { data } = await apiClient.patch<ApiResponse<Notification>>(`/notifications/${id}/read`);
        return data.data;
    },

    markAllAsRead: async () => {
        await apiClient.patch<ApiResponse<null>>('/notifications/read-all');
    },

    delete: async (id: string) => {
        await apiClient.delete<ApiResponse<null>>(`/notifications/${id}`);
    },

    deleteAll: async () => {
        await apiClient.delete<ApiResponse<null>>('/notifications/all');
    }
};

