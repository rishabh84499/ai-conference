import React, { createContext, useContext, useEffect, useState } from 'react';
import { io, Socket } from 'socket.io-client';
// Use a selector or hook to get the token directly if possible, or pass it in.
// Assuming we store token in localStorage or have a way to access it.
// For better integration, we might need to access the store state.
import { useSelector } from 'react-redux';
// Assuming root state type is available or use 'any' for now if strictly typed.
// Import store type if available. 

interface SocketContextType {
    socket: Socket | null;
    isConnected: boolean;
    emitCall: (to: string, offer: any, channelName: string) => void;
    emitAnswer: (to: string, answer: any) => void;
    emitRejectCall: (to: string) => void;
    emitEndCall: (to: string) => void;
}

const SocketContext = createContext<SocketContextType>({
    socket: null,
    isConnected: false,
    emitCall: () => { },
    emitAnswer: () => { },
    emitRejectCall: () => { },
    emitEndCall: () => { },
});

export const useSocketContext = () => useContext(SocketContext);

interface SocketProviderProps {
    children: React.ReactNode;
}

export const SocketProvider: React.FC<SocketProviderProps> = ({ children }) => {
    const [socket, setSocket] = useState<Socket | null>(null);
    const [isConnected, setIsConnected] = useState(false);

    // Access token from Redux store
    const token = useSelector((state: any) => state.auth?.tokens?.access?.token);
    const user = useSelector((state: any) => state.auth?.user);

    useEffect(() => {
        if (token && user) {
            // Environment variable for backend URL
            const SOCKET_URL = import.meta.env.VITE_API_BASE_URL || 'http://localhost:5000/api/v1';

            // Remove /api/v1 if present in the URL, as socket connects to root usually
            const baseUrl = SOCKET_URL.replace(/\/api\/v1\/?$/, '');

            const socketInstance = io(baseUrl, {
                auth: {
                    token: token
                },
                transports: ['websocket'], // Force websocket
                reconnection: true,
            });

            socketInstance.on('connect', () => {
                console.log('Socket connected');
                setIsConnected(true);
            });

            socketInstance.on('disconnect', () => {
                console.log('Socket disconnected');
                setIsConnected(false);
            });

            socketInstance.on('connect_error', (err) => {
                console.error('Socket connection error:', err);
            });

            setSocket(socketInstance);

            return () => {
                socketInstance.disconnect();
            };
        } else {
            // If no token/user, disconnect existing socket
            if (socket) {
                socket.disconnect();
                setSocket(null);
                setIsConnected(false);
            }
        }
    }, [token, user?.id]);

    const emitCall = (to: string, offer: any, channelName: string) => {
        socket?.emit('call-user', { to, offer, channelName });
    };

    const emitAnswer = (to: string, answer: any) => {
        socket?.emit('make-answer', { to, answer });
    };

    const emitRejectCall = (to: string) => {
        socket?.emit('reject-call', { to });
    };

    const emitEndCall = (to: string) => {
        socket?.emit('end-call', { to });
    };

    return (
        <SocketContext.Provider value={{
            socket,
            isConnected,
            emitCall,
            emitAnswer,
            emitRejectCall,
            emitEndCall
        }}>
            {children}
        </SocketContext.Provider>
    );
};
