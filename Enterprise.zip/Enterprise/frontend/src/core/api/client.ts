import axios from 'axios';
import type { AxiosError, InternalAxiosRequestConfig } from 'axios';
import type { RootState, AppDispatch } from '@/core/store';
import { clearAuth, setTokens, type Tokens } from '@/features/auth/store/authSlice';
import { ENDPOINTS } from '@/core/api/endpoints';
import { env } from '@/core/config/env';
import { Logger } from '@/core/services/Logger';
import type { ApiResponse } from '@/core/types/api';

// ── Axios Instance ─────────────────────────────────────────
const apiClient = axios.create({
    baseURL: env.VITE_API_BASE_URL,
    timeout: 15000,
    headers: {
        'Content-Type': 'application/json',
    },
    withCredentials: true, // Essential for HttpOnly Cookies
});

// ── Store Setup ────────────────────────────────────────────
export const setupAxios = (store: { getState: () => RootState; dispatch: AppDispatch }) => {

    // ── Request Interceptor ────────────────────────────────────
    apiClient.interceptors.request.use(
        (config: InternalAxiosRequestConfig) => {
            const state = store.getState();
            const token = state.auth.tokens?.access?.token;

            if (token && config.headers) {
                config.headers.Authorization = `Bearer ${token}`;
            }

            return config;
        },
        (error) => {
            Logger.error('Request Error:', error);
            return Promise.reject(error);
        },
    );

    // ── Response Interceptor (401 → Token Refresh) ─────────────
    let isRefreshing = false;
    let failedQueue: Array<{
        resolve: (value: unknown) => void;
        reject: (reason: unknown) => void;
    }> = [];

    const processQueue = (error: unknown) => {
        failedQueue.forEach((prom) => {
            if (error) {
                prom.reject(error);
            } else {
                prom.resolve(undefined);
            }
        });
        failedQueue = [];
    };

    apiClient.interceptors.response.use(
        (response) => response,
        async (error: AxiosError) => {
            const originalRequest = error.config as InternalAxiosRequestConfig & { _retry?: boolean };

            // Check if 401 and not already retried
            if (error.response?.status === 401 && !originalRequest._retry) {
                if (isRefreshing) {
                    return new Promise((resolve, reject) => {
                        failedQueue.push({ resolve, reject });
                    }).then(() => apiClient(originalRequest));
                }

                originalRequest._retry = true;
                isRefreshing = true;

                try {
                    Logger.debug('Attempting to refresh token via Cookie...');

                    // Call refresh endpoint - Cookie will be sent automatically due to withCredentials
                    const { data } = await axios.post<ApiResponse<{ tokens: Tokens }>>(
                        `${env.VITE_API_BASE_URL}${ENDPOINTS.AUTH.REFRESH}`,
                        {}, // No body needed, refresh token is in cookie
                        { withCredentials: true }
                    );

                    const newTokens = data?.data?.tokens;
                    if (!newTokens) throw new Error('Refresh response missing tokens');

                    store.dispatch(setTokens(newTokens));
                    Logger.debug('Token refresh successful');
                    processQueue(null);

                    // Ensure the retry uses the NEW token
                    if (originalRequest.headers) {
                        originalRequest.headers.Authorization = `Bearer ${newTokens.access.token}`;
                    }

                    return apiClient(originalRequest);
                } catch (refreshError) {
                    Logger.error('Token refresh failed:', refreshError);
                    processQueue(refreshError);
                    store.dispatch(clearAuth());

                    return Promise.reject(refreshError);
                } finally {
                    isRefreshing = false;
                }
            }

            // Global Error Handling: Handled by QueryProvider globally
            if (error.code !== 'ERR_CANCELED') {
                if (error.response?.status === 403) {
                    // Suspended or Inactive Account
                    store.dispatch(clearAuth());
                    window.location.href = '/login';
                }
                Logger.error('API Error:', error.message, error.response?.data);
            }

            return Promise.reject(error);
        },
    );
};

export default apiClient;
