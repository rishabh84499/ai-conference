export const ENDPOINTS = {
    AUTH: {
        LOGIN: '/auth/login',
        REFRESH: '/auth/refresh-tokens',
        LOGOUT: '/auth/logout',
        PROFILE: '/auth/profile',
        FORGOT_PASSWORD: '/auth/forgot-password',
        RESET_PASSWORD: '/auth/reset-password',
        CHANGE_PASSWORD: '/auth/change-password',
    },
    USERS: {
        BASE: '/users',
        BY_ID: (id: string) => `/users/${id}`,
    },
    PAYMENT: {
        LIST: '/payment',
        CREATE_ORDER: '/payment/create-order',
        VERIFY: '/payment/verify',
        REFUND: '/payment/refund',
    },
    CALL: {
        TOKEN: '/call/token',
    },
} as const;
