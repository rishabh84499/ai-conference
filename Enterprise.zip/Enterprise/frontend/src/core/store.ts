import { configureStore, combineReducers } from '@reduxjs/toolkit';
import { useDispatch, useSelector, type TypedUseSelectorHook } from 'react-redux';
import {
    persistStore,
    persistReducer,
    FLUSH,
    REHYDRATE,
    PAUSE,
    PERSIST,
    PURGE,
    REGISTER,
} from 'redux-persist';
import storage from 'redux-persist/lib/storage';
import authReducer from '@/features/auth/store/authSlice';

// ── Persist Config ─────────────────────────────────────────
const persistConfig = {
    key: 'enterprise',
    version: 1,
    storage,
    whitelist: ['auth'], // Only persist auth state
};

// ── Root Reducer ───────────────────────────────────────────
const rootReducer = combineReducers({
    auth: authReducer,
});

// Derive RootState from rootReducer so slice types are properly exposed
export type RootState = ReturnType<typeof rootReducer>;

// eslint-disable-next-line @typescript-eslint/no-explicit-any
const persistedReducer = persistReducer<RootState>(persistConfig, rootReducer);

// ── Store ──────────────────────────────────────────────────
export const store = configureStore({
    reducer: persistedReducer,
    middleware: (getDefaultMiddleware) =>
        getDefaultMiddleware({
            serializableCheck: {
                ignoredActions: [FLUSH, REHYDRATE, PAUSE, PERSIST, PURGE, REGISTER],
            },
        }),
    devTools: import.meta.env.DEV,
});

export const persistor = persistStore(store);

// ── Typed Hooks ────────────────────────────────────────────
export type AppDispatch = typeof store.dispatch;

export const useAppDispatch: () => AppDispatch = useDispatch;
export const useAppSelector: TypedUseSelectorHook<RootState> = useSelector;

