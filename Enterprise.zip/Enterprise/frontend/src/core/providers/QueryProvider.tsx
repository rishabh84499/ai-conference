import { QueryClient, QueryClientProvider, QueryCache, MutationCache } from '@tanstack/react-query';
import toast from 'react-hot-toast';
import type { AxiosError } from 'axios';
import type { ReactNode } from 'react';

const queryClient = new QueryClient({
    queryCache: new QueryCache({
        onError: (error) => {
            const axiosError = error as AxiosError<{ message?: string }>;
            const message = axiosError.response?.data?.message || axiosError.message || 'An error occurred';
            if (axiosError.response?.status !== 401) {
                toast.error(message);
            }
        },
    }),
    mutationCache: new MutationCache({
        onError: (error) => {
            const axiosError = error as AxiosError<{ message?: string }>;
            const message = axiosError.response?.data?.message || axiosError.message || 'An error occurred';
            toast.error(message);
        },
    }),
    defaultOptions: {
        queries: {
            staleTime: 5 * 60 * 1000, // 5 minutes
            gcTime: 10 * 60 * 1000, // 10 minutes
            retry: 1,
            refetchOnWindowFocus: false,
            // Note: React Query v5 auto-cancels requests on component unmount
        },
        mutations: {
            retry: 0,
        },
    },
});

interface QueryProviderProps {
    children: ReactNode;
}

export default function QueryProvider({ children }: QueryProviderProps) {
    return (
        <QueryClientProvider client={queryClient}>
            {children}
            {/* Uncomment to enable: {import.meta.env.DEV && <ReactQueryDevtools initialIsOpen={false} />} */}
        </QueryClientProvider>
    );
}
