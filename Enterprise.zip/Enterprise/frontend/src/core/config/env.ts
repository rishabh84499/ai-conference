import { z } from 'zod';

const envSchema = z.object({
    VITE_API_BASE_URL: z.string().url(),
    VITE_ENABLE_API_LOGGING: z.string().optional().transform(val => val === 'true'),
    MODE: z.enum(['development', 'production', 'test']).default('development'),
    DEV: z.boolean().default(false),
    PROD: z.boolean().default(false),
});

const processEnv = {
    VITE_API_BASE_URL: import.meta.env.VITE_API_BASE_URL,
    VITE_ENABLE_API_LOGGING: import.meta.env.VITE_ENABLE_API_LOGGING,
    MODE: import.meta.env.MODE,
    DEV: import.meta.env.DEV,
    PROD: import.meta.env.PROD,
};

const parsed = envSchema.safeParse(processEnv);

if (!parsed.success) {
    console.error(
        '❌ Invalid environment variables:',
        JSON.stringify(parsed.error.format(), null, 4)
    );
    throw new Error('Invalid environment variables');
}

export const env = parsed.data;
