import { Link } from 'react-router-dom';

export default function NotFoundPage() {
    return (
        <div className="flex min-h-screen items-center justify-center" style={{ backgroundColor: 'var(--color-bg-primary)' }}>
            <div className="text-center max-w-md px-6">
                <h1
                    className="text-8xl font-extrabold mb-2 gradient-text"
                >
                    404
                </h1>
                <h2 className="text-2xl font-bold mb-2" style={{ color: 'var(--color-text-primary)' }}>
                    Page Not Found
                </h2>
                <p className="mb-8" style={{ color: 'var(--color-text-secondary)' }}>
                    The page you're looking for doesn't exist or has been moved.
                </p>
                <Link
                    to="/"
                    className="inline-flex items-center gap-2 px-6 py-3 rounded-lg font-medium transition-all"
                    style={{
                        backgroundColor: 'var(--color-primary)',
                        color: 'white',
                    }}
                >
                    ← Back to Home
                </Link>
            </div>
        </div>
    );
}
