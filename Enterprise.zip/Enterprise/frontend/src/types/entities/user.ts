/**
 * Global User Role Definition
 */
export const UserRole = {
    SUPER_ADMIN: 'SuperAdmin',
    ADMIN: 'Admin',
    MANAGER: 'Manager',
    OPERATOR: 'Operator',
} as const;

export type UserRole = typeof UserRole[keyof typeof UserRole];

/**
 * Global User Status Definition
 */
export const UserStatus = {
    ACTIVE: 'active',
    INACTIVE: 'inactive',
    SUSPENDED: 'suspended',
    PENDING: 'pending',
} as const;

export type UserStatus = typeof UserStatus[keyof typeof UserStatus];

/**
 * Enterprise User Entity
 */
export interface User {
    _id: string;
    firstName: string;
    lastName: string;
    email: string;
    role: UserRole;
    status: UserStatus;
    profileImage?: string;
    isEmailVerified: boolean;
    lastLogin?: string;
    createdAt: string;
    updatedAt: string;
    preferences?: UserPreferences;
}

export interface NotificationChannels {
    email: boolean;
    push: boolean;
    inApp: boolean;
}

export interface UserPreferences {
    notifications: {
        security: NotificationChannels;
        activity: NotificationChannels;
        marketing: NotificationChannels;
        system: NotificationChannels;
    };
}

/**
 * User Identity for Auth (sometimes includes flattened name)
 */
export interface AuthUser extends User {
    name?: string; // Computed or legacy name field
}
