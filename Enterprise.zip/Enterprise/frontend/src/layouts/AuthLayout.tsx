import { Outlet } from 'react-router-dom';

export default function AuthLayout() {
    return (
        <div className="min-h-screen w-full grid place-items-center p-4 relative overflow-hidden bg-background">
            {/* Animated Gradient Background Orbs */}
            <div className="absolute top-[-20%] left-[-10%] w-[500px] h-[500px] rounded-full opacity-60 mix-blend-multiply blur-[100px] bg-gradient-to-br from-indigo-500/40 to-purple-500/40 animate-float dark:opacity-40 dark:mix-blend-normal dark:from-indigo-600/50 dark:to-purple-600/50" />
            <div className="absolute bottom-[-20%] right-[-10%] w-[400px] h-[400px] rounded-full opacity-60 mix-blend-multiply blur-[100px] bg-gradient-to-br from-blue-500/40 to-cyan-500/40 animate-float-reverse dark:opacity-40 dark:mix-blend-normal dark:from-blue-600/50 dark:to-cyan-600/50" />

            <div className="w-full max-w-[480px] relative z-10 flex flex-col gap-8">
                {/* Brand Header */}
                <div className="text-center">
                    <div className="inline-flex items-center justify-center w-16 h-16 rounded-2xl mb-6 shadow-2xl bg-gradient-to-br from-indigo-500 to-purple-600 ring-1 ring-white/20">
                        <span className="text-3xl font-bold text-white drop-shadow-md">E</span>
                    </div>
                    <h1 className="text-4xl font-bold mb-2 bg-gradient-to-r from-indigo-600 via-purple-600 to-cyan-600 dark:from-white dark:via-indigo-200 dark:to-cyan-200 bg-clip-text text-transparent drop-shadow-sm">
                        Enterprise
                    </h1>
                    <p className="text-base text-gray-600 dark:text-muted-foreground/80 font-medium">
                        Secure enterprise management platform
                    </p>
                </div>

                {/* Auth Form Container — Glassmorphism Card */}
                <div className="w-full rounded-3xl p-6 sm:p-8 md:p-10 shadow-2xl border border-gray-200/50 dark:border-border/50 bg-white/60 dark:bg-black/40 backdrop-blur-2xl shadow-gray-200/50 dark:shadow-black/50 ring-1 ring-gray-200/50 dark:ring-white/5 hover:ring-gray-300/50 dark:hover:ring-white/10 transition-all duration-500">
                    <Outlet />
                </div>

                {/* Footer */}
                <p className="text-center text-xs text-muted-foreground/60 font-medium tracking-wide">
                    © {new Date().getFullYear()} Enterprise. All rights reserved.
                </p>
            </div>
        </div>
    );
}
