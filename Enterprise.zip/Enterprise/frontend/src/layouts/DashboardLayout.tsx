import { useState } from 'react';
import { Outlet, NavLink, useNavigate } from 'react-router-dom';
import { useTranslation } from 'react-i18next';
import { useAppSelector, useAppDispatch } from '@/core/store';
import { clearAuth } from '@/features/auth/store/authSlice';
import { LayoutDashboard, Users, Settings, LogOut, Menu, X, CreditCard, Video } from 'lucide-react';
import toast from 'react-hot-toast';
import NotificationDropdown from '@/features/dashboard/components/NotificationDropdown';

export default function DashboardLayout() {
    const { t } = useTranslation();
    const [sidebarOpen, setSidebarOpen] = useState(false);
    const user = useAppSelector((state) => state.auth.user);
    const dispatch = useAppDispatch();
    const navigate = useNavigate();

    const navItems = [
        { to: '/dashboard', icon: LayoutDashboard, label: t('nav.dashboard') },
        { to: '/dashboard/users', icon: Users, label: t('nav.users') },
        { to: '/dashboard/settings', icon: Settings, label: t('nav.settings') },
        { to: '/dashboard/payment-test', icon: CreditCard, label: 'Payment Test' },
        { to: '/dashboard/video-call-test', icon: Video, label: 'Video Call Test' },
    ];

    const handleLogout = () => {
        dispatch(clearAuth());
        toast.success(t('auth.login.success'));
        navigate('/login');
    };

    return (
        <div className="flex h-screen w-full bg-background overflow-hidden">
            {/* Sidebar Overlay (Mobile) */}
            {sidebarOpen && (
                <div
                    className="fixed inset-0 z-40 bg-black/50 lg:hidden"
                    onClick={() => setSidebarOpen(false)}
                    aria-hidden="true"
                />
            )}

            {/* Sidebar */}
            <aside
                className={`
                    fixed inset-y-0 left-0 z-50 w-64 bg-card/80 backdrop-blur-xl border-r border-border 
                    flex flex-col transition-transform duration-300 ease-out
                    lg:static lg:translate-x-0 
                    ${sidebarOpen ? 'translate-x-0 shadow-2xl' : '-translate-x-full'}
                `}
                aria-label={t('nav.title')}
            >
                {/* Sidebar Header */}
                <div className="flex-none flex items-center justify-between h-16 px-6 border-b border-border/50">
                    <div className="flex items-center gap-3">
                        <div className="w-8 h-8 rounded-lg bg-gradient-to-br from-indigo-500 to-purple-600 flex items-center justify-center text-white font-bold shadow-lg shadow-indigo-500/20">
                            E
                        </div>
                        <span className="text-lg font-bold bg-gradient-to-r from-foreground to-foreground/70 bg-clip-text text-transparent">{t('nav.title')}</span>
                    </div>
                    <button
                        className="lg:hidden p-1 rounded-md cursor-pointer text-muted-foreground hover:text-foreground hover:bg-muted/50 transition-colors"
                        onClick={() => setSidebarOpen(false)}
                        aria-label={t('nav.close_sidebar')}
                    >
                        <X size={20} />
                    </button>
                </div>

                {/* Nav Items */}
                <nav className="flex-1 overflow-y-auto px-4 py-6 space-y-1 scrollbar-thin">
                    {navItems.map((item) => (
                        <NavLink
                            key={item.to}
                            to={item.to}
                            end={item.to === '/dashboard'}
                            onClick={() => setSidebarOpen(false)}
                            className={({ isActive }) =>
                                `flex items-center gap-3 px-3 py-2.5 rounded-xl text-sm font-medium transition-all duration-200 group ${isActive
                                    ? 'bg-primary/10 text-primary shadow-sm ring-1 ring-primary/20'
                                    : 'text-muted-foreground hover:bg-muted/50 hover:text-foreground'
                                }`
                            }
                        >
                            <item.icon size={18} className="transition-transform group-hover:scale-110 duration-200" />
                            {item.label}
                        </NavLink>
                    ))}
                </nav>

                {/* Sidebar Footer */}
                <div className="flex-none px-4 py-4 border-t border-border/50">
                    <button
                        onClick={handleLogout}
                        className="flex items-center gap-3 px-3 py-2.5 rounded-xl text-sm font-medium w-full transition-all duration-200 cursor-pointer text-muted-foreground hover:text-destructive hover:bg-destructive/10 group"
                        aria-label={t('nav.logout')}
                    >
                        <LogOut size={18} className="transition-transform group-hover:-translate-x-1" />
                        {t('nav.logout')}
                    </button>
                </div>
            </aside>

            {/* Main Content Area */}
            <div className="flex-1 flex flex-col min-w-0 overflow-hidden bg-background/50">
                {/* Top Header */}
                <header className="flex-none h-16 flex items-center justify-between px-4 lg:px-8 bg-card/50 backdrop-blur-md border-b border-border/50 z-40 transition-all duration-200">
                    <button
                        className="lg:hidden p-2 rounded-lg cursor-pointer text-muted-foreground hover:text-foreground hover:bg-muted/50 transition-colors"
                        onClick={() => setSidebarOpen(true)}
                        aria-label={t('nav.open_sidebar')}
                    >
                        <Menu size={20} />
                    </button>

                    <div className="flex-1" />

                    {/* Notification Bell */}
                    <div className="flex items-center gap-2">
                        <NotificationDropdown />

                        <div className="h-6 w-px bg-border/50 mx-2" /> {/* Vertical Divider */}

                        {/* User Profile */}
                        <button
                            className="flex items-center gap-3 pl-2 pr-1 py-1.5 rounded-full cursor-pointer hover:bg-muted/50 transition-all border border-transparent hover:border-border/50 bg-card/30"
                            onClick={() => navigate('/dashboard/settings')}
                            aria-label={t('nav.user_settings')}
                        >
                            <div className="w-8 h-8 rounded-full flex items-center justify-center text-sm font-semibold bg-gradient-to-br from-indigo-500 to-purple-600 text-white shadow-md ring-2 ring-background">
                                {user?.firstName?.charAt(0)?.toUpperCase() || user?.name?.charAt(0)?.toUpperCase() || 'U'}
                            </div>
                            <span className="hidden sm:block text-sm font-medium text-foreground pr-2">
                                {user?.firstName ? user.firstName : (user?.name || 'User')}
                            </span>
                        </button>
                    </div>
                </header>

                {/* Page Content */}
                <main className="flex-1 overflow-y-auto p-4 lg:p-8 scrollbar-thin">
                    <div className="w-full animate-in fade-in duration-500">
                        <Outlet />
                    </div>
                </main>
            </div>
        </div>
    );
}
