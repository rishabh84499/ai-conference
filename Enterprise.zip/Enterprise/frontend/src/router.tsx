import { lazy, Suspense } from 'react';
import { Routes, Route, Navigate } from 'react-router-dom';
import RootLayout from '@/layouts/RootLayout';
import AuthLayout from '@/layouts/AuthLayout';
import DashboardLayout from '@/layouts/DashboardLayout';
import ProtectedRoute from '@/features/auth/components/ProtectedRoute';
import PublicRoute from '@/features/auth/components/PublicRoute'; // Import PublicRoute
import NotFoundPage from '@/core/errors/NotFoundPage';
import Spinner from '@/shared/ui/Spinner';

// ── Lazy-loaded Pages ──────────────────────────────────────
const LoginPage = lazy(() => import('@/features/auth/pages/LoginPage'));
const ForgotPasswordPage = lazy(() => import('@/features/auth/pages/ForgotPasswordPage'));
const ResetPasswordPage = lazy(() => import('@/features/auth/pages/ResetPasswordPage'));


// ── Dashboard Pages ──────────────────────────────────────────
const DashboardHome = lazy(() => import('@/features/dashboard/pages/DashboardHome'));
const UsersPage = lazy(() => import('@/features/dashboard/pages/UsersPage'));
const SettingsPage = lazy(() => import('@/features/dashboard/pages/SettingsPage'));
const NotificationsPage = lazy(() => import('@/features/dashboard/pages/NotificationsPage'));
const PaymentTestPage = lazy(() => import('@/features/dashboard/pages/PaymentTestPage'));
const VideoCallTestPage = lazy(() => import('@/features/dashboard/pages/VideoCallTestPage'));

// ── Suspense Fallback ──────────────────────────────────────
function PageLoader() {
    return (
        <div className="flex items-center justify-center min-h-[60vh]">
            <Spinner size="lg" />
        </div>
    );
}

export default function AppRouter() {
    return (
        <Suspense fallback={<PageLoader />}>
            <Routes>
                <Route element={<RootLayout />}>
                    {/* Auth Routes - Wrapped in PublicRoute to prevent access if logged in */}
                    <Route
                        element={
                            <PublicRoute>
                                <AuthLayout />
                            </PublicRoute>
                        }
                    >
                        <Route path="/login" element={<LoginPage />} />
                        <Route path="/forgot-password" element={<ForgotPasswordPage />} />
                        <Route path="/reset-password" element={<ResetPasswordPage />} />

                    </Route>

                    {/* Protected Dashboard Routes */}
                    <Route
                        path="/dashboard"
                        element={
                            <ProtectedRoute>
                                <DashboardLayout />
                            </ProtectedRoute>
                        }
                    >
                        <Route index element={<DashboardHome />} />
                        <Route path="users" element={<UsersPage />} />
                        <Route path="settings" element={<SettingsPage />} />
                        <Route path="notifications" element={<NotificationsPage />} />
                        <Route path="payment-test" element={<PaymentTestPage />} />
                        <Route path="video-call-test" element={<VideoCallTestPage />} />
                    </Route>

                    {/* Redirect root to dashboard (which redirects to login if needed) */}
                    <Route path="/" element={<Navigate to="/dashboard" replace />} />

                    {/* 404 */}
                    <Route path="*" element={<NotFoundPage />} />
                </Route>
            </Routes>
        </Suspense>
    );
}
