try {
    require('dotenv').config({ path: '.env.test' }); // Try loading explicitly
    const app = require('./app');
    console.log('App loaded successfully');
} catch (error) {
    console.error('App failed to load:', error);
}
