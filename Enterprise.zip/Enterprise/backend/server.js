const config = require('./src/config/index'); // Import configured env variables
const logger = require('./src/shared/logger.service');
const { initSocket } = require('./src/config/socket');

const http = require('http');
const mongoose = require('mongoose');
const app = require('./app'); // Import configured express app
const { connectDB } = require('./src/config/db'); // DB connection function

const PORT = config.port;

// Create HTTP server instance
const server = http.createServer(app);

const { initPaymentCleanup } = require('./src/cron/paymentCleanup');

// ... imports

// Connect to DB and start the server
(async () => {
    try {
        await connectDB();
        const io = initSocket(server);

        // Initialize Cron Jobs
        initPaymentCleanup();

        // Initialize processors
        const { processBroadcast } = require('./src/modules/notification/v1/services/broadcast.processor');

        logger.info(`Attempting to start server on port: ${PORT}`);

        server.on('error', (err) => {
            if (err.code === 'EADDRINUSE') {
                logger.error(`Port ${PORT} is already in use. Please kill the process or use a different port.`);
            } else {
                logger.error('Server error:', err);
            }
            process.exit(1);
        });

        server.listen(PORT, () => {
            logger.info(`Server running at http://localhost:${PORT}`);
            logger.info(`Socket.IO initialized`);
        });
    } catch (err) {
        logger.error('Server failed to start:', err);
        process.exit(1);
    }
})();

// Graceful shutdown function
const shutdown = (signal) => {
    logger.info(`${signal} received. Shutting down gracefully...`);

    server.close(async () => {
        logger.info('HTTP server closed.');
        try {
            await mongoose.connection.close();
            logger.info('Mongoose connection closed.');
            process.exit(0);
        } catch (err) {
            logger.error('Error during shutdown:', err);
            process.exit(1);
        }
    });

    // Force close after 10 seconds
    setTimeout(() => {
        logger.error('Could not close connections in time, forcefully shutting down');
        process.exit(1);
    }, 10000);
};


process.on('SIGTERM', () => shutdown('SIGTERM'));
process.on('SIGINT', () => shutdown('SIGINT'));
process.on('SIGUSR2', () => shutdown('SIGUSR2')); // Nodemon restart

process.on('unhandledRejection', (err) => {
    logger.error('Unhandled Rejection:', err);
    shutdown('unhandledRejection');
});

