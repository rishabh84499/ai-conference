try {
    console.log('Loading config...');
    const config = require('./src/config/index');
    console.log('Config loaded:', JSON.stringify(config, null, 2));

    console.log('Loading mongoose...');
    const mongoose = require('mongoose');
    console.log('Mongoose version:', mongoose.version);

    console.log('Connecting to DB...');
    mongoose.connect(config.mongoose.url, config.mongoose.options)
        .then(() => {
            console.log('DB Connected!');
            process.exit(0);
        })
        .catch(err => {
            console.error('DB Connection Failed:', err);
            process.exit(1);
        });
} catch (error) {
    console.error('Crash:', error);
    process.exit(1);
}
