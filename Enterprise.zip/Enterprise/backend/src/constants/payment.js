const PAYMENT_STATUS = {
    PENDING: 'pending',
    COMPLETED: 'completed',
    FAILED: 'failed',
    REFUNDED: 'refunded'
};

const PAYMENT_PROVIDERS = {
    RAZORPAY: 'razorpay',
    STRIPE: 'stripe',
    PAYPAL: 'paypal'
};

const CURRENCIES = {
    INR: 'INR',
    USD: 'USD',
    GBP: 'GBP',
    EUR: 'EUR',
    AED: 'AED',
    CAD: 'CAD',
    AUD: 'AUD',
    JPY: 'JPY'
};

module.exports = {
    PAYMENT_STATUS,
    PAYMENT_PROVIDERS,
    CURRENCIES
};
