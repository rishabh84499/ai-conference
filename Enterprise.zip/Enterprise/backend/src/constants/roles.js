// User roles for system administrators
const ROLES = {
  SUPER_ADMIN: 'SuperAdmin',
  ADMIN: 'Admin',
  MANAGER: 'Manager',
  OPERATOR: 'Operator',
};

// Role hierarchy - higher number = more permissions
const ROLE_HIERARCHY = {
  [ROLES.OPERATOR]: 1,
  [ROLES.MANAGER]: 2,
  [ROLES.ADMIN]: 3,
  [ROLES.SUPER_ADMIN]: 4,
};

// Permissions mapping
const PERMISSIONS = {
  // User Management
  CREATE_USER: [ROLES.SUPER_ADMIN, ROLES.ADMIN],
  READ_USERS: [ROLES.SUPER_ADMIN, ROLES.ADMIN, ROLES.MANAGER],
  UPDATE_USER: [ROLES.SUPER_ADMIN, ROLES.ADMIN],
  DELETE_USER: [ROLES.SUPER_ADMIN],
  CHANGE_USER_STATUS: [ROLES.SUPER_ADMIN, ROLES.ADMIN],
  RESET_USER_PASSWORD: [ROLES.SUPER_ADMIN, ROLES.ADMIN],

  // System Settings
  MANAGE_SETTINGS: [ROLES.SUPER_ADMIN],

  // Reports
  VIEW_REPORTS: [ROLES.SUPER_ADMIN, ROLES.ADMIN, ROLES.MANAGER],
  EXPORT_REPORTS: [ROLES.SUPER_ADMIN, ROLES.ADMIN],

  // Profile Management
  UPDATE_OWN_PROFILE: [ROLES.SUPER_ADMIN, ROLES.ADMIN, ROLES.MANAGER, ROLES.OPERATOR],
};

/**
 * Check if a role has a specific permission
 * @param {string} role
 * @param {string} permission
 * @returns {boolean}
 */
const hasPermission = (role, permission) => {
  if (!PERMISSIONS[permission]) return false;
  return PERMISSIONS[permission].includes(role);
};

/**
 * Get all roles with a specific permission
 * @param {string} permission
 * @returns {string[]}
 */
const getRolesWithPermission = (permission) => {
  return PERMISSIONS[permission] || [];
};

module.exports = {
  ROLES,
  ROLE_HIERARCHY,
  PERMISSIONS,
  hasPermission,
  getRolesWithPermission,
};
