// Regular expressions for validation
const PATTERNS = {
    // RFC 5322 Official Standard
    EMAIL: /^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$/,

    // At least 8 chars, 1 uppercase, 1 lowercase, 1 number, 1 special char
    PASSWORD_STRONG: /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[@$!%*?&])[A-Za-z\d@$!%*?&]{8,}$/,

    // Only alphanumeric, undoes, hyphens, 3-30 chars
    USERNAME: /^[a-zA-Z0-9_-]{3,30}$/,

    // E.164 format (e.g. +14155552671)
    PHONE_E164: /^\+[1-9]\d{1,14}$/,

    // URL validation
    URL: /^(https?:\/\/)?([\da-z\.-]+)\.([a-z\.]{2,6})([\/\w \.-]*)*\/?$/,

    // MongoDB ObjectId
    MONGO_ID: /^[0-9a-fA-F]{24}$/,
};

module.exports = PATTERNS;
