/**
 * specific function to catch errors in async functions
 * @param {Promise} fn
 * @returns {Promise}
 */
const catchAsync = (fn) => (req, res, next) => {
    Promise.resolve(fn(req, res, next)).catch((err) => next(err));
};

module.exports = catchAsync;
