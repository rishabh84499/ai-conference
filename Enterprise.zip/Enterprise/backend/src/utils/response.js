const httpStatus = require('../constants/httpStatus');

/**
 * Send success response
 * @param {Object} res - Express response object
 * @param {string} message - Success message
 * @param {*} data - Response data
 * @param {number} statusCode - HTTP status code
 */
const sendSuccess = (res, message = "Success", data = null, statusCode = httpStatus.OK) => {
    const response = {
        success: true,
        message,
    };

    if (data !== null) {
        response.data = data;
    }

    return res.status(statusCode).json(response);
};

/**
 * Send error response
 * @param {Object} res - Express response object
 * @param {string} message - Error message
 * @param {*} errors - Error details
 * @param {number} statusCode - HTTP status code
 */
const sendError = (res, message = "Something went wrong", errors = null, statusCode = httpStatus.INTERNAL_SERVER_ERROR) => {
    const response = {
        success: false,
        message,
    };

    if (errors) {
        response.errors = errors;
    }

    return res.status(statusCode).json(response);
};

/**
 * Send paginated response
 * @param {Object} res - Express response object
 * @param {Array} data - Response data array
 * @param {Object} pagination - Pagination info
 * @param {string} message - Success message
 */
const sendPaginatedResponse = (res, results, pagination, message = "Success") => {
    return res.status(httpStatus.OK).json({
        success: true,
        message,
        data: {
            results,
            page: pagination.page,
            limit: pagination.limit,
            totalResults: pagination.total,
            totalPages: Math.ceil(pagination.total / pagination.limit),
        },
    });
};

module.exports = {
    sendSuccess,
    sendError,
    sendPaginatedResponse,
};
