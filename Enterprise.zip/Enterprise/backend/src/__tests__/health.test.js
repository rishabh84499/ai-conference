const request = require('supertest');
const app = require('../../app');
const mongoose = require('mongoose');

describe('Health Check', () => {
    beforeAll(async () => {
        // Mongoose might already be connected if app.js imports db connection
        // But in testing env, we usually want to mock or use a test db.
        // For this simple health check, we just want to ensure the app mounts.
    });

    afterAll(async () => {
        await mongoose.disconnect();
    });

    test('GET /api/v1/health should return 404 (if not implemented) or 200', async () => {
        // We don't have a specific health route yet, so let's hit a known 404 or a public route.
        // Let's try the root API
        const res = await request(app).get('/api/v1/health');
        // Since we don't have a health route, it might 404, which proves the app is running.
        expect(res.status).toBeOneOf([200, 404]);
    });
});

// Extend jest matchers if needed, or just use standard checks
expect.extend({
    toBeOneOf(received, validOptions) {
        const pass = validOptions.includes(received);
        if (pass) {
            return {
                message: () => `expected ${received} not to be one of [${validOptions}]`,
                pass: true,
            };
        } else {
            return {
                message: () => `expected ${received} to be one of [${validOptions}]`,
                pass: false,
            };
        }
    },
});
