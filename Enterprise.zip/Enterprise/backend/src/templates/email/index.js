const fs = require('fs');
const path = require('path');
const Handlebars = require('handlebars');
const logger = require('../../shared/logger.service');

const TEMPLATES_DIR = path.join(__dirname);

// Cache compiled templates in memory to avoid repeated disk reads + compilation
const templateCache = new Map();

/**
 * Load and compile a .hbs email template, then render with data.
 *
 * Templates are Handlebars (.hbs) files stored in /src/templates/email/.
 * Supports all Handlebars features: {{variable}}, {{#if}}, {{#each}}, partials, etc.
 *
 * @param {string} templateName - File name without extension (e.g. 'welcome-credentials')
 * @param {Object} data - Variables to inject into the template
 * @returns {string} Rendered HTML string
 *
 * @example
 *   const html = loadTemplate('welcome-credentials', {
 *       user_name: 'John Doe',
 *       email: 'john@example.com',
 *       password: 'abc123',
 *       role: 'consultant',
 *   });
 */
function loadTemplate(templateName, data = {}) {
    let compiledTemplate = templateCache.get(templateName);

    if (!compiledTemplate) {
        const filePath = path.join(TEMPLATES_DIR, `${templateName}.hbs`);

        if (!fs.existsSync(filePath)) {
            logger.error(`[EmailTemplate] Template not found: ${filePath}`);
            throw new Error(`Email template "${templateName}" not found`);
        }

        const source = fs.readFileSync(filePath, 'utf-8');
        compiledTemplate = Handlebars.compile(source);

        // Cache compiled template in production
        if (process.env.NODE_ENV === 'production') {
            templateCache.set(templateName, compiledTemplate);
        }
    }

    return compiledTemplate(data);
}

module.exports = { loadTemplate };
