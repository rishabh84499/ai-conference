const Notification = require('./notification.model');
const notificationController = require('./v1/controllers/notification.controller');
const notificationRoutes = require('./v1/routes/notification.routes');
const notificationService = require('./v1/services/notification.service');

module.exports = {
    Notification,
    notificationController,
    notificationRoutes,
    notificationRoutes,
    notificationService
};
