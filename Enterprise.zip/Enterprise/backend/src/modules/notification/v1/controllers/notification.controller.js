const httpStatus = require('../../../../constants/httpStatus');
const pick = require('../../../../utils/pick');
const catchAsync = require('../../../../utils/catchAsync');
const notificationService = require('../services/notification.service');
const { SUCCESS } = require('../../../../constants/messages'); // Assuming SUCCESS messages exist or use strings

const createNotification = async (notificationBody) => {
    return notificationService.createNotification(notificationBody);
};

const getNotifications = catchAsync(async (req, res) => {
    const filter = { recipient: req.user.id };
    const options = pick(req.query, ['sortBy', 'limit', 'page']);
    const result = await notificationService.queryNotifications(filter, options);
    res.send({ success: true, data: result });
});


const markAsRead = catchAsync(async (req, res) => {
    const notification = await notificationService.markAsRead(req.params.notificationId, req.user.id);
    res.send(notification);
});

const markAllAsRead = catchAsync(async (req, res) => {
    await notificationService.markAllAsRead(req.user.id);
    res.status(httpStatus.NO_CONTENT).send();
});

const deleteNotification = catchAsync(async (req, res) => {
    await notificationService.deleteNotification(req.params.notificationId, req.user.id);
    res.status(httpStatus.NO_CONTENT).send();
});

const deleteAllNotifications = catchAsync(async (req, res) => {
    await notificationService.deleteAllNotifications(req.user.id);
    res.status(httpStatus.NO_CONTENT).send();
});

const broadcastNotification = catchAsync(async (req, res) => {
    const broadcast = await notificationService.createBroadcast(req.body, req.user.id);

    // Process asynchronously
    // We don't await this so the response is fast
    const { processBroadcast } = require('../services/broadcast.processor');
    processBroadcast(broadcast._id).catch(err => {
        console.error('Broadcast processing failed:', err);
    });

    res.status(httpStatus.ACCEPTED).send({
        message: 'Broadcast started successfully',
        broadcastId: broadcast._id
    });
});

module.exports = {
    createNotification,
    getNotifications,
    markAsRead,
    markAllAsRead,
    deleteNotification,
    deleteAllNotifications,
    broadcastNotification
};

