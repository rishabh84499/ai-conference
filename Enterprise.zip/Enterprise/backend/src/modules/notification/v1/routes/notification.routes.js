const express = require('express');
const notificationController = require('../controllers/notification.controller');
const { authenticate } = require('../../../../middlewares/auth.middleware');
const { validateParams } = require('../../../../middlewares/validate.middleware');
const {
    markAsRead,
    deleteNotification
} = require('../validators/notification.validator');

const router = express.Router();

router.use(authenticate);

router.get('/', notificationController.getNotifications);
router.patch('/read-all', notificationController.markAllAsRead);
router.delete('/all', notificationController.deleteAllNotifications);
router.patch('/:notificationId/read', validateParams(markAsRead), notificationController.markAsRead);
router.delete('/:notificationId', validateParams(deleteNotification), notificationController.deleteNotification);

// Broadcast route - Protected by RBAC and Role
const { ROLES } = require('../../../../constants/roles');
const { authorize } = require('../../../../middlewares/auth.middleware');
const { broadcastLimiter } = require('../../../../middlewares/rateLimiter.middleware');
const { validate } = require('../../../../middlewares/validate.middleware');
const { broadcastNotification } = require('../validators/notification.validator');

router.post(
    '/broadcast',
    authorize(ROLES.SUPER_ADMIN, ROLES.ADMIN, ROLES.MANAGER),
    broadcastLimiter,
    validate(broadcastNotification),
    notificationController.broadcastNotification
);


module.exports = router;
