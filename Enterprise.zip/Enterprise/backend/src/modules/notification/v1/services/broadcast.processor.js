const { User, USER_STATUS } = require('../../../user/user.model');
const Notification = require('../../notification.model');
const Broadcast = require('../../../../models/broadcast.model');
const { getIo } = require('../../../../config/socket');
const logger = require('../../../../shared/logger.service');

const BATCH_SIZE = 100;

/**
 * Process a broadcast job
 * @param {ObjectId} broadcastId
 */
const processBroadcast = async (broadcastId) => {
    logger.info(`[BroadcastProcessor] Starting broadcast job: ${broadcastId}`);

    const broadcast = await Broadcast.findById(broadcastId);
    if (!broadcast) {
        logger.error(`[BroadcastProcessor] Broadcast not found: ${broadcastId}`);
        return;
    }

    try {
        broadcast.status = 'PROCESSING';
        broadcast.startedAt = new Date();
        await broadcast.save();

        // Count total active users
        const totalUsers = await User.countDocuments({ status: USER_STATUS.ACTIVE });
        broadcast.stats.totalUsers = totalUsers;
        await broadcast.save();

        const io = getIo();
        let processed = 0;
        let success = 0;

        // Use cursor for efficient memory usage
        const cursor = User.find({ status: USER_STATUS.ACTIVE }).cursor();

        let batch = [];

        for (let doc = await cursor.next(); doc != null; doc = await cursor.next()) {
            // Prepare notification object
            const notificationData = {
                recipient: doc._id,
                type: broadcast.type,
                title: broadcast.title,
                message: broadcast.message,
                read: false,
                createdAt: new Date(),
                updatedAt: new Date()
            };

            batch.push(notificationData);

            if (batch.length >= BATCH_SIZE) {
                await processBatch(batch, io);
                processed += batch.length;
                success += batch.length; // Assuming insertMany succeeds. Partial failures in insertMany usually throw.

                // Update stats periodically
                broadcast.stats.processedCount = processed;
                broadcast.stats.successCount = success;
                await broadcast.save();

                batch = []; // Reset batch
            }
        }

        // Process remaining items
        if (batch.length > 0) {
            await processBatch(batch, io);
            processed += batch.length;
            success += batch.length;
        }

        broadcast.status = 'COMPLETED';
        broadcast.completedAt = new Date();
        broadcast.stats.processedCount = processed;
        broadcast.stats.successCount = success;
        await broadcast.save();

        logger.info(`[BroadcastProcessor] Completed broadcast job: ${broadcastId}. Processed: ${processed}`);

    } catch (error) {
        logger.error(`[BroadcastProcessor] Failed broadcast job ${broadcastId}: ${error.message}`);
        broadcast.status = 'FAILED';
        broadcast.error = error.message;
        broadcast.completedAt = new Date();
        await broadcast.save();
    }
};

/**
 * Helper to save notifications and emit events
 * @param {Array} batch 
 * @param {Object} io 
 */
const processBatch = async (batch, io) => {
    if (batch.length === 0) return;

    // Bulk insert notifications
    await Notification.insertMany(batch);

    // Emit socket events
    if (io) {
        batch.forEach(notification => {
            // notification.recipient is an ObjectId
            io.to(notification.recipient.toString()).emit('notification:new', notification);
        });
    }
};

module.exports = {
    processBroadcast
};
