const httpStatus = require('../../../../constants/httpStatus');
const ApiError = require('../../../../utils/ApiError');
const Notification = require('../../notification.model');
const { getIo } = require('../../../../config/socket');
const Broadcast = require('../../../../models/broadcast.model');

/**
 * Create a notification
 * @param {Object} notificationBody
 * @returns {Promise<Notification>}
 */
const createNotification = async (notificationBody) => {
    const notification = await Notification.create(notificationBody);

    try {
        const io = getIo();
        if (io) {
            io.to(notification.recipient.toString()).emit('notification:new', notification);
        }
    } catch (error) {
        // Fail silently for socket errors, notification is still saved
        console.error('Socket emission failed:', error);
    }

    return notification;
};

/**
 * Query for notifications
 * @param {Object} filter - Mongo filter
 * @param {Object} options - Query options
 * @returns {Promise<QueryResult>}
 */
const queryNotifications = async (filter, options) => {
    // Default sort by newest
    if (!options.sortBy) {
        options.sortBy = 'createdAt:desc';
    }
    const notifications = await Notification.paginate(filter, options);
    return notifications;
};

/**
 * Get notification by id
 * @param {ObjectId} id
 * @returns {Promise<Notification>}
 */
const getNotificationById = async (id) => {
    return Notification.findById(id);
};

/**
 * Mark notification as read
 * @param {ObjectId} notificationId
 * @param {ObjectId} userId
 * @returns {Promise<Notification>}
 */
const markAsRead = async (notificationId, userId) => {
    const notification = await getNotificationById(notificationId);
    if (!notification) {
        throw new ApiError('Notification not found', httpStatus.NOT_FOUND);
    }
    if (notification.recipient.toString() !== userId.toString()) {
        throw new ApiError('Forbidden', httpStatus.FORBIDDEN);
    }
    Object.assign(notification, { read: true });
    await notification.save();
    return notification;
};

/**
 * Mark all notifications as read
 * @param {ObjectId} userId
 * @returns {Promise<void>}
 */
const markAllAsRead = async (userId) => {
    await Notification.updateMany({ recipient: userId, read: false }, { read: true });
};

/**
 * Delete notification by id
 * @param {ObjectId} notificationId
 * @param {ObjectId} userId
 * @returns {Promise<void>}
 */
const deleteNotification = async (notificationId, userId) => {
    const notification = await getNotificationById(notificationId);
    if (!notification) {
        throw new ApiError('Notification not found', httpStatus.NOT_FOUND);
    }
    if (notification.recipient.toString() !== userId.toString()) {
        throw new ApiError('Forbidden', httpStatus.FORBIDDEN);
    }
    await notification.deleteOne();
};

/**
 * Delete all notifications for a user
 * @param {ObjectId} userId
 * @returns {Promise<void>}
 */
const deleteAllNotifications = async (userId) => {
    await Notification.deleteMany({ recipient: userId });
};

/**
 * Create a broadcast job
 * @param {Object} broadcastBody
 * @param {UserId} userId
 * @returns {Promise<Broadcast>}
 */
const createBroadcast = async (broadcastBody, userId) => {
    const broadcast = await Broadcast.create({
        ...broadcastBody,
        createdBy: userId,
    });
    return broadcast;
};

module.exports = {
    createNotification,
    queryNotifications,
    getNotificationById,
    markAsRead,
    markAllAsRead,
    deleteNotification,
    deleteAllNotifications,
    createBroadcast,
};


