const Joi = require('joi');

const objectIdSchema = Joi.string()
    .pattern(/^[0-9a-fA-F]{24}$/)
    .required()
    .messages({
        'string.pattern.base': 'Invalid ID format',
        'any.required': 'ID is required',
    });

const markAsRead = Joi.object({
    notificationId: objectIdSchema,
});

const deleteNotification = Joi.object({
    notificationId: objectIdSchema,
});

const broadcastNotification = Joi.object({
    title: Joi.string().required().trim().min(3).max(100),
    message: Joi.string().required().min(10).max(1000),
    type: Joi.string().valid('security', 'system', 'marketing', 'activity').required(),
});

module.exports = {
    markAsRead,
    deleteNotification,
    broadcastNotification,
};
