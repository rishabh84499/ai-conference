const express = require('express');
const callController = require('../controllers/call.controller');
const { authenticate } = require('../../../../middlewares/auth.middleware');
// const validate = require('../../../../middlewares/validate.middleware');
// const callValidator = require('../validators/call.validator');

const router = express.Router();

router.post('/token', authenticate, callController.generateToken);

module.exports = router;
