const catchAsync = require('../../../../utils/catchAsync');
const { sendSuccess } = require('../../../../utils/response');
const { generateRtcToken } = require('../../../../integrations/agora.integration');
const httpStatus = require('../../../../constants/httpStatus');

/**
 * Generate Agora RTC Token
 */
const generateToken = catchAsync(async (req, res) => {
    const { channelName, uid } = req.body;

    // Default UID to 0 if not provided (Agora will assign a random one if 0)
    // Or we could use the user's ID if it's numeric. 
    // For now, let's expect uid from body or default to 0.
    const agoraUid = uid || 0;

    const token = generateRtcToken(channelName, agoraUid);

    sendSuccess(res, 'Agora token generated successfully', {
        token,
        channelName,
        uid: agoraUid
    });
});

module.exports = {
    generateToken,
};
