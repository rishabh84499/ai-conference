const Transaction = require('./payment.model');
const paymentService = require('./v1/services/payment.service');
const paymentController = require('./v1/controllers/payment.controller');
const paymentRoutes = require('./v1/routes/payment.routes');
const paymentValidation = require('./v1/validators/payment.validation');

module.exports = {
    Transaction,
    paymentService,
    paymentController,
    paymentRoutes,
    paymentValidation,
};
