const paymentService = require('../v1/services/payment.service');
const Transaction = require('../../payment.model');
const { PAYMENT_STATUS } = require('../../../constants/payment');
const ApiError = require('../../../utils/ApiError');

// Mock dependencies
jest.mock('../../payment.model', () => ({
    create: jest.fn(),
    findOne: jest.fn(),
    findOneAndUpdate: jest.fn(),
    findById: jest.fn(),
}));

jest.mock('../../../shared/logger.service', () => ({
    info: jest.fn(),
    error: jest.fn()
}));

// Mock Razorpay Provider
jest.mock('../v1/services/providers/razorpay.provider', () => {
    return class RazorpayProvider {
        createOrder = jest.fn().mockResolvedValue({ id: 'order_123', amount: 100 });
        verifyPayment = jest.fn().mockResolvedValue(true);
        refund = jest.fn().mockResolvedValue({ id: 'rfnd_123' });
    };
});

describe('PaymentService', () => {
    afterEach(() => {
        jest.clearAllMocks();
    });

    describe('createOrder', () => {
        it('should create a transaction and order successfully', async () => {
            const userId = 'user123';
            const amount = 100;
            const currency = 'INR';

            // Mock DB Create
            Transaction.create.mockResolvedValue({
                _id: 'tx_123',
                userId,
                amount,
                status: PAYMENT_STATUS.PENDING,
                save: jest.fn()
            });

            const result = await paymentService.createOrder(userId, amount, currency);

            expect(result).toHaveProperty('transaction');
            expect(result).toHaveProperty('order');
            expect(result.order.id).toBe('order_123');
            expect(Transaction.create).toHaveBeenCalled();
        });
    });

    describe('verifyPayment', () => {
        it('should verify payment successfully', async () => {
            const userId = 'user123';
            const data = { orderId: 'order_123', paymentId: 'pay_123', signature: 'sig_123' };

            // Mock DB FindOne
            Transaction.findOne.mockResolvedValue({
                _id: 'tx_123',
                userId,
                status: PAYMENT_STATUS.PENDING,
                providerOrderId: 'order_123',
                save: jest.fn()
            });

            // Mock DB FindOneAndUpdate (Atomic update)
            Transaction.findOneAndUpdate.mockResolvedValue({
                _id: 'tx_123',
                userId,
                status: PAYMENT_STATUS.COMPLETED
            });

            const result = await paymentService.verifyPayment(userId, data);

            expect(result.success).toBe(true);
            expect(result.transaction.status).toBe(PAYMENT_STATUS.COMPLETED);
            expect(Transaction.findOneAndUpdate).toHaveBeenCalled();
        });

        it('should return error if transactions does not exist', async () => {
            Transaction.findOne.mockResolvedValue(null);
            await expect(paymentService.verifyPayment('user1', { orderId: 'inv' }))
                .rejects.toThrow(ApiError);
        });
    });
});
