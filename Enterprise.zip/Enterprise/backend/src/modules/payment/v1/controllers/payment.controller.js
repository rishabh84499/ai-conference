const catchAsync = require('../../../../utils/catchAsync');
const paymentService = require('../services/payment.service');
const httpStatus = require('../../../../constants/httpStatus');
const logger = require('../../../../shared/logger.service');
const { sendSuccess, sendPaginatedResponse } = require('../../../../utils/response');
const pick = require('../../../../utils/pick');

const createOrder = catchAsync(async (req, res) => {
    const { amount, currency, provider } = req.body;
    const userId = req.user.id;
    logger.info(`[PaymentController] Received createOrder request from User: ${userId}`);

    const result = await paymentService.createOrder(userId, amount, currency, provider);
    sendSuccess(res, 'Order created successfully', result);
});

const verifyPayment = catchAsync(async (req, res) => {
    const { orderId, paymentId, signature, provider } = req.body;
    const userId = req.user.id;

    const result = await paymentService.verifyPayment(userId, { orderId, paymentId, signature }, provider);
    sendSuccess(res, 'Payment verified successfully', result);
});

const refundPayment = catchAsync(async (req, res) => {
    const { transactionId, amount, notes } = req.body;
    const userId = req.user.id;

    const result = await paymentService.refundPayment(userId, transactionId, amount, notes);
    sendSuccess(res, 'Refund processed successfully', result);
});

const getTransactions = catchAsync(async (req, res) => {
    const filter = pick(req.query, ['status', 'provider']);
    const options = pick(req.query, ['sortBy', 'limit', 'page']);

    // Default sort
    if (!options.sortBy) {
        options.sortBy = 'createdAt:desc';
    }

    const { results, page, limit, totalPages, totalResults } = await paymentService.getTransactions(req.user.id, {
        ...filter,
        ...options
    });

    sendPaginatedResponse(res, results, { page, limit, total: totalResults }, 'Transactions fetched successfully');
});

module.exports = {
    createOrder,
    verifyPayment,
    refundPayment,
    getTransactions,
};
