const httpStatus = require('../../../../constants/httpStatus');
const catchAsync = require('../../../../utils/catchAsync');
const paymentService = require('../services/payment.service');
const ApiError = require('../../../../utils/ApiError');
const { sendSuccess } = require('../../../../utils/response');

const handleWebhook = catchAsync(async (req, res) => {
    const signature = req.headers['x-razorpay-signature'];
    const provider = req.params.provider || 'razorpay';

    // Validate signature first
    const isValid = paymentService.verifyWebhookSignature(req.body, signature, provider);

    if (!isValid) {
        throw new ApiError('Invalid Webhook Signature', httpStatus.UNAUTHORIZED);
    }

    // Process the event
    await paymentService.processWebhookEvent(req.body, provider);

    sendSuccess(res, 'Webhook processed successfully', { status: 'ok' });
});

module.exports = {
    handleWebhook,
};
