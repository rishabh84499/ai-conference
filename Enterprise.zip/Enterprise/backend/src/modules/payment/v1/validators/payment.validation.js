const Joi = require('joi');

const createOrder = Joi.object({
    amount: Joi.number().required().min(1),
    currency: Joi.string().required(),
    provider: Joi.string().valid('razorpay', 'stripe', 'paypal').default('razorpay'),
    notes: Joi.object().optional()
});

const verifyPayment = Joi.object({
    orderId: Joi.string().required(),
    paymentId: Joi.string().required(),
    provider: Joi.string().valid('razorpay', 'stripe', 'paypal').default('razorpay'),
    signature: Joi.string().when('provider', {
        is: 'razorpay',
        then: Joi.required(),
        otherwise: Joi.optional()
    })
});

const webhook = Joi.object().unknown(true);

const refundPayment = Joi.object({
    transactionId: Joi.string().required(),
    amount: Joi.number().min(1).optional(),
    notes: Joi.object().optional()
});

module.exports = {
    createOrder,
    verifyPayment,
    webhook,
    refundPayment
};
