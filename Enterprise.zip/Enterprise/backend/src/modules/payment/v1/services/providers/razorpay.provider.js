const crypto = require('crypto');
const config = require('../../../../../config/index');
const PaymentProvider = require('./payment.provider');
const razorpay = require('../../../../../integrations/razorpay.integration');

class RazorpayProvider extends PaymentProvider {
    constructor() {
        super();
        this.instance = razorpay;
    }

    async createOrder(amount, currency = 'INR', options = {}) {
        try {
            // Convert amount to smallest currency unit (e.g., paise for INR)
            // Assuming amount is passed as a number or string representing the main unit (e.g., 10.50)
            const amountInSubunits = Math.round(parseFloat(amount.toString()) * 100);

            const orderOptions = {
                amount: amountInSubunits,
                currency,
                receipt: `receipt_${Date.now()}`,
                ...options
            };
            const order = await this.instance.orders.create(orderOptions);
            return order;
        } catch (error) {
            throw new Error(`Razorpay Order Creation Failed: ${error.message}`);
        }
    }

    async verifyPayment(data) {
        const { orderId, paymentId, signature } = data;
        const secret = config.razorpay?.keySecret || process.env.RAZORPAY_KEY_SECRET;

        const generatedSignature = crypto
            .createHmac('sha256', secret)
            .update(orderId + '|' + paymentId)
            .digest('hex');

        if (generatedSignature === signature) {
            return true;
        }
        return false;
    }

    verifyWebhookSignature(body, signature) {
        const secret = config.razorpay?.webhookSecret || process.env.RAZORPAY_WEBHOOK_SECRET;
        if (!secret) {
            throw new Error('Razorpay Webhook Secret not configured');
        }

        const Razorpay = require('razorpay');
        return Razorpay.validateWebhookSignature(JSON.stringify(body), signature, secret);
    }

    async refund(paymentId, amount = null, notes = {}) {
        try {
            const options = {
                notes
            };
            if (amount) {
                options.amount = Math.round(parseFloat(amount.toString()) * 100);
            }

            const refund = await this.instance.payments.refund(paymentId, options);
            return refund;
        } catch (error) {
            throw new Error(`Razorpay Refund Failed: ${error.message}`);
        }
    }

    async fetchOrder(orderId) {
        try {
            const order = await this.instance.orders.fetch(orderId);
            return order;
        } catch (error) {
            throw new Error(`Razorpay Fetch Order Failed: ${error.message}`);
        }
    }
}

module.exports = RazorpayProvider;
