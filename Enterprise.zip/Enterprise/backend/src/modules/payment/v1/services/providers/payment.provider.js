/**
 * Abstract Class PaymentProvider.
 *
 * @class PaymentProvider
 */
class PaymentProvider {
    constructor() {
        if (this.constructor === PaymentProvider) {
            throw new Error("Abstract classes can't be instantiated.");
        }
    }

    /**
     * Create an order
     * @param {number} amount
     * @param {string} currency
     * @param {object} options
     * @returns {Promise<object>}
     */
    async createOrder(amount, currency, options = {}) {
        throw new Error("Method 'createOrder()' must be implemented.");
    }

    /**
     * Verify a payment
     * @param {object} data
     * @returns {Promise<boolean>}
     */
    async verifyPayment(data) {
        throw new Error("Method 'verifyPayment()' must be implemented.");
    }
}

module.exports = PaymentProvider;
