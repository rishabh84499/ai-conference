// const RazorpayProvider = require('./providers/razorpay.provider'); // Lazy loaded
// const StripeProvider = require('./providers/stripe.provider');
// const PaypalProvider = require('./providers/paypal.provider');
const Transaction = require('../../payment.model');
const { PAYMENT_STATUS, PAYMENT_PROVIDERS } = require('../../../../constants/payment');
const logger = require('../../../../shared/logger.service');
const ApiError = require('../../../../utils/ApiError');
const httpStatus = require('../../../../constants/httpStatus');

const eventBus = require('../../../../shared/eventBus');

class PaymentService {
    constructor() {
        this.providers = {};
    }

    getProvider(providerName) {
        if (this.providers[providerName]) {
            return this.providers[providerName];
        }

        switch (providerName) {
            case 'razorpay':
                const RazorpayProvider = require('./providers/razorpay.provider');
                this.providers[providerName] = new RazorpayProvider();
                break;
            case 'stripe':
                // const StripeProvider = require('./providers/stripe.provider');
                // this.providers[providerName] = new StripeProvider();
                throw new ApiError('Stripe provider not implemented yet', httpStatus.NOT_IMPLEMENTED);
            case 'paypal':
                // const PaypalProvider = require('./providers/paypal.provider');
                // this.providers[providerName] = new PaypalProvider();
                throw new ApiError('PayPal provider not implemented yet', httpStatus.NOT_IMPLEMENTED);
            default:
                throw new ApiError(`Payment provider '${providerName}' not supported.`, httpStatus.BAD_REQUEST);
        }

        return this.providers[providerName];
    }


    /**
     * Creates a payment order with a specified provider.
     * @param {string} userId - The ID of the user initiating the order.
     * @param {number|string} amount - The amount to be paid (in major currency units, e.g., "10.50").
     * @param {string} currency - The currency code (e.g., "INR", "USD").
     * @param {string} [providerName='razorpay'] - The payment provider to use.
     * @param {Object} [options={}] - Additional options for the order.
     * @returns {Promise<Object>} The created transaction and provider order details.
     * @throws {ApiError} If the order creation fails.
     */
    async createOrder(userId, amount, currency, providerName = 'razorpay', options = {}) {
        const provider = this.getProvider(providerName);
        logger.info(`[PaymentService] Creating order. User: ${userId}, Amount: ${amount} ${currency}, Provider: ${providerName}`);

        // 1. Create Transaction Record (Pending)
        const transaction = await Transaction.create({
            userId,
            amount,
            currency,
            provider: providerName,
            status: PAYMENT_STATUS.PENDING
        });

        try {
            // 2. Call Provider
            const order = await provider.createOrder(amount, currency, {
                notes: { transactionId: transaction._id.toString(), ...options.notes }
            });

            // 3. Update Transaction with Provider Info
            transaction.providerOrderId = order.id;
            transaction.metadata = order;
            await transaction.save();

            logger.info(`[PaymentService] Transaction created: ${transaction._id}`);
            return { transaction, order };
        } catch (error) {
            logger.error(`[PaymentService] Create order failed: ${error.message}`);
            transaction.status = PAYMENT_STATUS.FAILED;
            transaction.error = error;
            await transaction.save();
            throw new ApiError(`Order creation failed: ${error.message}`, httpStatus.BAD_GATEWAY);
        }
    }

    /**
     * Verifies a payment signature and updates the transaction status.
     * @param {string} userId - The ID of the user verifying the payment.
     * @param {Object} data - Verification data (orderId, paymentId, signature).
     * @param {string} [providerName='razorpay'] - The payment provider name.
     * @returns {Promise<Object>} Success status and updated transaction.
     * @throws {ApiError} If verification fails or transaction is not found/unauthorized.
     */
    async verifyPayment(userId, data, providerName = 'razorpay') {
        const provider = this.getProvider(providerName);
        logger.info(`[PaymentService] Verifying payment for User: ${userId}, OrderId: ${data.orderId}`);

        // 1. Initial Check (Read-only)
        const existingTx = await Transaction.findOne({ providerOrderId: data.orderId });
        if (!existingTx) throw new ApiError('Transaction not found', httpStatus.NOT_FOUND);

        // Security: Ownership Check
        if (existingTx.userId.toString() !== userId.toString()) {
            throw new ApiError('Unauthorized: Transaction does not belong to user', httpStatus.FORBIDDEN);
        }

        // Robustness: Idempotency Check (Fast return)
        if (existingTx.status === PAYMENT_STATUS.COMPLETED) {
            logger.info(`[PaymentService] Transaction ${existingTx._id} already verified.`);
            return { success: true, transaction: existingTx, message: 'Payment already verified' };
        }

        // 2. Verify with Provider
        const isValid = await provider.verifyPayment(data);

        if (!isValid) {
            existingTx.status = PAYMENT_STATUS.FAILED;
            existingTx.error = { message: 'Invalid signature' };
            await existingTx.save();
            throw new ApiError('Invalid payment signature', httpStatus.BAD_REQUEST);
        }

        // 3. Atomic Update (Concurrency Safe)
        const transaction = await Transaction.findOneAndUpdate(
            {
                providerOrderId: data.orderId,
                status: PAYMENT_STATUS.PENDING
            },
            {
                status: PAYMENT_STATUS.COMPLETED,
                providerPaymentId: data.paymentId,
                signature: data.signature
            },
            { new: true }
        );

        // 4. Handle Race Condition
        if (!transaction) {
            // If we are here, it means the status was NOT pending (likely completed by another request)
            const currentTx = await Transaction.findOne({ providerOrderId: data.orderId });
            if (currentTx && currentTx.status === PAYMENT_STATUS.COMPLETED) {
                return { success: true, transaction: currentTx, message: 'Payment already verified (concurrent)' };
            }
            throw new ApiError('Transaction update failed due to concurrent modification', httpStatus.CONFLICT);
        }

        logger.info(`[PaymentService] Transaction ${transaction._id} completed successfully.`);

        // Emit Payment Completed Event
        eventBus.emit('payment.completed', { transaction, userId });

        return { success: true, transaction };
    }

    verifyWebhookSignature(body, signature, providerName = 'razorpay') {
        const provider = this.getProvider(providerName);
        if (typeof provider.verifyWebhookSignature !== 'function') {
            throw new ApiError(`Provider ${providerName} does not support webhook verification`, httpStatus.BAD_REQUEST);
        }
        return provider.verifyWebhookSignature(body, signature);
    }

    async processWebhookEvent(body, providerName = 'razorpay') {
        logger.info(`[PaymentService] Processing webhook event: ${body.event} for ${providerName}`);

        let providerOrderId;
        let providerPaymentId;

        // Example for Razorpay 'payment.captured'
        if (body.event === 'payment.captured') {
            const payment = body.payload.payment.entity;
            providerOrderId = payment.order_id;
            providerPaymentId = payment.id;
        } else if (body.event === 'order.paid') {
            const order = body.payload.order.entity;
            providerOrderId = order.id;
        }

        if (providerOrderId) {
            const transaction = await Transaction.findOne({ providerOrderId });
            if (transaction && transaction.status !== PAYMENT_STATUS.COMPLETED) {
                transaction.status = PAYMENT_STATUS.COMPLETED;
                if (providerPaymentId) transaction.providerPaymentId = providerPaymentId;
                transaction.metadata = { ...transaction.metadata, webhookEvent: body };
                await transaction.save();

                logger.info(`[PaymentService] Transaction ${transaction._id} updated via webhook.`);

                // Emit Payment Completed Event
                eventBus.emit('payment.completed', { transaction, userId: transaction.userId });
            } else {
                logger.info(`[PaymentService] Transaction not found or already completed for OrderId: ${providerOrderId}`);
            }
        }
    }

    /**
     * Refunds a completed transaction.
     * @param {string} userId - The ID of the user requesting the refund.
     * @param {string} transactionId - The ID of the transaction to refund.
     * @param {number|string} [amount=null] - Optional amount to refund (if partial).
     * @param {Object} [notes={}] - Refund notes.
     * @returns {Promise<Object>} The updated transaction and refund details.
     * @throws {ApiError} If refund fails or transaction is invalid.
     */
    async refundPayment(userId, transactionId, amount = null, notes = {}) {
        const transaction = await Transaction.findById(transactionId);
        if (!transaction) throw new ApiError('Transaction not found', httpStatus.NOT_FOUND);

        if (transaction.userId.toString() !== userId.toString()) {
            throw new ApiError('Unauthorized: Transaction does not belong to user', httpStatus.FORBIDDEN);
        }

        if (transaction.status !== PAYMENT_STATUS.COMPLETED) {
            throw new ApiError('Transaction must be completed to be refunded', httpStatus.BAD_REQUEST);
        }

        const provider = this.getProvider(transaction.provider);

        try {
            const refundData = await provider.refund(transaction.providerPaymentId, amount, notes);

            transaction.status = PAYMENT_STATUS.REFUNDED;
            transaction.metadata = { ...transaction.metadata, refund: refundData };
            await transaction.save();

            return { success: true, transaction, refund: refundData };
        } catch (error) {
            logger.error(`[PaymentService] Refund failed: ${error.message}`);
            throw new ApiError(`Refund failed: ${error.message}`, httpStatus.BAD_GATEWAY);
        }
    }

    /**
     * Get transaction history for a user.
     * @param {string} userId - User ID
     * @param {Object} options - Query options (limit, page, sortBy)
     * @returns {Promise<Object>} Paginated transaction results
     */
    async getTransactions(userId, options = {}) {
        const { limit = 10, page = 1, sortBy = 'createdAt:desc' } = options;

        // Use pagination plugin if available, otherwise manual
        if (typeof Transaction.paginate === 'function') {
            return await Transaction.paginate({ userId }, { limit, page, sortBy });
        }

        const skip = (page - 1) * limit;
        const [sortField, sortOrder] = sortBy.split(':');
        const sort = { [sortField]: sortOrder === 'desc' ? -1 : 1 };

        const transactions = await Transaction.find({ userId })
            .sort(sort)
            .skip(skip)
            .limit(limit);

        const totalResults = await Transaction.countDocuments({ userId });
        const totalPages = Math.ceil(totalResults / limit);

        return {
            results: transactions,
            page,
            limit,
            totalPages,
            totalResults
        };
    }
}

module.exports = new PaymentService();
