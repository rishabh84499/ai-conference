const express = require('express');
const { validate } = require('../../../../middlewares/validate.middleware'); // Assuming this middleware exists based on standard structure
const paymentValidation = require('../validators/payment.validation');
const paymentController = require('../controllers/payment.controller');
const { authenticate } = require('../../../../middlewares/auth.middleware'); // Assuming standard auth middleware export
const rateLimit = require('express-rate-limit');

const router = express.Router();

// Strict Rate Limiting for Payment Creation & Refunds
const paymentLimiter = rateLimit({
    windowMs: 15 * 60 * 1000, // 15 minutes
    max: 20, // Limit each IP to 20 requests per windowMs
    message: 'Too many payment requests from this IP, please try again after 15 minutes',
    standardHeaders: true, // Return rate limit info in the `RateLimit-*` headers
    legacyHeaders: false, // Disable the `X-RateLimit-*` headers
});

// router.route('/create-order')
//     .post(auth(), validate(paymentValidation.createOrder), paymentController.createOrder);

const webhookController = require('../controllers/webhook.controller');

router.get('/', authenticate, paymentController.getTransactions);
router.post('/create-order', authenticate, paymentLimiter, validate(paymentValidation.createOrder), paymentController.createOrder);

router.post('/verify', authenticate, validate(paymentValidation.verifyPayment), paymentController.verifyPayment);

router.post('/refund', authenticate, paymentLimiter, validate(paymentValidation.refundPayment), paymentController.refundPayment);

router.post('/webhook/:provider', validate(paymentValidation.webhook), webhookController.handleWebhook);

module.exports = router;
