const mongoose = require('mongoose');

const paymentProviderSchema = new mongoose.Schema({
    id: { type: String },         // Provider's Order ID or Payment ID
    status: { type: String },     // Provider's status
    raw: { type: Object }         // Full response from provider for debugging
}, { _id: false });

const { PAYMENT_STATUS, PAYMENT_PROVIDERS, CURRENCIES } = require('../../constants/payment');

const transactionSchema = new mongoose.Schema({
    userId: {
        type: mongoose.Schema.Types.ObjectId,
        ref: 'User',
        required: true,
        index: true
    },
    amount: {
        type: mongoose.Schema.Types.Decimal128,
        required: true,
        // get: (v) => v ? parseFloat(v.toString()) : v // REMOVED: Precision risk
    },
    currency: {
        type: String,
        required: true,
        default: CURRENCIES.INR
    },
    provider: {
        type: String,
        enum: Object.values(PAYMENT_PROVIDERS),
        required: true
    },
    status: {
        type: String,
        enum: Object.values(PAYMENT_STATUS),
        default: PAYMENT_STATUS.PENDING,
        index: true
    },
    transactionId: {
        type: String,
        unique: true,
        sparse: true // Allows null/undefined to be unique if needed, though we should generate one
    },
    providerOrderId: {
        type: String,
        index: true
    },
    providerPaymentId: {
        type: String,
        index: true
    },
    signature: {
        type: String
    },
    metadata: {
        type: mongoose.Schema.Types.Mixed
    },
    error: {
        type: Object
    }
}, {
    timestamps: true,
    toJSON: { virtuals: true },
    toObject: { virtuals: true }
});

// Add plugins if any (like paginate)
// transactionSchema.plugin(paginate);
const { toJSON } = require('../../models/plugins');
transactionSchema.plugin(toJSON);

const Transaction = mongoose.model('Transaction', transactionSchema);

module.exports = Transaction;
