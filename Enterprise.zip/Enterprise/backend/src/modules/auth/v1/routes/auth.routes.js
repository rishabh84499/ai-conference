const express = require('express');
const authController = require('../controllers/auth.controller');
const { authenticate } = require('../../../../middlewares/auth.middleware');
const { validate } = require('../../../../middlewares/validate.middleware');
const { loginLimiter, passwordResetLimiter } = require('../../../../middlewares/rateLimiter.middleware');
const {
    loginSchema,
    refreshTokenSchema,
    forgotPasswordSchema,
    resetPasswordSchema,
    changePasswordSchema,
} = require('../validators/auth.validator');

const router = express.Router();

/**
 * @swagger
 * tags:
 *   name: Auth
 *   description: Authentication management
 */

// Public routes with validation and rate limiting

/**
 * @swagger
 * /auth/login:
 *   post:
 *     summary: Login user
 *     tags: [Auth]
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             type: object
 *             required:
 *               - email
 *               - password
 *             properties:
 *               email:
 *                 type: string
 *                 format: email
 *               password:
 *                 type: string
 *                 format: password
 *     responses:
 *       200:
 *         description: Successful login
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 user:
 *                   type: object
 *                 tokens:
 *                   type: object
 *       401:
 *         description: Invalid credentials
 */
router.post(
    '/login',
    loginLimiter,
    validate(loginSchema),
    authController.login
);

router.post(
    '/refresh-tokens',
    validate(refreshTokenSchema),
    authController.refreshTokens
);

router.post(
    '/forgot-password',
    passwordResetLimiter,
    validate(forgotPasswordSchema),
    authController.forgotPassword
);

router.post(
    '/reset-password',
    validate(resetPasswordSchema),
    authController.resetPassword
);

// Protected routes
router.post('/logout', authenticate, authController.logout);
router.get('/profile', authenticate, authController.getProfile);
router.post(
    '/change-password',
    authenticate,
    validate(changePasswordSchema),
    authController.changePassword
);

module.exports = router;
