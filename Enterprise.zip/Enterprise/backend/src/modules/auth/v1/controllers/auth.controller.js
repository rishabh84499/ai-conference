const authService = require('../../../../shared/auth.service');
const { sendSuccess } = require('../../../../utils/response');
const catchAsync = require('../../../../utils/catchAsync');
const httpStatus = require('../../../../constants/httpStatus');
const { SUCCESS } = require('../../../../constants/messages');
const config = require('../../../../config/index');

const getCookieOptions = () => ({
    maxAge: config.jwt.refreshExpirationDays * 24 * 60 * 60 * 1000,
    httpOnly: true,
    secure: process.env.NODE_ENV === 'production',
    sameSite: 'strict',
});

/**
 * Login
 */
const login = catchAsync(async (req, res) => {
    const { email, password } = req.body;
    const { user, tokens } = await authService.loginWithEmailAndPassword(email, password);

    res.cookie('refreshToken', tokens.refresh.token, getCookieOptions());

    // Remove refresh token from response body for security
    const responseTokens = {
        access: tokens.access,
        // Client might need expiration for UI logic, but token itself is hidden
        refresh: {
            expires: tokens.refresh.expires
        }
    };

    sendSuccess(res, SUCCESS.LOGIN_SUCCESS, {
        user,
        tokens: responseTokens,
    });
});

/**
 * Refresh tokens
 */
const refreshTokens = catchAsync(async (req, res) => {
    const refreshToken = req.cookies.refreshToken || req.body.refreshToken;
    if (!refreshToken) {
        // Let authService handle the missing token error or throw here
        // But authService.refreshAuthTokens expects a token string.
        // If not present, we should probably throw 401 directly or pass empty string to let service fail
    }

    const { user, tokens } = await authService.refreshAuthTokens(refreshToken);

    res.cookie('refreshToken', tokens.refresh.token, getCookieOptions());

    const responseTokens = {
        access: tokens.access,
        refresh: {
            expires: tokens.refresh.expires
        }
    };

    sendSuccess(res, SUCCESS.TOKENS_REFRESHED, {
        user,
        tokens: responseTokens,
    });
});

/**
 * Get current user profile
 */
const getProfile = catchAsync(async (req, res) => {
    const user = await authService.getCurrentUser(req.user._id);
    sendSuccess(res, SUCCESS.PROFILE_FETCHED, user);
});

/**
 * Logout (client-side - just acknowledge, but also clear cookie)
 */
const logout = catchAsync(async (req, res) => {
    // Blacklist access token
    const authHeader = req.headers.authorization;
    if (authHeader && authHeader.startsWith('Bearer ')) {
        const accessToken = authHeader.substring(7);
        // Decode to get expiration, but don't verify (we want to blacklist even if expired/invalid check not needed here as middleware passed)
        // Actually, passing it to blacklistToken needs expiration.
        // We can just decode it.
        const jwt = require('jsonwebtoken');
        const payload = jwt.decode(accessToken);
        if (payload && payload.exp) {
            await authService.logout(accessToken, payload.exp, req.cookies.refreshToken);
        }
    }

    res.clearCookie('refreshToken', { ...getCookieOptions(), maxAge: 0 });
    sendSuccess(res, SUCCESS.LOGOUT_SUCCESS, null);
});

/**
 * Forgot password - request reset token
 */
const forgotPassword = catchAsync(async (req, res) => {
    const result = await authService.forgotPassword(req.body.email);
    sendSuccess(res, SUCCESS.PASSWORD_RESET_SENT, null);
});

/**
 * Reset password with token
 */
const resetPassword = catchAsync(async (req, res) => {
    await authService.resetPassword(req.body.token, req.body.password);
    sendSuccess(res, SUCCESS.PASSWORD_RESET_SUCCESS);
});

/**
 * Change password for authenticated user
 */
const changePassword = catchAsync(async (req, res) => {
    await authService.changePassword(
        req.user._id,
        req.body.currentPassword,
        req.body.newPassword
    );
    sendSuccess(res, SUCCESS.PASSWORD_CHANGED);
});

module.exports = {
    login,
    refreshTokens,
    getProfile,
    logout,
    forgotPassword,
    resetPassword,
    changePassword,
};
