// Auth module exports
const authService = require('../../shared/auth.service');
const tokenService = require('../../shared/token.service');
const authController = require('./v1/controllers/auth.controller');
const authRoutes = require('./v1/routes/auth.routes');

module.exports = {
    authService,
    tokenService,
    authController,
    authRoutes,
};
