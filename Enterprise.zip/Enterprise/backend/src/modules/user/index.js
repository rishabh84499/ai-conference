// User module exports
const { User, USER_STATUS } = require('./user.model');
const userService = require('./v1/services/user.service');
const userController = require('./v1/controllers/user.controller');
const userRoutes = require('./v1/routes/user.routes');

module.exports = {
    User,
    USER_STATUS,
    userService,
    userController,
    userRoutes,
};
