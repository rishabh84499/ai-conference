const Joi = require('joi');
const { ROLES } = require('../../../../constants/roles');

const createUserSchema = Joi.object({
    firstName: Joi.string()
        .min(2)
        .max(50)
        .required()
        .messages({
            'string.min': 'First name must be at least 2 characters',
            'string.max': 'First name cannot exceed 50 characters',
            'any.required': 'First name is required',
        }),
    lastName: Joi.string()
        .min(2)
        .max(50)
        .required()
        .messages({
            'string.min': 'Last name must be at least 2 characters',
            'string.max': 'Last name cannot exceed 50 characters',
            'any.required': 'Last name is required',
        }),
    email: Joi.string()
        .email()
        .required()
        .messages({
            'string.email': 'Please provide a valid email address',
            'any.required': 'Email is required',
        }),
    password: Joi.string()
        .min(8)
        .pattern(/^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[@$!%*?&#._-])[A-Za-z\d@$!%*?&#._-]/)
        .required()
        .messages({
            'string.min': 'Password must be at least 8 characters',
            'string.pattern.base': 'Password must contain uppercase, lowercase, number and special character',
            'any.required': 'Password is required',
        }),
    role: Joi.string()
        .valid(...Object.values(ROLES))
        .messages({
            'any.only': `Role must be one of: ${Object.values(ROLES).join(', ')}`,
        }),
    status: Joi.string()
        .valid('active', 'inactive', 'suspended')
        .messages({
            'any.only': 'Status must be one of: active, inactive, suspended',
        }),
});

const updateUserSchema = Joi.object({
    firstName: Joi.string()
        .min(2)
        .max(50)
        .messages({
            'string.min': 'First name must be at least 2 characters',
            'string.max': 'First name cannot exceed 50 characters',
        }),
    lastName: Joi.string()
        .min(2)
        .max(50)
        .messages({
            'string.min': 'Last name must be at least 2 characters',
            'string.max': 'Last name cannot exceed 50 characters',
        }),
    role: Joi.string()
        .valid(...Object.values(ROLES))
        .messages({
            'any.only': `Role must be one of: ${Object.values(ROLES).join(', ')}`,
        }),
    status: Joi.string()
        .valid('active', 'inactive', 'suspended')
        .messages({
            'any.only': 'Status must be one of: active, inactive, suspended',
        }),
    preferences: Joi.object({
        notifications: Joi.object({
            security: Joi.object({
                email: Joi.boolean(),
                push: Joi.boolean(),
                inApp: Joi.boolean()
            }),
            activity: Joi.object({
                email: Joi.boolean(),
                push: Joi.boolean(),
                inApp: Joi.boolean()
            }),
            marketing: Joi.object({
                email: Joi.boolean(),
                push: Joi.boolean(),
                inApp: Joi.boolean()
            }),
            system: Joi.object({
                email: Joi.boolean(),
                push: Joi.boolean(),
                inApp: Joi.boolean()
            })
        })
    }),
}).min(1).messages({
    'object.min': 'At least one field must be provided for update',
});

const changeStatusSchema = Joi.object({
    status: Joi.string()
        .valid('active', 'inactive', 'suspended')
        .required()
        .messages({
            'any.only': 'Status must be one of: active, inactive, suspended',
            'any.required': 'Status is required',
        }),
});

const resetPasswordSchema = Joi.object({
    password: Joi.string()
        .min(8)
        .pattern(/^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[@$!%*?&#._-])[A-Za-z\d@$!%*?&#._-]/)
        .required()
        .messages({
            'string.min': 'Password must be at least 8 characters',
            'string.pattern.base': 'Password must contain uppercase, lowercase, number and special character',
            'any.required': 'Password is required',
        }),
});

// MongoDB ObjectId validation
const objectIdSchema = Joi.object({
    userId: Joi.string()
        .pattern(/^[0-9a-fA-F]{24}$/)
        .required()
        .messages({
            'string.pattern.base': 'Invalid user ID format',
            'any.required': 'User ID is required',
        }),
});

module.exports = {
    createUserSchema,
    updateUserSchema,
    changeStatusSchema,
    resetPasswordSchema,
    objectIdSchema,
};
