const express = require('express');
const userController = require('../controllers/user.controller');
const { authenticate, authorizePermission } = require('../../../../middlewares/auth.middleware');
const { validate, validateParams } = require('../../../../middlewares/validate.middleware');
const {
    createUserSchema,
    updateUserSchema,
    changeStatusSchema,
    resetPasswordSchema,
    objectIdSchema,
} = require('../validators/user.validator');

const router = express.Router();

// All routes require authentication
router.use(authenticate);

// Create user - requires CREATE_USER permission
router.post(
    '/',
    authorizePermission('CREATE_USER'),
    validate(createUserSchema),
    userController.createUser
);

// Get all users - requires READ_USERS permission
router.get(
    '/',
    authorizePermission('READ_USERS'),
    userController.getUsers
);

// Get user by ID - requires READ_USERS permission
router.get(
    '/:userId',
    authorizePermission('READ_USERS'),
    validateParams(objectIdSchema),
    userController.getUserById
);

// Update own profile - requires UPDATE_OWN_PROFILE permission
router.patch(
    '/profile',
    authorizePermission('UPDATE_OWN_PROFILE'),
    validate(updateUserSchema),
    userController.updateProfile
);

// Update user - requires UPDATE_USER permission
router.patch(
    '/:userId',
    authorizePermission('UPDATE_USER'),
    validateParams(objectIdSchema),
    validate(updateUserSchema),
    userController.updateUser
);

// Delete user - requires DELETE_USER permission
router.delete(
    '/:userId',
    authorizePermission('DELETE_USER'),
    validateParams(objectIdSchema),
    userController.deleteUser
);

// Change user status - requires CHANGE_USER_STATUS permission
router.patch(
    '/:userId/status',
    authorizePermission('CHANGE_USER_STATUS'),
    validateParams(objectIdSchema),
    validate(changeStatusSchema),
    userController.changeUserStatus
);

// Reset user password - requires RESET_USER_PASSWORD permission
router.post(
    '/:userId/reset-password',
    authorizePermission('RESET_USER_PASSWORD'),
    validateParams(objectIdSchema),
    validate(resetPasswordSchema),
    userController.resetUserPassword
);

module.exports = router;
