const { User, USER_STATUS } = require('../../user.model');
const ApiError = require('../../../../utils/ApiError');
const httpStatus = require('../../../../constants/httpStatus');
const { ERROR } = require('../../../../constants/messages');
const mailService = require('../../../../shared/mail.service');
const { loadTemplate } = require('../../../../templates/email');
const logger = require('../../../../shared/logger.service');
const auditService = require('../../../../shared/audit.service');

/**
 * Create a new user
 * @param {Object} userData
 * @param {ObjectId} creatorId - ID of the user creating this user
 * @returns {Promise<User>}
 */
const createUser = async (userData, creatorId = null) => {
    if (await User.isEmailTaken(userData.email)) {
        throw new ApiError(ERROR.USER_ALREADY_EXISTS, httpStatus.CONFLICT);
    }

    // Capture plaintext password before it gets hashed by the model
    const plaintextPassword = userData.password;

    const user = await User.create({
        ...userData,
        createdBy: creatorId,
        updatedBy: creatorId,
    });

    // Send welcome email with credentials
    try {
        const welcomeHtml = loadTemplate('welcome-credentials', {
            user_name: `${user.firstName} ${user.lastName}`,
            email: user.email,
            password: plaintextPassword,
            role: user.role,
        });

        await mailService.sendRawEmail({
            to: user.email,
            subject: 'Welcome — Your Account Has Been Created',
            html: welcomeHtml,
        });
        logger.info(`Welcome email sent to: ${user.email}`);
    } catch (emailError) {
        // Log error but don't fail user creation
        logger.error(`Failed to send welcome email to ${user.email}:`, emailError);
    }

    // Audit Log
    if (creatorId) {
        await auditService.logAudit({
            user: creatorId,
            action: 'CREATE',
            entity: 'User',
            entityId: user._id,
            details: { email: user.email, role: user.role }
        });
    }

    return user;
};

/**
 * Get users with pagination and filters
 * @param {Object} filter - Mongo filter
 * @param {Object} options - Query options (page, limit, sortBy)
 * @returns {Promise<{users: User[], total: number, page: number, limit: number}>}
 */
const getUsers = async (filter = {}, options = {}) => {
    const page = parseInt(options.page, 10) || 1;
    const limit = parseInt(options.limit, 10) || 10;
    const skip = (page - 1) * limit;
    const sortBy = options.sortBy || 'createdAt';
    const sortOrder = options.sortOrder === 'asc' ? 1 : -1;
    const { search } = options;

    // Exclude deleted/suspended users by default unless explicitly requested
    const queryFilter = { ...filter };

    if (search) {
        queryFilter.$or = [
            { email: { $regex: search, $options: 'i' } },
            { firstName: { $regex: search, $options: 'i' } },
            { lastName: { $regex: search, $options: 'i' } },
        ];
    }

    const [users, total] = await Promise.all([
        User.find(queryFilter)
            .sort({ [sortBy]: sortOrder })
            .skip(skip)
            .limit(limit)
            .populate('createdBy', 'firstName lastName email')
            .populate('updatedBy', 'firstName lastName email'),
        User.countDocuments(queryFilter),
    ]);

    return {
        users,
        total,
        page,
        limit,
    };
};

/**
 * Get user by ID
 * @param {string} userId
 * @returns {Promise<User>}
 */
const getUserById = async (userId) => {
    const user = await User.findById(userId)
        .populate('createdBy', 'firstName lastName email')
        .populate('updatedBy', 'firstName lastName email');

    if (!user) {
        throw new ApiError(ERROR.USER_NOT_FOUND, httpStatus.NOT_FOUND);
    }

    return user;
};

/**
 * Update user by ID
 * @param {string} userId
 * @param {Object} updateData
 * @param {ObjectId} updaterId - ID of the user performing the update
 * @returns {Promise<User>}
 */
const updateUser = async (userId, updateData, updaterId) => {
    const user = await getUserById(userId);

    // Prevent email updates for security and data integrity
    if (updateData.email && updateData.email !== user.email) {
        throw new ApiError('Email cannot be changed', httpStatus.BAD_REQUEST);
    }

    // Don't allow password or email updates through this method
    delete updateData.password;
    delete updateData.email;

    Object.assign(user, updateData, { updatedBy: updaterId });
    await user.save();

    await auditService.logAudit({
        user: updaterId,
        action: 'UPDATE',
        entity: 'User',
        entityId: user._id,
        details: { updates: Object.keys(updateData) }
    });

    return user;
};

/**
 * Delete user by ID (Hard delete)
 * @param {string} userId
 * @param {ObjectId} actorId
 * @returns {Promise<User>}
 */
const deleteUser = async (userId, actorId) => {
    const user = await getUserById(userId);
    await User.findByIdAndDelete(userId);

    await auditService.logAudit({
        user: actorId,
        action: 'DELETE',
        entity: 'User',
        entityId: userId,
        details: { deletedUserEmail: user.email }
    });

    return user;
};

/**
 * Change user status
 * @param {string} userId
 * @param {string} status - New status (active, inactive, suspended)
 * @param {ObjectId} updaterId
 * @returns {Promise<User>}
 */
const changeUserStatus = async (userId, status, updaterId) => {
    const user = await getUserById(userId);

    if (!Object.values(USER_STATUS).includes(status)) {
        throw new ApiError('Invalid status', httpStatus.BAD_REQUEST);
    }

    user.status = status;
    user.updatedBy = updaterId;
    await user.save();

    await auditService.logAudit({
        user: updaterId,
        action: 'STATUS_CHANGE',
        entity: 'User',
        entityId: user._id,
        details: { oldStatus: user.status, newStatus: status }
    });

    return user;
};

/**
 * Reset user password
 * @param {string} userId
 * @param {string} newPassword
 * @param {ObjectId} updaterId
 * @returns {Promise<User>}
 */
const resetUserPassword = async (userId, newPassword, updaterId) => {
    const user = await getUserById(userId);

    user.password = newPassword;
    user.updatedBy = updaterId;
    await user.save();

    return user;
};

/**
 * Update last login timestamp
 * @param {string} userId
 * @returns {Promise<User>}
 */
const updateLastLogin = async (userId) => {
    return User.findByIdAndUpdate(userId, { lastLogin: new Date() }, { new: true });
};

module.exports = {
    createUser,
    getUsers,
    getUserById,
    updateUser,
    deleteUser,
    changeUserStatus,
    resetUserPassword,
    updateLastLogin,
};
