const httpStatus = require('../../../../constants/httpStatus');
const { SUCCESS } = require('../../../../constants/messages');
const userService = require('../services/user.service');
const { sendSuccess, sendPaginatedResponse } = require('../../../../utils/response');
const catchAsync = require('../../../../utils/catchAsync');
const { ROLES } = require('../../../../constants/roles');

/**
 * Create a new user
 */
const createUser = catchAsync(async (req, res) => {
    const user = await userService.createUser(req.body, req.user._id);
    sendSuccess(res, SUCCESS.USER_CREATED, user, httpStatus.CREATED);
});

/**
 * Get all users with pagination
 */
const getUsers = catchAsync(async (req, res) => {
    const { page, limit, sortBy, sortOrder, status, role, search } = req.query;

    const filter = {};
    if (status) filter.status = status;
    if (role) filter.role = role;

    // Hide SuperAdmin from non-SuperAdmin users
    if (req.user.role !== ROLES.SUPER_ADMIN) {
        // If explicitly asking for SuperAdmin, return empty list
        if (filter.role === ROLES.SUPER_ADMIN) {
            return sendPaginatedResponse(res, [], {
                page: parseInt(page, 10) || 1,
                limit: parseInt(limit, 10) || 10,
                total: 0
            }, SUCCESS.USERS_FETCHED);
        }

        // If not filtering by role (or filtering by other roles), explicitly exclude SuperAdmin
        if (!filter.role) {
            filter.role = { $ne: ROLES.SUPER_ADMIN };
        }
    }

    const result = await userService.getUsers(filter, { page, limit, sortBy, sortOrder, search });

    sendPaginatedResponse(res, result.users, {
        page: result.page,
        limit: result.limit,
        total: result.total,
    }, SUCCESS.USERS_FETCHED);
});

/**
 * Get user by ID
 */
const getUserById = catchAsync(async (req, res) => {
    const user = await userService.getUserById(req.params.userId);
    sendSuccess(res, SUCCESS.USER_FETCHED, user);
});

/**
 * Update user by ID
 */
const updateUser = catchAsync(async (req, res) => {
    const user = await userService.updateUser(req.params.userId, req.body, req.user._id);
    sendSuccess(res, SUCCESS.USER_UPDATED, user);
});

/**
 * Update own profile
 */
const updateProfile = catchAsync(async (req, res) => {
    const user = await userService.updateUser(req.user._id, req.body, req.user._id);
    sendSuccess(res, SUCCESS.USER_UPDATED, user);
});

/**
 * Delete user by ID (soft delete)
 */
const deleteUser = catchAsync(async (req, res) => {
    await userService.deleteUser(req.params.userId, req.user._id);
    sendSuccess(res, SUCCESS.USER_DELETED, null);
});

/**
 * Change user status
 */
const changeUserStatus = catchAsync(async (req, res) => {
    const user = await userService.changeUserStatus(
        req.params.userId,
        req.body.status,
        req.user._id
    );
    sendSuccess(res, SUCCESS.USER_STATUS_UPDATED, user);
});

/**
 * Reset user password
 */
const resetUserPassword = catchAsync(async (req, res) => {
    await userService.resetUserPassword(
        req.params.userId,
        req.body.password,
        req.user._id
    );
    sendSuccess(res, SUCCESS.PASSWORD_RESET_SUCCESS, null);
});

module.exports = {
    createUser,
    getUsers,
    getUserById,
    updateProfile,
    updateUser,
    deleteUser,
    changeUserStatus,
    resetUserPassword,
};
