const cron = require('node-cron');
const Transaction = require('../modules/payment/payment.model');
const { PAYMENT_STATUS } = require('../constants/payment');
const logger = require('../shared/logger.service');

const paymentService = require('../modules/payment/v1/services/payment.service');
const eventBus = require('../shared/eventBus');

const cleanupPendingTransactions = async () => {
    try {
        logger.info('[PaymentCleanup] Starting cleanup of old pending transactions...');

        // Find transactions pending for more than 24 hours
        const cutoffDate = new Date();
        cutoffDate.setHours(cutoffDate.getHours() - 24);

        const pendingTransactions = await Transaction.find({
            status: PAYMENT_STATUS.PENDING,
            createdAt: { $lt: cutoffDate }
        });

        if (pendingTransactions.length === 0) {
            logger.info('[PaymentCleanup] No old pending transactions found.');
            return;
        }

        logger.info(`[PaymentCleanup] Found ${pendingTransactions.length} pending transactions. Starting reconciliation...`);

        for (const transaction of pendingTransactions) {
            try {
                const provider = paymentService.getProvider(transaction.provider);
                if (!provider) {
                    logger.error(`[PaymentCleanup] Unknown provider '${transaction.provider}' for transaction ${transaction._id}`);
                    continue;
                }

                const orderData = await provider.fetchOrder(transaction.providerOrderId);

                if (orderData.status === 'paid') {
                    // Reconciliation: User paid but we missed it. self-heal.
                    transaction.status = PAYMENT_STATUS.COMPLETED;
                    transaction.metadata = {
                        ...transaction.metadata,
                        reconciliation: 'auto-healed',
                        reconciledAt: new Date(),
                        providerStatus: orderData.status
                    };
                    await transaction.save();

                    logger.info(`[PaymentCleanup] RECONCILED: Transaction ${transaction._id} was actually PAID. Updated to COMPLETED.`);
                    eventBus.emit('payment.completed', { transaction, userId: transaction.userId });
                } else if (orderData.status === 'attempted' || orderData.status === 'created') {
                    // Still pending at provider, but we are expiring it locally
                    transaction.status = PAYMENT_STATUS.FAILED;
                    transaction.error = { message: 'Transaction expired due to inactivity', lastProviderStatus: orderData.status };
                    await transaction.save();
                    logger.info(`[PaymentCleanup] Expired Transaction ${transaction._id}. Provider status: ${orderData.status}.`);
                } else {
                    // Provider marked it as failed/expired
                    transaction.status = PAYMENT_STATUS.FAILED;
                    transaction.error = { message: 'Transaction failed at provider', providerStatus: orderData.status };
                    await transaction.save();
                    logger.info(`[PaymentCleanup] Failed Transaction ${transaction._id} based on provider status: ${orderData.status}.`);
                }
            } catch (err) {
                logger.error(`[PaymentCleanup] Failed to reconcile transaction ${transaction._id}: ${err.message}`, { transactionId: transaction._id });
                // Don't fail the loop, continue to next
            }
        }

    } catch (error) {
        logger.error(`[PaymentCleanup] Cleanup failed: ${error.message}`, { stack: error.stack });
    }
};

// Schedule task to run every day at midnight
const initPaymentCleanup = () => {
    cron.schedule('0 0 * * *', cleanupPendingTransactions);
    logger.info('[PaymentCleanup] Scheduled reconciliation & cleanup job for 00:00 daily.');
};

module.exports = {
    initPaymentCleanup,
    cleanupPendingTransactions
};
