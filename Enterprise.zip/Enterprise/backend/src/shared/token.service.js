const jwt = require('jsonwebtoken');
const config = require('../config');
const moment = require('moment');
const redis = require('../config/redis');

const TOKEN_TYPES = {
    ACCESS: 'access',
    REFRESH: 'refresh',
};

/**
 * Generate a JWT token
 * @param {ObjectId} userId
 * @param {Moment} expires
 * @param {string} type
 * @param {string} [secret]
 * @returns {string}
 */
const generateToken = (userId, expires, type, secret = config.jwt.secret) => {
    const payload = {
        sub: userId,
        iat: moment().unix(),
        exp: expires.unix(),
        type,
    };
    return jwt.sign(payload, secret);
};

/**
 * Generate access and refresh tokens
 * @param {User} user
 * @returns {Object}
 */
const generateAuthTokens = (user) => {
    const accessTokenExpires = moment().add(config.jwt.accessExpirationMinutes, 'minutes');
    const accessToken = generateToken(user._id, accessTokenExpires, TOKEN_TYPES.ACCESS);

    const refreshTokenExpires = moment().add(config.jwt.refreshExpirationDays, 'days');
    const refreshToken = generateToken(user._id, refreshTokenExpires, TOKEN_TYPES.REFRESH);

    return {
        access: {
            token: accessToken,
            expires: accessTokenExpires.toDate(),
        },
        refresh: {
            token: refreshToken,
            expires: refreshTokenExpires.toDate(),
        },
    };
};

/**
 * Verify a JWT token
 * @param {string} token
 * @param {string} type - Expected token type
 * @returns {Object} Token payload
 */
const verifyToken = async (token, type = TOKEN_TYPES.ACCESS) => {
    const payload = jwt.verify(token, config.jwt.secret);
    if (payload.type !== type) {
        throw new Error('Invalid token type');
    }

    if (await isTokenBlacklisted(token)) {
        throw new Error('Token is blacklisted');
    }

    return payload;
};

/**
 * Blacklist a token
 * @param {string} token
 * @param {number} expires - Expiration time in seconds
 * @returns {Promise<void>}
 */
const blacklistToken = async (token, expires) => {
    const now = moment().unix();
    const ttl = expires - now;
    if (ttl > 0) {
        await redis.set(`blacklist:${token}`, '1', 'EX', ttl);
    }
};

/**
 * Check if token is blacklisted
 * @param {string} token
 * @returns {Promise<boolean>}
 */
const isTokenBlacklisted = async (token) => {
    const result = await redis.get(`blacklist:${token}`);
    return result === '1';
};

module.exports = {
    TOKEN_TYPES,
    generateToken,
    generateAuthTokens,
    verifyToken,
    blacklistToken,
    isTokenBlacklisted,
};
