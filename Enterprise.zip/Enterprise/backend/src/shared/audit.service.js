const AuditLog = require('../models/auditLog.model');
const logger = require('./logger.service');

/**
 * Log an audit event
 * @param {Object} params
 * @param {ObjectId} params.user - User ID performing the action
 * @param {string} params.action - Action type (CREATE, UPDATE, DELETE, etc.)
 * @param {string} params.entity - Entity affected (User, Payment, etc.)
 * @param {string} params.entityId - ID of the entity
 * @param {Object} [params.details] - Additional details (changes, metadata)
 * @param {string} [params.ip] - IP address
 * @param {string} [params.userAgent] - User Agent
 * @returns {Promise<AuditLog>}
 */
const logAudit = async ({ user, action, entity, entityId, details = {}, ip, userAgent }) => {
    try {
        const audit = await AuditLog.create({
            user,
            action,
            entity,
            entityId,
            details,
            ip,
            userAgent,
        });
        return audit;
    } catch (error) {
        logger.error('Failed to create audit log:', error);
        // Don't throw, we don't want to break the main flow if logging fails
    }
};

module.exports = {
    logAudit,
};
