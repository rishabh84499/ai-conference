const config = require('../config');
const logger = require('./logger.service');

const { apiUrl, apiKey, projectId } = config.emailService;

/**
 * Send email using a pre-configured template via the external Email API.
 * brand_name, support_email, and from address are automatically injected from project config.
 *
 * @param {Object} options
 * @param {string} options.template - Template slug (e.g. 'reset-password')
 * @param {string} options.to - Recipient email address
 * @param {string} options.subject - Email subject line
 * @param {Object} [options.data={}] - Template variables
 * @returns {Promise<Object>} API response
 */
async function sendEmail({ template, to, subject, data = {} }) {
    try {
        if (!apiUrl || !apiKey) {
            logger.warn('[EmailService] EMAIL_API_URL or EMAIL_API_KEY not configured. Skipping email send.');
            return { success: false, message: 'Email service not configured' };
        }

        logger.info(`[EmailService] Sending email to ${to} | Template: ${template}`);

        if (config.env === 'test') {
            logger.info('[EmailService] Test environment — skipping actual send.');
            return { success: true, message: 'Skipped in test environment' };
        }

        const response = await fetch(`${apiUrl}/send`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'X-API-Key': apiKey,
            },
            body: JSON.stringify({
                template,
                to,
                subject,
                data,
                projectId,
            }),
        });

        if (!response.ok) {
            const error = await response.json().catch(() => ({ message: response.statusText }));
            logger.error(`[EmailService] API Error (${response.status}): ${error.message || JSON.stringify(error)}`);
            throw new Error(error.message || 'Email sending failed');
        }

        const result = await response.json();
        logger.info(`[EmailService] Email sent successfully. Response: ${JSON.stringify(result)}`);
        return result;
    } catch (error) {
        logger.error(`[EmailService] Failed to send email: ${error.message}`);
        throw error;
    }
}

/**
 * Send email with inline HTML content (no template required).
 *
 * @param {Object} options
 * @param {string} options.to - Recipient email address
 * @param {string} options.subject - Email subject line
 * @param {string} options.html - Full HTML body
 * @returns {Promise<Object>} API response
 */
async function sendRawEmail({ to, subject, html }) {
    try {
        if (!apiUrl || !apiKey) {
            logger.warn('[EmailService] EMAIL_API_URL or EMAIL_API_KEY not configured. Skipping email send.');
            return { success: false, message: 'Email service not configured' };
        }

        logger.info(`[EmailService] Sending raw email to ${to} | Subject: ${subject}`);

        if (config.env === 'test') {
            logger.info('[EmailService] Test environment — skipping actual send.');
            return { success: true, message: 'Skipped in test environment' };
        }

        const response = await fetch(`${apiUrl}/send`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'X-API-Key': apiKey,
            },
            body: JSON.stringify({
                to,
                subject,
                html,
                projectId,
            }),
        });

        if (!response.ok) {
            const error = await response.json().catch(() => ({ message: response.statusText }));
            logger.error(`[EmailService] API Error (${response.status}): ${error.message || JSON.stringify(error)}`);
            throw new Error(error.message || 'Email sending failed');
        }

        const result = await response.json();
        logger.info(`[EmailService] Raw email sent successfully. Response: ${JSON.stringify(result)}`);
        return result;
    } catch (error) {
        logger.error(`[EmailService] Failed to send raw email: ${error.message}`);
        throw error;
    }
}

module.exports = { sendEmail, sendRawEmail };