const { User, USER_STATUS } = require('../modules/user/user.model');
const tokenService = require('./token.service');
const userService = require('../modules/user/v1/services/user.service');
const mailService = require('./mail.service');
const ApiError = require('../utils/ApiError');
const httpStatus = require('../constants/httpStatus');
const { ERROR } = require('../constants/messages');
const crypto = require('crypto');
const config = require('../config');
const { loadTemplate } = require('../templates/email');
const logger = require('./logger.service');
const auditService = require('./audit.service');

/**
 * Login with email and password
 * @param {string} email
 * @param {string} password
 * @returns {Promise<{user: User, tokens: Object}>}
 */
const loginWithEmailAndPassword = async (email, password) => {
    const user = await User.findOne({ email });

    if (!user) {
        logger.warn(`Failed login attempt for non-existent email: ${email}`);
        throw new ApiError(ERROR.INVALID_CREDENTIALS, httpStatus.UNAUTHORIZED);
    }

    if (user.status === USER_STATUS.SUSPENDED) {
        logger.warn(`Login attempt for suspended account: ${email}`);
        throw new ApiError('Your account has been suspended. Please contact support.', httpStatus.FORBIDDEN);
    }

    if (user.status !== USER_STATUS.ACTIVE) {
        logger.warn(`Login attempt for inactive account: ${email}`);
        throw new ApiError('Account is not active. Please contact administrator.', httpStatus.FORBIDDEN);
    }

    const isPasswordValid = await user.isPasswordMatch(password);
    if (!isPasswordValid) {
        logger.warn(`Failed login attempt for email: ${email}`);
        throw new ApiError(ERROR.INVALID_CREDENTIALS, httpStatus.UNAUTHORIZED);
    }

    // Update last login
    await userService.updateLastLogin(user._id);

    const tokens = tokenService.generateAuthTokens(user);

    logger.info(`User logged in: ${email}`);
    return { user, tokens };
};

/**
 * Refresh auth tokens
 * @param {string} refreshToken
 * @returns {Promise<Object>}
 */
const refreshAuthTokens = async (refreshToken) => {
    try {
        const payload = tokenService.verifyToken(refreshToken, tokenService.TOKEN_TYPES.REFRESH);
        const user = await User.findById(payload.sub);

        if (!user) {
            throw new ApiError('User not found', httpStatus.UNAUTHORIZED);
        }

        if (user.status !== USER_STATUS.ACTIVE) {
            throw new ApiError('Account is not active', httpStatus.FORBIDDEN);
        }

        const tokens = tokenService.generateAuthTokens(user);
        return { user, tokens };
    } catch (error) {
        logger.warn(`Invalid refresh token attempt`);
        throw new ApiError('Invalid refresh token', httpStatus.UNAUTHORIZED);
    }
};

/**
 * Get current user profile
 * @param {ObjectId} userId
 * @returns {Promise<User>}
 */
const getCurrentUser = async (userId) => {
    return userService.getUserById(userId);
};

/**
 * Request password reset
 * @param {string} email
 * @returns {Promise<{resetToken: string}>}
 */
const forgotPassword = async (email) => {
    const user = await User.findOne({ email });

    if (!user) {
        // Don't reveal if email exists
        logger.info(`Password reset requested for non-existent email: ${email}`);
        return { message: 'If the email exists, a reset link will be sent' };
    }

    // Generate reset token (valid for 1 hour)
    const resetToken = crypto.randomBytes(32).toString('hex');
    const resetTokenExpires = new Date(Date.now() + 60 * 60 * 1000); // 1 hour

    user.passwordResetToken = crypto.createHash('sha256').update(resetToken).digest('hex');
    user.passwordResetExpires = resetTokenExpires;
    await user.save();

    logger.info(`Password reset token generated for: ${email}`);

    // Construct reset link
    const frontendUrl = config.frontendUrl || 'http://localhost:5173';
    const resetLink = `${frontendUrl}/reset-password?token=${resetToken}`;

    // Send email
    try {
        const resetHtml = loadTemplate('reset-password', {
            user_name: `${user.firstName} ${user.lastName}`,
            reset_link: resetLink,
            expiry_time: '1 hour',
        });

        await mailService.sendRawEmail({
            to: email,
            subject: 'Reset Your Password',
            html: resetHtml,
        });

        logger.info(`Password reset email sent to: ${email}`);

        // Audit Log: Success
        await auditService.logAudit({
            user: user._id,
            action: 'PASSWORD_RESET_REQUESTED',
            entity: 'User',
            entityId: user._id,
            details: { email: user.email, status: 'EMAIL_SENT' }
        });
    } catch (emailError) {
        logger.error(`Failed to send password reset email to ${email}:`, emailError);

        // Audit Log: Failure
        await auditService.logAudit({
            user: user._id,
            action: 'PASSWORD_RESET_FAILED',
            entity: 'User',
            entityId: user._id,
            details: { email: user.email, error: emailError.message }
        });
    }

    return {
        message: 'If the email exists, a reset link will be sent',
    };
};

/**
 * Reset password with token
 * @param {string} token
 * @param {string} newPassword
 * @returns {Promise<void>}
 */
const resetPassword = async (token, newPassword) => {
    const hashedToken = crypto.createHash('sha256').update(token).digest('hex');

    const user = await User.findOne({
        passwordResetToken: hashedToken,
        passwordResetExpires: { $gt: Date.now() },
    });

    if (!user) {
        throw new ApiError('Invalid or expired reset token', httpStatus.BAD_REQUEST);
    }

    user.password = newPassword;
    user.passwordResetToken = undefined;
    user.passwordResetExpires = undefined;
    await user.save();

    logger.info(`Password reset successful for: ${user.email}`);
};

/**
 * Change password for authenticated user
 * @param {ObjectId} userId
 * @param {string} currentPassword
 * @param {string} newPassword
 * @returns {Promise<void>}
 */
const changePassword = async (userId, currentPassword, newPassword) => {
    const user = await User.findById(userId);

    if (!user) {
        throw new ApiError(ERROR.USER_NOT_FOUND, httpStatus.NOT_FOUND);
    }

    const isPasswordValid = await user.isPasswordMatch(currentPassword);
    if (!isPasswordValid) {
        logger.warn(`Failed password change attempt for user: ${user.email}`);
        throw new ApiError('Current password is incorrect', httpStatus.BAD_REQUEST);
    }

    user.password = newPassword;
    await user.save();

    logger.info(`Password changed for: ${user.email}`);
};

/**
 * Logout
 * @param {string} accessToken
 * @param {number} accessExpires
 * @param {string} [refreshToken]
 * @returns {Promise<void>}
 */
const logout = async (accessToken, accessExpires, refreshToken) => {
    // Blacklist access token
    await tokenService.blacklistToken(accessToken, accessExpires);

    // Blacklist refresh token if provided
    if (refreshToken) {
        try {
            const payload = tokenService.verifyToken(refreshToken, tokenService.TOKEN_TYPES.REFRESH);
            // Verify is async now? No, decode first to get exp if verification fails? 
            // Ideally we verify. But verifyToken is now async.
            // We can just use jwt.decode if we trust it's ours, or just use verifyToken.
            // But if we call verifyToken it calls redis, which is fine.
            // HOWEVER, tokenService.verifyToken returns payload.
            // Wait, tokenService.verifyToken is async now.

            // Let's rely on payload.exp
            await tokenService.blacklistToken(refreshToken, payload.exp);
        } catch (e) {
            // If refresh token is invalid/expired, no need to blacklist
        }
    }
};

module.exports = {
    loginWithEmailAndPassword,
    refreshAuthTokens,
    getCurrentUser,
    forgotPassword,
    resetPassword,
    changePassword,
    logout,
};
