const mongoose = require('mongoose');

// Mock Redis globally
jest.mock('ioredis', () => {
    return jest.fn().mockImplementation(() => ({
        on: jest.fn(),
        status: 'ready',
        connect: jest.fn(),
        disconnect: jest.fn(),
        duplicate: jest.fn().mockReturnThis(),
        // Add other methods used in the app
    }));
});

// Mock Socket.IO Redis Adapter
jest.mock('@socket.io/redis-adapter', () => ({
    createAdapter: jest.fn().mockReturnValue(() => { }),
}));

// Mock BullMQ
jest.mock('bullmq', () => ({
    Queue: jest.fn().mockImplementation(() => ({
        add: jest.fn(),
        process: jest.fn(),
        on: jest.fn(),
    })),
    Worker: jest.fn().mockImplementation(() => ({
        on: jest.fn(),
    })),
}));

// Global hooks
beforeAll(async () => {
    // Connect to a dummy mongoose instance or mock it? 
    // Ideally use MongoMemoryServer, but for now we suppress connection errors
    jest.spyOn(mongoose, 'connect').mockImplementation(async () => Promise.resolve());
});

afterAll(async () => {
    await mongoose.disconnect();
});

afterEach(() => {
    jest.clearAllMocks();
});
