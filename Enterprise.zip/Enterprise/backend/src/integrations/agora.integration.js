const { RtcTokenBuilder, RtcRole } = require('agora-token');
const config = require('../config/index');
const logger = require('../shared/logger.service');

/**
 * Generate Agora RTC Token
 * @param {string} channelName 
 * @param {number} uid 
 * @param {number} role 
 * @param {number} privilegeExpireTime 
 * @returns {string}
 */
const generateRtcToken = (channelName, uid, role = RtcRole.PUBLISHER, privilegeExpireTime = 3600) => {
    try {
        const appId = config.agora.appId;
        const appCertificate = config.agora.appCertificate;

        if (!appId || !appCertificate) {
            throw new Error('Agora App ID or App Certificate is missing in configuration');
        }

        const currentTimestamp = Math.floor(Date.now() / 1000);
        const privilegeExpiredTs = currentTimestamp + privilegeExpireTime;

        const token = RtcTokenBuilder.buildTokenWithUid(
            appId,
            appCertificate,
            channelName,
            uid,
            role,
            privilegeExpiredTs,
            privilegeExpiredTs
        );

        return token;
    } catch (error) {
        logger.error('Error generating Agora RTC token:', error);
        throw error;
    }
};

module.exports = {
    generateRtcToken,
};
