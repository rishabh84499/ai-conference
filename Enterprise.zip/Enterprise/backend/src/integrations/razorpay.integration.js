const Razorpay = require('razorpay');
const config = require('../config/index');
const logger = require('../shared/logger.service');

/**
 * Razorpay Integration Client
 * Centralized initialization of the Razorpay SDK
 */
const razorpay = new Razorpay({
    key_id: config.razorpay.keyId,
    key_secret: config.razorpay.keySecret,
});

logger.info('Razorpay integration initialized');

module.exports = razorpay;
