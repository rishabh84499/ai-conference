const mongoose = require('mongoose');
const { toJSON, paginate } = require('./plugins');

const auditLogSchema = mongoose.Schema(
    {
        user: {
            type: mongoose.Schema.Types.ObjectId,
            ref: 'User',
            required: true,
        },
        action: {
            type: String,
            required: true,
            enum: ['CREATE', 'UPDATE', 'DELETE', 'LOGIN', 'LOGOUT', 'STATUS_CHANGE'],
        },
        entity: {
            type: String,
            required: true, // e.g., 'User', 'Payment'
        },
        entityId: {
            type: String,
            required: true,
        },
        details: {
            type: mongoose.Schema.Types.Mixed,
            default: {},
        },
        ip: {
            type: String,
        },
        userAgent: {
            type: String,
        },
    },
    {
        timestamps: true,
    }
);

// add plugin that converts mongoose to json
auditLogSchema.plugin(toJSON);
auditLogSchema.plugin(paginate);

const AuditLog = mongoose.model('AuditLog', auditLogSchema);

module.exports = AuditLog;
