const mongoose = require('mongoose');
const { toJSON } = require('./plugins');

const broadcastSchema = mongoose.Schema(
    {
        title: {
            type: String,
            required: true,
            trim: true,
        },
        message: {
            type: String,
            required: true,
        },
        type: {
            type: String,
            enum: ['security', 'system', 'marketing', 'activity'],
            required: true,
        },
        createdBy: {
            type: mongoose.Schema.Types.ObjectId,
            ref: 'User',
            required: true,
        },
        status: {
            type: String,
            enum: ['PENDING', 'PROCESSING', 'COMPLETED', 'FAILED'],
            default: 'PENDING',
        },
        stats: {
            totalUsers: { type: Number, default: 0 },
            processedCount: { type: Number, default: 0 },
            successCount: { type: Number, default: 0 },
            failureCount: { type: Number, default: 0 },
        },
        startedAt: {
            type: Date,
        },
        completedAt: {
            type: Date,
        },
        error: {
            type: String,
        },
    },
    {
        timestamps: true,
    }
);

// add plugin that converts mongoose to json
broadcastSchema.plugin(toJSON);

const Broadcast = mongoose.model('Broadcast', broadcastSchema);

module.exports = Broadcast;
