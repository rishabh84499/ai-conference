const toJSON = require('./toJSON');
const paginate = require('./paginate');

module.exports = {
    toJSON,
    paginate,
};
