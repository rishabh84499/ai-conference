const Redis = require('ioredis');
const config = require('./index');
const logger = require('../shared/logger.service');

const redisConfig = {
    host: config.redis.host,
    port: config.redis.port,
    password: config.redis.password,
    maxRetriesPerRequest: null, // Required for BullMQ
    enableReadyCheck: false,
    retryStrategy(times) {
        const delay = Math.min(times * 50, 2000);
        return delay;
    },
    reconnectOnError(err) {
        const targetError = 'READONLY';
        if (err.message.slice(0, targetError.length) === targetError) {
            // Only reconnect when the error starts with "READONLY"
            return true;
        }
        return false;
    },
};

const redis = new Redis(redisConfig);

redis.on('connect', () => {
    logger.info('[Redis] Connected to Redis');
});

redis.on('error', (err) => {
    logger.error(`[Redis] Error: ${err.message}`);
});

module.exports = redis;
