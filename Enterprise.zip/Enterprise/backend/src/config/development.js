require('dotenv').config();

module.exports = {
    env: 'development',
    cors: {
        origin: process.env.CORS_ORIGIN ? process.env.CORS_ORIGIN.split(',') : ["http://localhost:5001", "http://localhost:5173", "http://localhost:5002"],
        credentials: true,
    },
    logLevel: 'debug',
};
