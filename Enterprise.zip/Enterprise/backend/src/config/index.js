const dotenv = require('dotenv');
const path = require('path');

dotenv.config({
    path: process.env.NODE_ENV === 'test' ? path.join(__dirname, '../../.env.test') : path.join(__dirname, '../../.env')
});
const joi = require('joi');

const envSchema = joi.object({
    NODE_ENV: joi.string()
        .allow('development', 'production', 'test', 'staging')
        .default('development'),
    PORT: joi.number().default(5000),
    MONGO_URI: joi.string().default('mongodb://localhost:27017/enterprise_dev').description('Mongo DB url'),
    JWT_SECRET: joi.string().default('default-secret-key').description('JWT secret key'),
    JWT_ACCESS_EXPIRATION_MINUTES: joi.number().default(30).description('minutes after which access tokens expire'),
    JWT_REFRESH_EXPIRATION_DAYS: joi.number().default(30).description('days after which refresh tokens expire'),
    SMTP_HOST: joi.string().description('server that will send the emails'),
    SMTP_PORT: joi.number().description('port to connect to the email server'),
    SMTP_USERNAME: joi.string().description('username for email server'),
    SMTP_PASSWORD: joi.string().description('password for email server'),
    EMAIL_FROM: joi.string().description('the from field in the emails sent by the app'),
    RAZORPAY_KEY_ID: joi.string().description('razorpay key id'),
    RAZORPAY_KEY_SECRET: joi.string().description('razorpay key secret'),
    RAZORPAY_WEBHOOK_SECRET: joi.string().description('razorpay webhook secret'),
    EMAIL_API_URL: joi.string().description('External email API base URL'),
    EMAIL_API_KEY: joi.string().description('External email API key'),
    PROJECT_ID: joi.string().description('Project ID for the email service'),
    REDIS_HOST: joi.string().default('localhost').description('Redis host'),
    REDIS_PORT: joi.number().default(6379).description('Redis port'),
    REDIS_PASSWORD: joi.string().allow('').description('Redis password'),
    FRONTEND_URL: joi.string().description('Frontend URL for emails'),
    AGORA_APP_ID: joi.string().description('Agora App ID'),
    AGORA_APP_CERTIFICATE: joi.string().description('Agora App Certificate'),
})
    .unknown();

const { value: envVars, error } = envSchema.prefs({ errors: { label: 'key' } }).validate(process.env);

if (error) {
    throw new Error(`Config validation error: ${error.message}`);
}

const env = envVars.NODE_ENV;
const environmentConfig = require(`./${env}`);

const config = {
    env,
    port: envVars.PORT,
    mongoose: {
        url: envVars.MONGO_URI,
        options: {
            // Mongoose 6+: these are default true, but Mongoose 9 might not support them?
            // Keeping empty for now to auto-negotiate
        },
    },
    jwt: {
        secret: envVars.JWT_SECRET,
        accessExpirationMinutes: envVars.JWT_ACCESS_EXPIRATION_MINUTES,
        refreshExpirationDays: envVars.JWT_REFRESH_EXPIRATION_DAYS,
    },
    email: {
        smtp: {
            host: envVars.SMTP_HOST,
            port: envVars.SMTP_PORT,
            auth: {
                user: envVars.SMTP_USERNAME,
                pass: envVars.SMTP_PASSWORD,
            },
        },
        from: envVars.EMAIL_FROM,
    },
    razorpay: {
        keyId: envVars.RAZORPAY_KEY_ID,
        keySecret: envVars.RAZORPAY_KEY_SECRET,
        webhookSecret: envVars.RAZORPAY_WEBHOOK_SECRET,
    },
    emailService: {
        apiUrl: envVars.EMAIL_API_URL,
        apiKey: envVars.EMAIL_API_KEY,
        projectId: envVars.PROJECT_ID,
    },
    redis: {
        host: envVars.REDIS_HOST,
        port: envVars.REDIS_PORT,
        password: envVars.REDIS_PASSWORD,
    },
    agora: {
        appId: envVars.AGORA_APP_ID,
        appCertificate: envVars.AGORA_APP_CERTIFICATE,
    },
    frontendUrl: envVars.FRONTEND_URL,
    ...environmentConfig,
};

module.exports = config;
