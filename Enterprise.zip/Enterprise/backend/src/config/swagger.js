const swaggerJsdoc = require('swagger-jsdoc');
const { version } = require('../../package.json');
const config = require('./index');

const options = {
    definition: {
        openapi: '3.0.0',
        info: {
            title: 'NexFutrr Enterprise API',
            version,
            description: 'Enterprise-grade backend API documentation',
            license: {
                name: 'MIT',
                url: 'https://github.com/hagopj13/node-express-boilerplate/blob/master/LICENSE',
            },
        },
        servers: [
            {
                url: `http://localhost:${config.port}/api/v1`,
                description: 'Development Server',
            },
        ],
        components: {
            securitySchemes: {
                bearerAuth: {
                    type: 'http',
                    scheme: 'bearer',
                    bearerFormat: 'JWT',
                },
            },
        },
        security: [
            {
                bearerAuth: [],
            },
        ],
    },
    apis: ['./src/modules/*/v1/routes/*.js', './src/routes/v1/*.js'],
};

const specs = swaggerJsdoc(options);

module.exports = specs;
