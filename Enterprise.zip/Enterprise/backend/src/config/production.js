require('dotenv').config();

module.exports = {
    env: 'production',
    cors: {
        origin: process.env.CORS_ORIGIN ? process.env.CORS_ORIGIN.split(',') : [],
        credentials: true,
    },
    logLevel: 'info',
};
