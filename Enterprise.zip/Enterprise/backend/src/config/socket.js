const socketIo = require('socket.io');
const jwt = require('jsonwebtoken');
const config = require('./index');
const logger = require('../shared/logger.service');

let io;

const initSocket = (server) => {

    io = socketIo(server, {
        cors: {
            origin: config.cors.origin,
            methods: ["GET", "POST"],
            credentials: config.cors.credentials
        }
    });


    io.use((socket, next) => {
        // Auth Middleware
        const token = socket.handshake.auth.token || socket.handshake.query.token;
        if (!token) {
            return next(new Error('Authentication error: Token required'));
        }

        try {
            if (!config.jwt.secret) {
                throw new Error('JWT_SECRET not configured');
            }
            const decoded = jwt.verify(token, config.jwt.secret);
            socket.user = decoded;
            next();
        } catch (err) {
            next(new Error('Authentication error: Invalid token'));
        }
    });

    io.on('connection', (socket) => {
        logger.info(`User connected: ${socket.user.sub}`);

        // Join a room specifically for this user to receive private notifications
        socket.join(socket.user.sub);

        // ─── Video Call Signaling ────────────────────────────────
        socket.on('call-user', ({ to, offer, channelName }) => {
            logger.info(`Call from ${socket.user.sub} to ${to}`);
            io.to(to).emit('call-made', {
                offer,
                from: socket.user.sub,
                channelName
            });
        });

        socket.on('make-answer', ({ to, answer }) => {
            logger.info(`Answer from ${socket.user.sub} to ${to}`);
            io.to(to).emit('answer-made', {
                answer,
                from: socket.user.sub
            });
        });

        socket.on('reject-call', ({ to }) => {
            logger.info(`Call rejected by ${socket.user.sub} to ${to}`);
            io.to(to).emit('call-rejected', {
                from: socket.user.sub
            });
        });

        socket.on('end-call', ({ to }) => {
            logger.info(`Call ended by ${socket.user.sub} for ${to}`);
            io.to(to).emit('call-ended', {
                from: socket.user.sub
            });
        });

        socket.on('disconnect', () => {
            logger.info('User disconnected');
        });
    });

    return io;
};

const getIo = () => {
    if (!io) {
        throw new Error('Socket.io not initialized!');
    }
    return io;
};

module.exports = { initSocket, getIo };
