const config = require('../config');
const { User, USER_STATUS } = require('../modules/user/user.model');
const ApiError = require('../utils/ApiError');
const httpStatus = require('../constants/httpStatus');
const { ROLES, hasPermission } = require('../constants/roles');
const tokenService = require('../shared/token.service');

/**
 * Authenticate user via JWT token
 */
const authenticate = async (req, res, next) => {
    try {
        const authHeader = req.headers.authorization;

        if (!authHeader || !authHeader.startsWith('Bearer ')) {
            throw new ApiError('Authentication required', httpStatus.UNAUTHORIZED);
        }

        const token = authHeader.substring(7);

        // Use tokenService for consistent token verification
        const decoded = await tokenService.verifyToken(token, tokenService.TOKEN_TYPES.ACCESS);

        const user = await User.findById(decoded.sub);

        if (!user) {
            throw new ApiError('User not found', httpStatus.UNAUTHORIZED);
        }

        if (user.status !== USER_STATUS.ACTIVE) {
            throw new ApiError('Account is not active', httpStatus.FORBIDDEN);
        }

        req.user = user;
        next();
    } catch (error) {
        if (error.name === 'JsonWebTokenError') {
            next(new ApiError('Invalid token', httpStatus.UNAUTHORIZED));
        } else if (error.name === 'TokenExpiredError') {
            next(new ApiError('Token expired', httpStatus.UNAUTHORIZED));
        } else if (error.message === 'Token is blacklisted') {
            next(new ApiError('Session expired. Please login again.', httpStatus.UNAUTHORIZED));
        } else {
            next(error);
        }
    }
};

/**
 * Authorize user based on roles
 * @param {...string} allowedRoles - Roles that are allowed to access the route
 */
const authorize = (...allowedRoles) => {
    return (req, res, next) => {
        if (!req.user) {
            return next(new ApiError('Authentication required', httpStatus.UNAUTHORIZED));
        }

        if (!allowedRoles.includes(req.user.role)) {
            return next(new ApiError('Access denied', httpStatus.FORBIDDEN));
        }

        next();
    };
};

/**
 * Authorize user based on permission
 * @param {string} permission - Permission required to access the route
 */
const authorizePermission = (permission) => {
    return (req, res, next) => {
        if (!req.user) {
            return next(new ApiError('Authentication required', httpStatus.UNAUTHORIZED));
        }

        if (!hasPermission(req.user.role, permission)) {
            return next(new ApiError('Access denied', httpStatus.FORBIDDEN));
        }

        next();
    };
};

module.exports = {
    authenticate,
    authorize,
    authorizePermission,
};
