const rateLimit = require('express-rate-limit');

/**
 * Rate limiter for login attempts
 * Prevents brute-force attacks
 */
const loginLimiter = rateLimit({
    windowMs: 15 * 60 * 1000, // 15 minutes
    max: 5, // 5 attempts per window
    skipSuccessfulRequests: true, // Only count failed attempts
    message: {
        success: false,
        message: 'Too many login attempts. Please try again after 15 minutes.',
    },
    standardHeaders: true,
    legacyHeaders: false,
});

/**
 * Rate limiter for password reset requests
 */
const passwordResetLimiter = rateLimit({
    windowMs: 60 * 60 * 1000, // 1 hour
    max: 3, // 3 attempts per hour
    message: {
        success: false,
        message: 'Too many password reset requests. Please try again after an hour.',
    },
    standardHeaders: true,
    legacyHeaders: false,
});

/**
 * Rate limiter for broadcasting notifications
 */
const broadcastLimiter = rateLimit({
    windowMs: 60 * 1000, // 1 minute
    max: 10, // 10 broadcasts per minute
    message: {
        success: false,
        message: 'Too many broadcasts. Please wait a minute.',
    },
    standardHeaders: true,
    legacyHeaders: false,
});

module.exports = {
    loginLimiter,
    passwordResetLimiter,
    broadcastLimiter
};

