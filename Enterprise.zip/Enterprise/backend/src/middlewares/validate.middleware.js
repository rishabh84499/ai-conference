const ApiError = require('../utils/ApiError');
const httpStatus = require('../constants/httpStatus');

/**
 * Validate request body against a Joi schema
 * @param {Joi.Schema} schema
 * @returns {Function}
 */
const validate = (schema) => {
    return (req, res, next) => {
        const { error, value } = schema.validate(req.body, {
            abortEarly: false,
            stripUnknown: true,
        });

        if (error) {
            const errorMessage = error.details
                .map((detail) => detail.message)
                .join(', ');
            return next(new ApiError(errorMessage, httpStatus.BAD_REQUEST));
        }

        // Replace body with validated/sanitized value
        req.body = value;
        next();
    };
};

/**
 * Validate request params against a Joi schema
 * @param {Joi.Schema} schema
 * @returns {Function}
 */
const validateParams = (schema) => {
    return (req, res, next) => {
        const { error, value } = schema.validate(req.params, {
            abortEarly: false,
        });

        if (error) {
            const errorMessage = error.details
                .map((detail) => detail.message)
                .join(', ');
            return next(new ApiError(errorMessage, httpStatus.BAD_REQUEST));
        }

        req.params = value;
        next();
    };
};

module.exports = { validate, validateParams };
