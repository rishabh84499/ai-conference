const express = require('express');
const userRoutes = require('../../modules/user/v1/routes/user.routes');
const authRoutes = require('../../modules/auth/v1/routes/auth.routes');
const paymentRoutes = require('../../modules/payment/v1/routes/payment.routes');
const notificationRoutes = require('../../modules/notification/v1/routes/notification.routes');
const callRoutes = require('../../modules/call/v1/routes/call.routes');

const router = express.Router();

router.use('/auth', authRoutes);
router.use('/users', userRoutes);
router.use('/payment', paymentRoutes);
router.use('/notifications', notificationRoutes);
router.use('/call', callRoutes);

module.exports = router;
