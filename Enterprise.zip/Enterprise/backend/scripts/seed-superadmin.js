/**
 * Seed script to create initial SuperAdmin user
 * Run with: node scripts/seed-superadmin.js
 */
require('dotenv').config();
const mongoose = require('mongoose');
const config = require('../src/config');
const { User, USER_STATUS } = require('../src/modules/user/user.model');
const { ROLES } = require('../src/constants/roles');

const SUPER_ADMIN_DATA = {
    firstName: 'Super',
    lastName: 'Admin',
    email: 'superadmin@enterprise.com',
    password: 'SuperAdmin@123!', // Will be hashed by pre-save hook
    role: ROLES.SUPER_ADMIN,
    status: USER_STATUS.ACTIVE,
    isEmailVerified: true,
};

const seedSuperAdmin = async () => {
    try {
        console.log('Connecting to database...');
        await mongoose.connect(config.mongoose.url);
        console.log('Connected to MongoDB');

        // Check if SuperAdmin already exists
        const existingAdmin = await User.findOne({ email: SUPER_ADMIN_DATA.email });

        if (existingAdmin) {
            console.log('SuperAdmin already exists:', existingAdmin.email);
            console.log('Skipping creation.');
        } else {
            const superAdmin = await User.create(SUPER_ADMIN_DATA);
            console.log('SuperAdmin created successfully!');
            console.log('Email:', superAdmin.email);
            console.log('Role:', superAdmin.role);
            console.log('Password: SuperAdmin@123! (change immediately!)');
        }

        await mongoose.disconnect();
        console.log('Database disconnected.');
        process.exit(0);
    } catch (error) {
        console.error('Error seeding SuperAdmin:', error.message);
        process.exit(1);
    }
};

seedSuperAdmin();
