const mailService = require('../src/shared/mail.service');
const config = require('../src/config/index');

async function test() {
    console.log('Config being used:', JSON.stringify(config.emailService, null, 2));
    console.log('Starting email test...');
    try {
        const result = await mailService.sendEmail({
            template: 'registration-confirmation',
            to: 'ashish.bigfatailabs@gmail.com', // Using a test email
            subject: 'Test Email Delivery',
            data: {
                user_name: 'Test Administrator',
                status: 'Active',
                next_steps: 'If you see this, the email integration is working correctly.'
            }
        });
        console.log('Test successful:', JSON.stringify(result, null, 2));
    } catch (error) {
        console.error('Test failed:', error.message);
    }
}

test();
