const express = require("express");
const config = require("./src/config/index");
const morgan = require("morgan");
const helmet = require("helmet");
const cors = require("cors");
const rateLimit = require("express-rate-limit");
const cookieParser = require("cookie-parser");
const mongoSanitize = require('express-mongo-sanitize');
const compression = require('compression');
const hpp = require('hpp');

const routes = require("./src/routes/v1/index"); // Entry point for /api/v1/*
const { errorConverter, errorHandler, notFound } = require('./src/middlewares/error.middleware');

const app = express();

const logger = require('./src/shared/logger.service');

const { v4: uuidv4 } = require('uuid');

// const xss = require('xss-clean');

// ─── Middlewares ─────────────────────────────────────────
// ─── Middlewares ─────────────────────────────────────────

// Secure CORS Configuration (MUST BE FIRST)
// Verify config.cors.origin is correct
console.log('CORS Origin Config:', config.cors.origin);

app.use(
  cors({
    origin: config.cors.origin,
    methods: ['GET', 'POST', 'PUT', 'PATCH', 'DELETE', 'OPTIONS'],
    allowedHeaders: ['Content-Type', 'Authorization', 'X-Requested-With'],
    credentials: true,
  })
);

app.use(express.json());
app.use(express.urlencoded({ extended: true }));
app.use(cookieParser());

// Request ID Middleware
app.use((req, res, next) => {
  req.id = uuidv4();
  res.setHeader('X-Request-Id', req.id);
  next();
});

// Data Sanitization against XSS
// app.use(xss());

app.use(helmet({
  crossOriginResourcePolicy: { policy: "cross-origin" }
}));

// Custom Morgan Format with Request ID
morgan.token('id', (req) => req.id);
const morganFormat = ':date[iso] [:id] :method :url :status :res[content-length] - :response-time ms';

app.use(morgan(morganFormat, { stream: logger.stream }));

// ─── Rate Limiting ───────────────────────────────────────
const limiter = rateLimit({
  windowMs: 15 * 60 * 1000, // 15 minutes
  max: 100,
});
app.use(limiter);

// ─── Routes ──────────────────────────────────────────────
const swaggerUi = require('swagger-ui-express');
const swaggerSpecs = require('./src/config/swagger');

// Swagger Documentation
app.use('/api-docs', swaggerUi.serve, swaggerUi.setup(swaggerSpecs));

app.use("/api/v1", routes);

// ─── 404 Handler ─────────────────────────────────────────
app.use(notFound);

// ─── Global Error Handler ────────────────────────────────
app.use(errorConverter);
app.use(errorHandler);

module.exports = app;
