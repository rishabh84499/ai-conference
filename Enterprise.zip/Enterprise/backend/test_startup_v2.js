const fs = require('fs');
const path = require('path');

const logFile = path.resolve('startup.log');
fs.writeFileSync(logFile, 'Starting diagnostics...\n');

const log = (msg) => {
    console.log(msg);
    fs.appendFileSync(logFile, '[INFO] ' + msg + '\n');
};
const error = (msg) => {
    console.error(msg);
    fs.appendFileSync(logFile, '[ERROR] ' + msg + '\n');
};

process.on('uncaughtException', (err) => {
    error('Uncaught Exception: ' + err.stack);
    process.exit(1);
});

try {
    log('Loading config...');
    const config = require('./src/config/index');
    log('Config loaded successfully.');

    log('Loading app...');
    const app = require('./app');
    log('App loaded successfully.');

    log('Loading server...');
    // We can't require server.js easily because it starts the server.
    // But requiring app.js loads all routes and middleware.

    log('Diagnostics complete. App structure seems valid.');
    process.exit(0);

} catch (e) {
    error('Startup Failed: ' + e.stack);
    process.exit(1);
}
